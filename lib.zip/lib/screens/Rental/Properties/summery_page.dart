import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:three_zero_two_property/provider/dateProvider.dart';
import 'package:three_zero_two_property/screens/Leasing/Applicants/Applicants_table.dart';
import 'package:three_zero_two_property/widgets/appbar.dart';
import '../../../Model/All_categories_model.dart';
import '../../../Model/Properties_revenue_model.dart';
import '../../../Model/properties_Lease_model.dart';
import '../../../Model/unit.dart';
import '../../../StaffModule/screen/Leasing/RentalRoll/addcard/AddCard.dart';
import '../../../constant/constant.dart';
import '../../../model/properties.dart';
import '../../../model/properties_summery.dart';
import '../../../model/properties_workorders.dart';
import '../../../model/unitsummery_propeties.dart';
import '../../../provider/lease_provider.dart';
import '../../../provider/properties_workorders.dart';
import '../../../repository/fetch_allcategories.dart';
import '../../../repository/properties.dart';
import '../../../repository/properties_summery.dart';
import 'package:http/http.dart' as http;
import '../../../repository/unit_data.dart';
import '../../../widgets/Properties_revenue_table.dart';
import '../../Leasing/RentalRoll/addcard/CardModel.dart';
import '../../Maintenance/Workorder/workorder_summery.dart';
import '../mortgage/property_mortgage_table.dart';
import 'Property Tax/Property_tax_Table.dart';
import 'applience/Applience_parts.dart';
import 'infrastracture.dart';
import 'moveout/Moveout_properties.dart';
import 'moveout/repository.dart';
import '../../Leasing/RentalRoll/NewAddLease.dart';
import '../../Maintenance/Workorder/Add_workorder.dart';
import '../../../widgets/custom_drawer.dart';
import '../../../widgets/custom_admin_lease_table.dart';

class Summery_page extends StatefulWidget {
  Rentals properties;
  TenantData? tenants;
  unit_properties? unit;

  //RentalSummary? tenantsummery;
  Summery_page({super.key, required this.properties, this.tenants, this.unit});
  @override
  _Summery_pageState createState() => _Summery_pageState();
}

class _Summery_pageState extends State<Summery_page>
    with SingleTickerProviderStateMixin {
  // Arrays for bed and bath dropdowns
  static const List<String> roomsArray = [
    "1 Bed",
    "2 Bed",
    "3 Bed",
    "4 Bed",
    "5 Bed",
    "6 Bed",
    "7 Bed",
    "8 Bed",
    "9 Bed",
    "9+ Bed",
  ];

  static const List<String> bathArray = [
    "1 Bath",
    "1.5 Bath",
    "2 Bath",
    "2.5 Bath",
    "3 Bath",
    "3.5 Bath",
    "4 Bath",
    "4.5 Bath",
    "5 Bath",
    "5+ Bath",
  ];
  TabController? _tabController;
  ScrollController _scrollController = ScrollController();
  late Future<List<TenantData>> futurePropertysummery;
  late Future<Rentals> futureRentalDetails;
  late Future<List<Properties_lease_model>> futureLeaseDetails;
  late Future<List<Properties_Revenu_model>> futureLeaseRevenueDetails;
  late Future<List<unit_properties>> futureUnitsummery;
  late Future<List<Rentals>> futurerentalowners;
  int _selectedIndex = 0;

  //late Future<List<RentalSummary>> futuresummery;

  unit_properties? unit;
  DateTime? startdate;
  DateTime? enddate;
  int unitCount = 0;
  TextEditingController startdateController = TextEditingController();
  TextEditingController enddateController = TextEditingController();
  TextEditingController unitnum = TextEditingController();
  TextEditingController street3 = TextEditingController();
  TextEditingController sqft3 = TextEditingController();
  TextEditingController bath3 = TextEditingController();
  TextEditingController bed3 = TextEditingController();
  bool isLoading = false;
  bool iserror = false;

  // Normalize bed value to match available options
  void normalizeBedValue() {
    if (bed3.text.isEmpty) return;

    // If the value is not in roomsArray, try to normalize it
    if (!roomsArray.contains(bed3.text)) {
      // Try to extract the number from the text (e.g., "10 Bed" -> 10)
      final RegExp bedRegex = RegExp(r'(\d+)');
      final match = bedRegex.firstMatch(bed3.text);
      if (match != null) {
        int bedCount = int.parse(match.group(1)!);
        if (bedCount >= 9) {
          bed3.text = "9+ Bed";
        } else if (bedCount > 0 && bedCount < 9) {
          bed3.text = "$bedCount Bed";
        }
      }
    }
  }

  // Normalize bath value to match available options
  void normalizeBathValue() {
    if (bath3.text.isEmpty) return;

    // If the value is not in bathArray, try to normalize it
    if (!bathArray.contains(bath3.text)) {
      // Try to extract the number from the text (e.g., "6.5 Bath" -> 6.5)
      final RegExp bathRegex = RegExp(r'(\d+\.?\d*)');
      final match = bathRegex.firstMatch(bath3.text);
      if (match != null) {
        double bathCount = double.parse(match.group(1)!);
        if (bathCount >= 5) {
          bath3.text = "5+ Bath";
        } else {
          // Round to nearest .5
          double rounded = (bathCount * 2).round() / 2;
          if (rounded > 0 && rounded < 5) {
            bath3.text =
                "${rounded.toStringAsFixed(rounded.truncateToDouble() == rounded ? 0 : 1)} Bath";
          }
        }
      }
    }
  }

  // Helper function to convert display format back to API format (yyyy-MM-dd)
  String _convertToApiFormat(String displayDate) {
    if (displayDate.isEmpty) return "";
    try {
      DateTime? parsedDate;

      // Try to parse the date using common formats
      List<String> dateFormats = [
        'MM/dd/yyyy',
        'MM-dd-yyyy',
        'yyyy-MM-dd',
        'dd/MM/yyyy',
        'dd-MM-yyyy'
      ];

      for (String format in dateFormats) {
        try {
          parsedDate = DateFormat(format).parse(displayDate);
          break;
        } catch (e) {
          continue;
        }
      }

      if (parsedDate != null) {
        return DateFormat('yyyy-MM-dd').format(parsedDate);
      }

      return displayDate; // Return as is if parsing fails
    } catch (e) {
      return displayDate; // Return as is if parsing fails
    }
  }

  ConnectivityResult? _connectivityResult;

  @override
  void initState() {
    super.initState();
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      setState(() {
        print(result);
        _connectivityResult = result;
      });
    });

    // Add scroll listener to update UI when scrolling
    _scrollController.addListener(() {
      setState(() {
        // This will trigger a rebuild to update arrow colors
      });
    });

    checkInternet();
    _fetchData();
    futureUnitsummery =
        Properies_summery_Repo().fetchunit(widget.properties.rentalId ?? "");
    fetchunits1();
    futurePropertysummery = Properies_summery_Repo()
        .fetchPropertiessummery(widget.properties.rentalId!);
    futureworkordersummery =
        Properies_summery_Repo().fetchWorkOrders(widget.properties.rentalId!);
    // futuresummery = Properies_summery_Repo().fetchPropertiessummery(widget.properties.rentalId!);
    _tabController = TabController(length: 5, vsync: this);
    // street3.text = widget.unit!.rentalunitadress!;
    futureRentalDetails = Properies_summery_Repo()
        .fetchrentalDetails(widget.properties.rentalId!);
    // futureLeaseDetails = Properies_summery_Repo().fetchrLeaseDetails(widget.unit?.unitId ?? "");
    futureUnitsummery.then((units) {
      if (units.isNotEmpty) {
        // Get the first unit's ID and fetch lease details
        String unitId = units.first.unitId!;
        futureLeaseDetails =
            Properies_summery_Repo().fetchrLeaseDetails(unitId);
        print("unit id with new $unitId");
      }
    });
    futureUnitsummery.then((units) {
      if (units.isNotEmpty) {
        // Get the first unit's ID and fetch lease details
        String unitId = units.first.unitId!;
        futureLeaseRevenueDetails =
            Properies_summery_Repo().fetchrRevenueDetails(unitId);
        print("unit id with new $unitId");
      }
    });
    _fetchData();
    print(" unit id ${widget.unit?.unitId ?? ""}");
    // moveOutDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    futurerentalowners = PropertiesRepository().fetchProperties();
    // displayDate = DateFormat('dd/MM/yyyy').format(DateTime.parse(moveOutDate));
    // startdateController.text = displayDate;
    print('abc test for enddate ${widget.tenants?.endDate}');
    // fetchunits1();
    //fetchLeases();
    // fetchAndSetCounts(context);
    //workorder
    // fetchAndSetCounts(context);
    WidgetsBinding.instance.addPostFrameCallback((_) {});
  }

  void checkInternet() async {
    var connectiondata;
    connectiondata = await Connectivity().checkConnectivity();
    setState(() {
      _connectivityResult = connectiondata;
    });
  }

  // Scroll to previous tab
  void _scrollToPreviousTab() {
    if (_scrollController.hasClients) {
      double currentOffset = _scrollController.offset;
      double scrollAmount = 150; // Adjust this value based on your tab width
      double newOffset = (currentOffset - scrollAmount)
          .clamp(0.0, _scrollController.position.maxScrollExtent);
      _scrollController.animateTo(
        newOffset,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  // Scroll to next tab
  void _scrollToNextTab() {
    if (_scrollController.hasClients) {
      double currentOffset = _scrollController.offset;
      double scrollAmount = 150; // Adjust this value based on your tab width
      double newOffset = (currentOffset + scrollAmount)
          .clamp(0.0, _scrollController.position.maxScrollExtent);
      _scrollController.animateTo(
        newOffset,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  String? moveOutDate;
  // String moveOutDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
  // String displayDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
  Future<Map<String, dynamic>> fetchDataOfCountWork(String rentalId) async {
    final response = await http
        .get(Uri.parse('$Api_url/api/work-order/rental_workorder/$rentalId'));

    if (response.statusCode == 200) {
      // Parse the response body
      final Map<String, dynamic> data = json.decode(response.body);
      return {
        "count": data['count'] ?? 0,
        "complete_count": data['complete_count'] ?? 0,
      };
    } else {
      throw Exception('Failed to load count data');
    }
  }

  Future<void> fetchAndSetCounts(BuildContext context) async {
    try {
      final data = await fetchDataOfCountWork(widget.properties.rentalId!);
      int newCount = data['count'] ?? 0;
      int newCompleteCount = data['complete_count'] ?? 0;
      print(newCompleteCount);
      print(newCount);
      final provider =
          Provider.of<WorkOrderCountProvider>(context, listen: false);
      provider.updateCount(newCount);
      provider.updateCompleteCount(newCompleteCount);
    } catch (error) {
      print('Error fetching counts: $error');
    }
  }

  File? _image;
  List<File> _images = [];
  String? _uploadedFileName;
  List<String> _uploadedFileNames = [];
  Future<String?> uploadImage(File imageFile) async {
    print(imageFile.path);
    final String uploadUrl = '${image_upload_url}/api/images/upload';
    var request = http.MultipartRequest(
        'POST',
        Uri.parse(
          uploadUrl,
        ));
    request.files
        .add(await http.MultipartFile.fromPath('files', imageFile.path));

    var response = await request.send();
    var responseData = await http.Response.fromStream(response);
    print(responseData.body);

    var responseBody = json.decode(responseData.body);
    if (responseBody['status'] == 'ok') {
      List file = responseBody['files'];
      return file.first["filename"];
    } else {
      throw Exception('Failed to upload file: ${responseBody['message']}');
    }
  }

  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _image = File(image.path);
        _images.add(File(image.path));
      });
      // _uploadImage(File(image.path));
    }
  }

  Future<void> _uploadImage(File imageFile) async {
    try {
      String? fileName = await uploadImage(imageFile);
      setState(() {
        _uploadedFileNames.add(fileName!);
        _uploadedFileName = fileName;
        // _imageUrls.add(fileName!);
        // _updateRentalImage(fileName!);
        _editimageUrls.add(fileName);
        print(fileName);
      });
    } catch (e) {
      print('Image upload failed: $e');
    }
  }

  Future<void> _updateRentalImage(String fileName) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? id = prefs.getString("adminId");
      String? token = prefs.getString('token');
      final String apiUrl =
          '${Api_url}/api/rentals/proparty_image/${widget.properties.rentalId}';
      final response = await http.put(
        Uri.parse(apiUrl),
        headers: <String, String>{
          "authorization": "CRM $token",
          'Content-Type': 'application/json; charset=UTF-8',
          "id": "CRM $id",
        },
        body: json.encode({
          'rental_id': widget.properties.rentalId,
          'admin_id': id,
          'rental_image': fileName, // Use the uploaded file name
        }),
      );
      print(' image put ${response.body}');
      if (response.statusCode == 200) {
        print('Image updated successfully');
        var responseBody = json.decode(response.body);
        setState(() {
          widget.properties.rentalImage =
              fileName; // Update the rental image URL
        });
        print(responseBody['message']);
      } else {
        throw Exception('Failed to update rental image');
      }
    } catch (e) {
      print('Failed to update image: $e');
    }
  }

  Future<void> _removeImage() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? id = prefs.getString("adminId");
      String? token = prefs.getString('token');
      final String apiUrl =
          '${Api_url}/api/rentals/proparty_image/${widget.properties.rentalId}';

      // Send the PUT request to update the rental image to empty (or null) on the server
      final response = await http.put(
        Uri.parse(apiUrl),
        headers: <String, String>{
          "authorization": "CRM $token",
          'Content-Type': 'application/json; charset=UTF-8',
          "id": "CRM $id",
        },
        body: json.encode({
          'rental_id': widget.properties.rentalId,
          'admin_id': id,
          'rental_image':
              '', // Remove the image by setting it to an empty string
        }),
      );

      if (response.statusCode == 200) {
        print('Image deleted successfully from the API');
        var responseBody = json.decode(response.body);
        print(responseBody['message']);

        // Clear local image data and update UI
        setState(() {
          widget.properties.rentalImage = ''; // Set the rentalImage to empty
          _imageUrls.clear(); // Clear the image list
        });
      } else {
        throw Exception('Failed to delete image from API');
      }
    } catch (e) {
      print('Failed to remove image: $e');
    }
  }

  List<String> _imageUrls = [];
  List<String> _editimageUrls = [];

  bool showdetails = false;
  @override
  void dispose() {
    _tabController!.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  List<List<Widget>> propertyGroups = [];
//  List<List<TextEditingController>> propertyGroupControllers = [];
  List<File?> propertyGroupImages = [];
  List<String?> propertyGroupImagenames = [];
  Widget customTextField(String label, TextEditingController Controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: TextFormField(
        controller: Controller,
        cursorColor: Colors.black,
        decoration: InputDecoration(
          hintText: label,
          // labelText: label,
          // labelStyle: TextStyle(color: Colors.grey[700]),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3),
            borderSide: const BorderSide(color: Color(0xFF8A95A8)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(3),
            borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
          ),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
        ),
      ),
    );
  }

  final Properies_summery_Repo unitRepository = Properies_summery_Repo();
  //int unitCount = 0;
  int tenentCount = 0;
  int unitTenantCount = 0; // New variable for tenant count from unit API
  int count = 0;
  int complete_count = 0;

  Future<void> _fetchData() async {
    try {
      // Fetch unit count
      final data =
          await unitRepository.fetchunit(widget.properties.rentalId ?? "");
      setState(() {
        unitCount = data.isNotEmpty ? data.length : 0;
      });
    } catch (e) {
      // Handle error for fetching unit count
      print('Error fetching unit data: $e');
    }

    try {
      // Fetch tenant count
      final data1 = await Properies_summery_Repo()
          .fetchPropertiessummery(widget.properties.rentalId ?? "");
      setState(() {
        tenentCount = data1.isNotEmpty ? data1.length : 0;
      });
    } catch (e) {
      // Handle error for fetching tenant data
      print('Error fetching tenant data: $e');
    }

    try {
      // Fetch work order count
      final data2 = await Properies_summery_Repo()
          .fetchWorkOrders(widget.properties.rentalId ?? "");
      setState(() {
        count = data2.isNotEmpty ? data2.length : 0;
        complete_count = data2.length;
      });
    } catch (e) {
      // Handle error for fetching work orders
      print('Error fetching work order data: $e');
    }
  }

  List<unit_properties> data = [];
  final Properies_summery_Repo unit1Repository = Properies_summery_Repo();
  Future<void> fetchunits1() async {
    //  try {
    final fetchedunit1 =
        await unit1Repository.fetchunit(widget.properties.rentalId ?? "");
    print(widget.properties.rentalId ?? "");
    print('hello');
    setState(() {
      print(widget.unit?.unitId ?? "");
      print('hello');
      data = fetchedunit1;

      // Calculate tenant count from unit API response
      unitTenantCount = 0;
      for (var unit in fetchedunit1) {
        if (unit.tenantCount != null) {
          unitTenantCount += unit.tenantCount!;
        }
      }
      print('Unit Tenant Count: $unitTenantCount');

      isLoading = false;
    });
    //} catch (e) {
    setState(() {
      isLoading = false;
    });
    //print('Failed to load leases: $e');
    //}
  }

  //lease table

  final UnitData leaseRepository = UnitData();

  List<unit_lease> leases = [];

  bool isloading = true;

  Future<void> fetchLeases() async {
    //  try {
    final fetchedLeases =
        await leaseRepository.fetchUnitLeases(widget.unit!.unitId!);
    print(widget.unit!.unitId!);
    print('hello');
    setState(() {
      print(widget.unit!.unitId!);
      print('hello');
      leases = fetchedLeases;
      isloading = false;
    });
    //} catch (e) {
    setState(() {
      isloading = false;
    });
    //print('Failed to load leases: $e');
    //}
  }

  String getStatus(String startDate, String endDate) {
    final now = DateTime.now();
    final start = DateTime.parse(startDate);
    final end = DateTime.parse(endDate);
    return (now.isAfter(start) && now.isBefore(end)) ? 'Active' : 'Inactive';
  }

  //work order
  int totalrecords = 0;
  late Future<List<propertiesworkData>> futureworkordersummery;
  int rowsPerPage = 5;
  int sortColumnIndex = 0;
  bool sortAscending = true;
  int currentPage = 0;
  int itemsPerPage = 10;
  List<int> itemsPerPageOptions = [
    10,
    25,
    50,
    100,
  ]; // Options for items per page

  void sortData(List<propertiesworkData> data) {
    if (sorting1) {
      data.sort((a, b) => ascending1
          ? a.workSubject!.compareTo(b.workSubject!)
          : b.workSubject!.compareTo(a.workSubject!));
    } else if (sorting2) {
      data.sort((a, b) => ascending2
          ? a.workSubject!.compareTo(b.workSubject!)
          : b.workSubject!.compareTo(a.workSubject!));
    }
  }

  int? expandedIndex;
  Set<int> expandedIndices = {};
  late bool isExpanded;
  bool sorting1 = false;
  bool sorting2 = false;
  bool sorting3 = false;
  bool ascending1 = false;
  bool ascending2 = false;
  bool ascending3 = false;
  bool isChecked = false;
  bool isCheckedlease = false;
  Widget _buildHeaders() {
    var width = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
          color: const Color(0xFFF4F8FF),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFDBE0E5))),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        // leading: Container(
        //   child: Icon(
        //     Icons.expand_less,
        //     color: Colors.transparent,
        //   ),
        // ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              child: const Icon(
                Icons.expand_less,
                color: Colors.transparent,
              ),
            ),
            Expanded(
              flex: 4,
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting1 == true) {
                      sorting2 = false;
                      sorting3 = false;
                      ascending1 = sorting1 ? !ascending1 : true;
                      ascending2 = false;
                      ascending3 = false;
                    } else {
                      sorting1 = !sorting1;
                      sorting2 = false;
                      sorting3 = false;
                      ascending1 = sorting1 ? !ascending1 : true;
                      ascending2 = false;
                      ascending3 = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    width < 400
                        ? Text("Work Order ",
                            style: TextStyle(
                                color: blueColor, fontWeight: FontWeight.bold))
                        : Text("Work Order",
                            style: TextStyle(
                                color: blueColor, fontWeight: FontWeight.bold)),
                    // Text("Property", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 1),
                    ascending1
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting2) {
                      sorting1 = false;
                      sorting2 = sorting2;
                      sorting3 = false;
                      ascending2 = sorting2 ? !ascending2 : true;
                      ascending1 = false;
                      ascending3 = false;
                    } else {
                      sorting1 = false;
                      sorting2 = !sorting2;
                      sorting3 = false;
                      ascending2 = sorting2 ? !ascending2 : true;
                      ascending1 = false;
                      ascending3 = false;
                    }
                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    Text("   Status",
                        style: TextStyle(
                            color: blueColor, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 5),
                    ascending2
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting3) {
                      sorting1 = false;
                      sorting2 = false;
                      sorting3 = sorting3;
                      ascending3 = sorting3 ? !ascending3 : true;
                      ascending2 = false;
                      ascending1 = false;
                    } else {
                      sorting1 = false;
                      sorting2 = false;
                      sorting3 = !sorting3;
                      ascending3 = sorting3 ? !ascending3 : true;
                      ascending2 = false;
                      ascending1 = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    Text("       Billable ",
                        style: TextStyle(
                            color: blueColor, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 5),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  final List<String> items = [
    'New',
    "In Progress",
    "On Hold",
    "Completed",
    "Over Due",
    "All"
  ];
  String? selectedValue;
  String searchvalue = "";
  List<propertiesworkData> _tableData = [];
  int _rowsPerPage = 10;
  int _currentPage = 0;
  int? _sortColumnIndex;
  bool _sortAscending = true;

  List<propertiesworkData> get _pagedData {
    int startIndex = _currentPage * _rowsPerPage;
    int endIndex = startIndex + _rowsPerPage;
    return _tableData.sublist(startIndex,
        endIndex > _tableData.length ? _tableData.length : endIndex);
  }

  void _changeRowsPerPage(int selectedRowsPerPage) {
    setState(() {
      _rowsPerPage = selectedRowsPerPage;
      _currentPage = 0; // Reset to the first page when changing rows per page
    });
  }

  void _sort<T>(Comparable<T> Function(propertiesworkData d) getField,
      int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _tableData.sort((a, b) {
        final aValue = getField(a);
        final bValue = getField(b);
        final result = aValue.compareTo(bValue as T);
        return _sortAscending ? result : -result;
      });
    });
  }

  Widget _buildHeader<T>(String text, int columnIndex,
      Comparable<T> Function(propertiesworkData d)? getField) {
    return TableCell(
      child: InkWell(
        onTap: getField != null
            ? () {
                _sort(getField, columnIndex, !_sortAscending);
              }
            : null,
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Row(
            children: [
              Text(text,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18)),
              if (_sortColumnIndex == columnIndex)
                Icon(_sortAscending
                    ? Icons.arrow_drop_down_outlined
                    : Icons.arrow_drop_up_outlined),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDataCell(String text) {
    return TableCell(
      child: Container(
        height: 60,
        padding: const EdgeInsets.only(top: 20.0, left: 16),
        child: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }

  Widget _buildDataCellBillable(bool isBillable) {
    return TableCell(
      child: Padding(
        padding: const EdgeInsets.only(top: 20.0, left: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (isBillable) Icon(Icons.check, color: blueColor),
            if (!isBillable) Icon(Icons.close, color: blueColor),
          ],
        ),
      ),
    );
  }

  Widget _buildPaginationControls() {
    int numorpages = 1;
    numorpages = (totalrecordsmulti / _rowsPerPage).ceil();

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Text('Rows per page: '),
        // SizedBox(width: 10),
        Material(
          elevation: 2,
          color: Colors.white,
          child: Container(
            height: 55,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                value: _rowsPerPage,
                items: [10, 25, 50, 100].map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
                onChanged: (newValue) {
                  if (newValue != null) {
                    _changeRowsPerPage(newValue);
                  }
                },
                icon: const Icon(
                  Icons.arrow_drop_down,
                  size: 40,
                ),
                style: const TextStyle(color: Colors.black, fontSize: 17),
                dropdownColor: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        IconButton(
          icon: FaIcon(
            FontAwesomeIcons.circleChevronLeft,
            size: 30,
            color: _currentPage == 0 ? Colors.grey : blueColor,
          ),
          onPressed: _currentPage == 0
              ? null
              : () {
                  setState(() {
                    _currentPage--;
                  });
                },
        ),
        Text(
          'Page ${_currentPage + 1} of $numorpages',
          style: const TextStyle(fontSize: 18),
        ),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronRight,
            color: (_currentPage + 1) * _rowsPerPage >= _tableData.length
                ? Colors.grey
                : blueColor, // Change color based on availability
          ),
          onPressed: (_currentPage + 1) * _rowsPerPage >= _tableData.length
              ? null
              : () {
                  setState(() {
                    _currentPage++;
                  });
                },
        ),
      ],
    );
  }

  //for multiunit table

  int totalrecordsmulti = 0;

  int rowsPerPagemulti = 5;
  int sortColumnIndexmulti = 0;
  bool sortAscendingmulti = true;
  int currentPagemulti = 0;
  int itemsPerPagemulti = 10;
  List<int> itemsPerPageOptionsmulti = [
    10,
    25,
    50,
    100,
  ]; // Options for items per page

  void sortDatamulti(List<unit_properties> data) {
    if (sorting1multi) {
      data.sort((a, b) => ascending1multi
          ? a.rentalunit!.compareTo(b.rentalunit!)
          : b.rentalunit!.compareTo(a.rentalunit!));
    } else if (sorting2multi) {
      data.sort((a, b) => ascending2multi
          ? a.rentalunitadress!.compareTo(b.rentalunitadress!)
          : b.rentalunitadress!.compareTo(a.rentalunitadress!));
    } else if (sorting3multi) {
      data.sort((a, b) => ascending3multi
          ? a.createdAt!.compareTo(b.createdAt!)
          : b.createdAt!.compareTo(a.createdAt!));
    }
  }

  int? expandedIndexmulti;
  Set<int> expandedIndicesmulti = {};
  late bool isExpandedmulti;
  bool sorting1multi = false;
  bool sorting2multi = false;
  bool sorting3multi = false;
  bool ascending1multi = false;
  bool ascending2multi = false;
  bool ascending3multi = false;

  Widget _buildHeadersmulti() {
    var width = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
          color: const Color(0xFFF4F8FF),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFDBE0E5))),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        // leading: Container(
        //   child: Icon(
        //     Icons.expand_less,
        //     color: Colors.transparent,
        //   ),
        // ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              child: const Icon(
                Icons.expand_less,
                color: Colors.transparent,
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting1multi == true) {
                      sorting2multi = false;
                      sorting3multi = false;
                      ascending1multi = sorting1multi ? !ascending1multi : true;
                      ascending2multi = false;
                      ascending3multi = false;
                    } else {
                      sorting1multi = !sorting1multi;
                      sorting2multi = false;
                      sorting3multi = false;
                      ascending1multi = sorting1multi ? !ascending1multi : true;
                      ascending2multi = false;
                      ascending3multi = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    width < 400
                        ? Text("Unit ",
                            style: TextStyle(
                                color: blueColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18))
                        : Text("Unit",
                            style: TextStyle(
                                color: blueColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18)),
                    // Text("Property", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 3),
                    ascending1multi
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting2multi) {
                      sorting1multi = false;
                      sorting2multi = sorting2multi;
                      sorting3multi = false;
                      ascending2multi = sorting2multi ? !ascending2multi : true;
                      ascending1multi = false;
                      ascending3multi = false;
                    } else {
                      sorting1 = false;
                      sorting2 = !sorting2;
                      sorting3 = false;
                      ascending2 = sorting2 ? !ascending2 : true;
                      ascending1 = false;
                      ascending3 = false;
                    }
                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    Text("Address",
                        style: TextStyle(
                            color: blueColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 18)),
                    const SizedBox(width: 5),
                    ascending2multi
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<unit_properties> _tableDatamulti = [];
  int _rowsPerPagemulti = 10;
  int _currentPagemulti = 0;
  int? _sortColumnIndexmulti;
  bool _sortAscendingmulti = true;

  List<unit_properties> get _pagedDatamulti {
    int startIndex = _currentPagemulti * _rowsPerPagemulti;
    int endIndex = startIndex + _rowsPerPagemulti;
    return _tableDatamulti.sublist(startIndex,
        endIndex > _tableDatamulti.length ? _tableDatamulti.length : endIndex);
  }

  void _changeRowsPerPagemulti(int selectedRowsPerPage) {
    setState(() {
      _rowsPerPagemulti = selectedRowsPerPage;
      _currentPagemulti =
          0; // Reset to the first page when changing rows per page
    });
  }

  void _sortmulti<T>(Comparable<T> Function(unit_properties d) getField,
      int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndexmulti = columnIndex;
      _sortAscendingmulti = ascending;
      _tableDatamulti.sort((a, b) {
        final aValue = getField(a);
        final bValue = getField(b);
        final result = aValue.compareTo(bValue as T);
        return _sortAscendingmulti ? result : -result;
      });
    });
  }

  Widget _buildHeadermulti<T>(String text, int columnIndex,
      Comparable<T> Function(unit_properties d)? getField) {
    return TableCell(
      child: InkWell(
        onTap: getField != null
            ? () {
                _sortmulti(getField, columnIndex, !_sortAscendingmulti);
              }
            : null,
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Row(
            children: [
              Text(text,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18)),
              if (_sortColumnIndexmulti == columnIndex)
                Icon(_sortAscendingmulti
                    ? Icons.arrow_drop_down_outlined
                    : Icons.arrow_drop_up_outlined),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDataCellmulti(String text) {
    return TableCell(
      child: Container(
        height: 60,
        padding: const EdgeInsets.only(top: 15.0, left: 16, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }

  Widget _buildPaginationControlsmulti() {
    int numorpages = 1;
    numorpages = (totalrecords / _rowsPerPagemulti).ceil();

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Text('Rows per page: '),
        // SizedBox(width: 10),
        Material(
          elevation: 2,
          color: Colors.white,
          child: Container(
            height: 55,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                value: _rowsPerPage,
                items: [10, 25, 50, 100].map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
                onChanged: (newValue) {
                  if (newValue != null) {
                    _changeRowsPerPagemulti(newValue);
                  }
                },
                icon: const Icon(
                  Icons.arrow_drop_down,
                  size: 40,
                ),
                style: const TextStyle(color: Colors.black, fontSize: 17),
                dropdownColor: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        IconButton(
          icon: FaIcon(
            FontAwesomeIcons.circleChevronLeft,
            size: 30,
            color: _currentPagemulti == 0 ? Colors.grey : blueColor,
          ),
          onPressed: _currentPagemulti == 0
              ? null
              : () {
                  setState(() {
                    _currentPagemulti--;
                  });
                },
        ),
        Text(
          'Page ${_currentPagemulti + 1} of $numorpages',
          style: const TextStyle(fontSize: 18),
        ),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronRight,
            color: (_currentPagemulti + 1) * _rowsPerPagemulti >=
                    _tableDatamulti.length
                ? Colors.grey
                : blueColor, // Change color based on availability
          ),
          onPressed: (_currentPagemulti + 1) * _rowsPerPagemulti >=
                  _tableDatamulti.length
              ? null
              : () {
                  setState(() {
                    _currentPagemulti++;
                  });
                },
        ),
      ],
    );
  }

//rentalowners

  int rowsPerPagerent = 5;
  int sortColumnIndexrent = 0;
  bool sortAscendingrent = true;
  final List<String> rolesrent = ['Manager', 'Employee', 'All'];
  String? selectedRolerent;
  String searchValuerent = "";
  int currentPagerent = 0;
  int itemsPerPagerent = 10;
  int? expandedIndexrent;
  Set<int> expandedIndicesrent = {};

  List<int> itemsPerPageOptionsrent = [
    10,
    25,
    50,
    100,
  ]; // Options for items per page
  late bool isExpandedrentrent;
  bool sorting1rent = false;
  bool sorting2rent = false;
  bool sorting3rent = false;
  bool ascending1rent = false;
  bool ascending2rent = false;
  bool ascending3rent = false;

  Widget _buildHeadersrent() {
    var width = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
        color: blueColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(13),
          topRight: Radius.circular(13),
        ),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              child: const Icon(
                Icons.expand_less,
                color: Colors.transparent,
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting1rent == true) {
                      sorting2rent = false;
                      sorting3rent = false;
                      ascending1rent = sorting1rent ? !ascending1rent : true;
                      ascending2rent = false;
                      ascending3rent = false;
                    } else {
                      sorting1rent = !sorting1rent;
                      sorting2rent = false;
                      sorting3rent = false;
                      ascending1rent = sorting1rent ? !ascending1rent : true;
                      ascending2rent = false;
                      ascending3rent = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    width < 400
                        ? const Text(" Contact\nName",
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white, fontSize: 14))
                        : const Text(" Contact\nName",
                            textAlign: TextAlign.center,
                            style:
                                TextStyle(color: Colors.white, fontSize: 14)),
                    // Text("Property", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 3),
                  ],
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting2rent) {
                      sorting1rent = false;
                      sorting2rent = sorting2rent;
                      sorting3rent = false;
                      ascending2rent = sorting2rent ? !ascending2rent : true;
                      ascending1rent = false;
                      ascending3rent = false;
                    } else {
                      sorting1rent = false;
                      sorting2rent = !sorting2rent;
                      sorting3rent = false;
                      ascending2rent = sorting2rent ? !ascending2rent : true;
                      ascending1rent = false;
                      ascending3rent = false;
                    }
                    // Sorting logic here
                  });
                },
                child: const Row(
                  children: [
                    Text("Company \nName",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 14)),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting3rent) {
                      sorting1rent = false;
                      sorting2rent = false;
                      sorting3rent = sorting3rent;
                      ascending3rent = sorting3rent ? !ascending3rent : true;
                      ascending2rent = false;
                      ascending1rent = false;
                    } else {
                      sorting1rent = false;
                      sorting2rent = false;
                      sorting3rent = !sorting3rent;
                      ascending3rent = sorting3rent ? !ascending3rent : true;
                      ascending2rent = false;
                      ascending1rent = false;
                    }

                    // Sorting logic here
                  });
                },
                child: const Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 8.0),
                      child: Text("   Phone\n   Number",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 14)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Rentals> _tableDatarent = [];
  int totalrecordsrent = 0;
  int _rowsPerPagerent = 10;
  int _currentPagerent = 0;
  int? _sortColumnIndexrent;
  bool _sortColumnIndexrentrent = true;

  List<Rentals> get _pagedDatarent {
    int startIndex = _currentPagerent * _rowsPerPagerent;
    int endIndex = startIndex + _rowsPerPagerent;
    return _tableDatarent.sublist(startIndex,
        endIndex > _tableDatarent.length ? _tableDatarent.length : endIndex);
  }

  void _changeRowsPerPagerent(int selectedRowsPerPage) {
    setState(() {
      _rowsPerPagerent = selectedRowsPerPage;
      _currentPagerent =
          0; // Reset to the first page when changing rows per page
    });
  }

  void _sortrent<T>(Comparable<T> Function(Rentals d) getField, int columnIndex,
      bool ascending) {
    setState(() {
      _sortColumnIndexrent = columnIndex;
      _sortColumnIndexrentrent = ascending;
      _tableDatarent.sort((a, b) {
        final aValue = getField(a);
        final bValue = getField(b);

        int result;
        if (aValue is String && bValue is String) {
          result = aValue
              .toString()
              .toLowerCase()
              .compareTo(bValue.toString().toLowerCase());
        } else {
          result = aValue.compareTo(bValue as T);
        }

        return _sortColumnIndexrentrent ? result : -result;
      });
    });
  }

  Widget _buildHeaderrent<T>(String text, int columnIndex,
      Comparable<T> Function(Rentals d)? getField) {
    return TableCell(
      child: InkWell(
        onTap: getField != null ? () {} : null,
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Row(
            children: [
              Text(text,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18)),
              if (_sortColumnIndex == columnIndex)
                Icon(_sortAscending
                    ? Icons.arrow_drop_down_outlined
                    : Icons.arrow_drop_up_outlined),
            ],
          ),
        ),
      ),
    );
  }

  late List<unit_properties> unitList;
  late List<TenantData> propertyList;
  late List<propertiesworkData> workOrderList;

  Widget _buildDataCellrent(String text) {
    return TableCell(
      child: Padding(
        padding: const EdgeInsets.only(top: 20.0, left: 16, bottom: 15),
        child: InkWell(
            onTap: () {},
            child: Text(text?.isNotEmpty == true ? text! : 'N/A',
                style: const TextStyle(fontSize: 18))),
      ),
    );
  }

  Widget _buildPaginationControlsrent() {
    int numorpages = 1;
    numorpages = (totalrecordsrent / _rowsPerPagerent).ceil();
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Text('Rows per page: '),
        // SizedBox(width: 10),
        Material(
          elevation: 2,
          color: Colors.white,
          child: Container(
            height: 55,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                value: _rowsPerPagerent,
                items: [10, 2, 5, 1].map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
                onChanged: (newValue) {
                  if (newValue != null) {
                    _changeRowsPerPagerent(newValue);
                  }
                },
                icon: const Icon(
                  Icons.arrow_drop_down,
                  size: 40,
                ),
                style: const TextStyle(color: Colors.black, fontSize: 17),
                dropdownColor: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronLeft,
            color: _currentPagerent == 0 ? Colors.grey : blueColor,
          ),
          onPressed: _currentPagerent == 0
              ? null
              : () {
                  setState(() {
                    _currentPagerent--;
                  });
                },
        ),
        Text(
          'Page ${_currentPagerent + 1} of $numorpages',
          style: const TextStyle(fontSize: 18),
        ),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronRight,
            color: (_currentPagerent + 1) * _rowsPerPagerent >=
                    _tableDatarent.length
                ? Colors.grey
                : blueColor, // Change color based on availability
          ),
          onPressed:
              (_currentPagerent + 1) * _rowsPerPagerent >= _tableDatarent.length
                  ? null
                  : () {
                      setState(() {
                        _currentPagerent++;
                      });
                    },
        ),
      ],
    );
  }

  bool isMovedOut = false;
  // int _selectedIndex = 0;
  Future<void> _uploadAllImages() async {
    for (var image in _images) {
      await _uploadImage(image); // Upload each picked image
    }
  }

  bool staffExpanded = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: widget_302.App_Bar(context: context),
      drawer: CustomDrawer(
        currentpage: "Properties",
        dropdown: true,
      ),
      body: _connectivityResult != ConnectivityResult.none
          ? SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      SizedBox(
                        width:
                            MediaQuery.of(context).size.width > 500 ? 200 : 170,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 1),
                          child: Text(
                            '${widget.properties?.rentalAddress}',
                            maxLines: 5, // Set maximum number of lines
                            overflow: TextOverflow
                                .ellipsis, // Handle overflow with ellipsis
                            style: TextStyle(
                              fontSize: MediaQuery.of(context).size.width < 500
                                  ? 13
                                  : 18,
                              color: blueColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      // Text('${widget.properties.rentalAddress}',
                      //     style: TextStyle(
                      //       color: blueColor,
                      //       fontWeight: FontWeight.bold,
                      //       fontSize: MediaQuery.of(context).size.width < 500 ? 14 : 20,
                      //     )),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      Text(
                          '${widget.properties.propertyTypeData?.propertyType}',
                          style: TextStyle(
                            color: const Color(0xFF8A95A8),
                            fontWeight: FontWeight.bold,
                            fontSize: MediaQuery.of(context).size.width < 500
                                ? 13
                                : 20,
                          )),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  /*  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 60,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: blueColor),
                      // color: Colors.blue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: TabBar(
                      controller: _tabController,
                      dividerColor: Colors.transparent,
                      indicatorWeight: 5,
                      labelStyle: TextStyle(
                        fontSize:
                            MediaQuery.of(context).size.width < 500 ? 14 : 20,
                        // fontWeight: FontWeight.bold,
                      ),
                      //indicatorPadding: EdgeInsets.symmetric(horizontal: 1),
                      indicatorColor: blueColor,
                      labelColor: blueColor,
                      unselectedLabelColor: blueColor,
                      tabs: [
                        Tab(
                          text: 'Summary',
                        ),
                        Tab(
                          text: 'Units',
                        ),
                        StatefulBuilder(
                          builder: (BuildContext context,
                              void Function(void Function()) setState) {
                            return Tab(text: 'Tenant');
                          },
                        ),
                        StatefulBuilder(
                          builder: (BuildContext context,
                              void Function(void Function()) setState) {
                            return Tab(text: 'Work');
                          },
                        ),
                        // Consumer<WorkOrderCountProvider>(
                        //   builder: (context, provider, child) {
                        //     return Tab(text: 'Work(${provider.isChecked ? provider.count : provider.count})');
                        //   },
                        // ),
                      ],
                    ),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     SizedBox(width: 2,),
                    //     Expanded(
                    //       child: Container(
                    //         height: 43,
                    //         decoration: BoxDecoration(
                    //           color: blueColor,
                    //           borderRadius: BorderRadius.circular(5),
                    //         ),
                    //           child: Center(child: Text("Summary",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),))),
                    //     ),
                    //     SizedBox(width: 5,),
                    //     Expanded(
                    //       child: Container( height: 43,
                    //           decoration: BoxDecoration(
                    //               color: blueColor,
                    //             borderRadius: BorderRadius.circular(5),
                    //           ),
                    //           child: Center(child: Text("Unit",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),))),
                    //     ),
                    //     SizedBox(width: 5,),
                    //     Expanded(
                    //       child: Container(
                    //           height: 43,
                    //           decoration: BoxDecoration(
                    //               color: blueColor,
                    //             borderRadius: BorderRadius.circular(5),
                    //           ),
                    //           child: Center(child: Text("Tenats",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),))),
                    //     ),
                    //     SizedBox(width: 5,),
                    //     Expanded(
                    //       child: Container(
                    //           height: 43,
                    //           decoration: BoxDecoration(
                    //               color: blueColor,
                    //             borderRadius: BorderRadius.circular(5),
                    //           ),
                    //           child: Center(child: Text("Workorder",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),))),
                    //     ),
                    //     SizedBox(width: 2,),
                    //   ],
                    // ),
                  ),*/
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    height: 45,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(color: Colors.transparent),
                    ),
                    child: FutureBuilder<Rentals>(
                      future: futureRentalDetails,
                      builder: (context, snapshot) {
                        final bool isMultiUnit =
                            snapshot.data?.propertyTypeData?.isMultiunit ??
                                false;

                        // Create list of tab items
                        List<Map<String, dynamic>> tabItems = [
                          {"title": "Summary", "index": 0},
                        ];

                        if (isMultiUnit) {
                          tabItems
                              .add({"title": "Unit ($unitCount)", "index": 1});
                        }

                        tabItems.addAll([
                          {
                            "title": "Tenant ($tenentCount)",
                            "index": isMultiUnit ? 2 : 1
                          },
                          {
                            "title": "Work order ($count)",
                            "index": isMultiUnit ? 3 : 2
                          },
                          {"title": "Lease", "index": isMultiUnit ? 4 : 3},
                          {"title": "Revenue", "index": isMultiUnit ? 5 : 4},
                          {
                            "title": "Infrastructure",
                            "index": isMultiUnit ? 6 : 5
                          },
                          {"title": "Mortgage", "index": isMultiUnit ? 7 : 6},
                          //{"title": "Property Tax", "index": isMultiUnit ? 8 : 7},
                        ]);

                        return Row(
                          children: [
                            // Left arrow button - only show if not at the beginning
                            if (_scrollController.hasClients &&
                                _scrollController.offset > 0)
                              Container(
                                width: 30,
                                height: 35,
                                child: IconButton(
                                  onPressed: () {
                                    // Scroll to previous tab
                                    _scrollToPreviousTab();
                                  },
                                  icon: Icon(
                                    Icons.chevron_left,
                                    color: blueColor,
                                    size: 36,
                                  ),
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                ),
                              ),

                            // Scrollable tab content
                            Expanded(
                              child: SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                controller: _scrollController,
                                physics: const BouncingScrollPhysics(),
                                child: Row(
                                  children: tabItems.map((tab) {
                                    int tabIndex = tab["index"];
                                    String title = tab["title"];

                                    return Container(
                                      margin:
                                          const EdgeInsets.symmetric(horizontal: 3),
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            _selectedIndex = tabIndex;
                                            // Refresh data when switching to Purchase Info tab
                                            if (tabIndex == 1) {
                                              // Purchase Info tab index
                                              futureRentalDetails =
                                                  Properies_summery_Repo()
                                                      .fetchrentalDetails(widget
                                                          .properties
                                                          .rentalId!);
                                            }
                                          });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 0, horizontal: 16),
                                          decoration: BoxDecoration(
                                            color: _selectedIndex == tabIndex
                                                ? blueColor
                                                : Colors.grey.shade200,
                                            borderRadius:
                                                BorderRadius.circular(6),
                                            border: Border.all(
                                              color: _selectedIndex == tabIndex
                                                  ? blueColor
                                                  : Colors.grey.shade300,
                                              width: 1,
                                            ),
                                            boxShadow:
                                                _selectedIndex == tabIndex
                                                    ? [
                                                        BoxShadow(
                                                          color: blueColor
                                                              .withOpacity(0.3),
                                                          blurRadius: 4,
                                                          offset: const Offset(0, 2),
                                                        )
                                                      ]
                                                    : [
                                                        BoxShadow(
                                                          color: Colors.grey
                                                              .withOpacity(0.1),
                                                          blurRadius: 2,
                                                          offset: const Offset(0, 1),
                                                        )
                                                      ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              title,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                color:
                                                    _selectedIndex == tabIndex
                                                        ? Colors.white
                                                        : blueColor,
                                                fontSize: 15,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),

                            // Right arrow button - only show if not at the end
                            if (_scrollController.hasClients &&
                                _scrollController.offset <
                                    _scrollController.position.maxScrollExtent)
                              Container(
                                width: 30,
                                height: 35,
                                child: IconButton(
                                  onPressed: () {
                                    // Scroll to next tab
                                    _scrollToNextTab();
                                  },
                                  icon: Icon(
                                    Icons.chevron_right,
                                    color: blueColor,
                                    size: 36,
                                  ),
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  ),
                  _buildTabContent(context),
                  /* Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        Summary_page(),
                        // showdetails
                        //     ? unitScreen(properties: widget.properties
                        //         //properties: widget.properties,
                        //       //  unit: unit,
                        //       )
                        //     : Unit_page(),
                        // showdetails ? unitScreen1(context, unit!) : Unit_page(context),
                        showdetails
                            ? unitScreen1(context, unit!)
                            : Unit_page(context),

                        // unitScreen(),
                        // Center(child: Text('Content of Tab 2')),
                        //  Container(color:Colors.blue),
                        Tenants(context),
                        Workorder(context),
                      ],
                    ),
                  ),*/
                ],
              ),
            )
          : SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Lottie.asset(
                    'assets/no_internet.json',
                    width: 200,
                    height: 200,
                    fit: BoxFit.fill,
                  ),
                  const Text(
                    'No Internet',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Text(
                    'Check your internet connection',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
    );
  }

  //work order
  int totalrecordslease = 0;

  int rowsPerPagelease = 5;
  int sortColumnIndexlease = 0;
  bool sortAscendinglease = true;
  int currentPagelease = 0;
  int itemsPerPagelease = 10;
  List<int> itemsPerPageOptionslease = [
    10,
    25,
    50,
    100,
  ]; //
  Lease_page() {
    print("calling lease page from my screen");
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width < 500 ? 24 : 50,
                  height: MediaQuery.of(context).size.width < 500 ? 24 : 50,
                  child: Checkbox(
                    value: isCheckedlease,
                    onChanged: (value) {
                      setState(() {
                        isCheckedlease = value ?? false;
                      });
                    },
                    activeColor: isCheckedlease ? blueColor : Colors.black,
                  ),
                ),
                const SizedBox(
                  width: 8,
                ),
                Text(
                  "Show Past Leases",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: blueColor,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: FutureBuilder<List<Properties_lease_model>>(
              future: futureLeaseDetails,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: SpinKitFadingCircle(color: Colors.black, size: 40),
                  );
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Container(
                    height: MediaQuery.of(context).size.height * .5,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/images/no_data.jpg",
                              height: 200, width: 200),
                          const SizedBox(height: 10),
                          Text(
                            "No Lease Data Available",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                                fontSize: 16),
                          )
                        ],
                      ),
                    ),
                  );
                } else {
                  var data = snapshot.data!;

                  // Search Filter
                  if (searchValuerent != null &&
                      searchValuerent!.isNotEmpty &&
                      searchValuerent != "All") {
                    data = data
                        .where((e) =>
                            e.tenantNames != null &&
                            e.tenantNames!
                                .toLowerCase()
                                .contains(searchValuerent!.toLowerCase()))
                        .toList();
                  }

                  // Rental ID filter
                  data = data
                      .where((e) => e.rentalId == widget.properties.rentalId)
                      .toList();

                  // Past/Current Lease Filter
                  DateTime currentDate = DateTime.now();
                  data = data.where((lease) {
                    if (lease.endDate == null || lease.endDate!.isEmpty)
                      return false;

                    // Handle special cases
                    if (lease.endDate == "At Will" ||
                        lease.endDate == "---" ||
                        lease.endDate == "N/A") {
                      return !isCheckedlease; // Show only when displaying current/future leases
                    }

                    // Try to parse the date with multiple formats
                    DateTime? endDate;
                    List<String> dateFormats = [
                      'yyyy-MM-dd',
                      'yyyy-M-d',
                      'dd-MM-yyyy',
                      'd-M-yyyy',
                      'M/d/yyyy',
                      'MM/dd/yyyy',
                      'yyyy/MM/dd',
                      'dd/MM/yyyy'
                    ];

                    for (String format in dateFormats) {
                      try {
                        endDate =
                            DateFormat(format).parse(lease.endDate!.trim());
                        break;
                      } catch (e) {
                        continue;
                      }
                    }

                    // If we couldn't parse the date with any format
                    if (endDate == null) {
                      return !isCheckedlease; // Show in current/future by default if date can't be parsed
                    }

                    if (isCheckedlease) {
                      // Show past leases when checked
                      return endDate.isBefore(currentDate);
                    } else {
                      // Show current/future leases when unchecked
                      return endDate.isAfter(currentDate) ||
                          endDate.isAtSameMomentAs(currentDate);
                    }
                  }).toList();

                  // Pagination
                  final totalPages = (data.length / itemsPerPagelease).ceil();
                  final currentPageData = data
                      .skip(currentPagelease * itemsPerPagelease)
                      .take(itemsPerPagelease)
                      .toList();

                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        CustomAdminLeaseTable(
                          leaseData: currentPageData,
                          onSort: (columnIndex) {
                            setState(() {
                              switch (columnIndex) {
                                case 1:
                                  data.sort((a, b) => (a.tenantNames ?? '')
                                      .compareTo(b.tenantNames ?? ''));
                                  break;
                                case 2:
                                  data.sort((a, b) => (a.endDate ?? '')
                                      .compareTo(b.endDate ?? ''));
                                  break;
                                case 3:
                                  data.sort((a, b) => (a.rentCycle ?? '')
                                      .compareTo(b.rentCycle ?? ''));
                                  break;
                              }
                            });
                          },
                          blueColor: blueColor,
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                Material(
                                  elevation: 3,
                                  child: Container(
                                    height: 40,
                                    padding:
                                        const EdgeInsets.symmetric(horizontal: 12.0),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.grey),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<int>(
                                        value: itemsPerPagelease,
                                        items: itemsPerPageOptionsrent
                                            .map((int value) {
                                          return DropdownMenuItem<int>(
                                            value: value,
                                            child: Text(value.toString()),
                                          );
                                        }).toList(),
                                        onChanged: (newValue) {
                                          setState(() {
                                            itemsPerPagelease = newValue!;
                                            currentPagelease = 0;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                IconButton(
                                  icon: FaIcon(
                                    FontAwesomeIcons.circleChevronLeft,
                                    color: currentPagelease == 0
                                        ? Colors.grey
                                        : blueColor,
                                  ),
                                  onPressed: currentPagelease == 0
                                      ? null
                                      : () {
                                          setState(() {
                                            currentPagelease--;
                                          });
                                        },
                                ),
                                Text(
                                    'Page ${currentPagelease + 1} of $totalPages'),
                                IconButton(
                                  icon: FaIcon(
                                    FontAwesomeIcons.circleChevronRight,
                                    color: currentPage < totalPages - 1
                                        ? blueColor
                                        : Colors.grey,
                                  ),
                                  onPressed: currentPagelease < totalPages - 1
                                      ? () {
                                          setState(() {
                                            currentPagelease++;
                                          });
                                        }
                                      : null,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  int totalrecordsrevenue = 0;

  int rowsPerPagerevenue = 5;
  int sortColumnIndexrevenue = 0;
  bool sortAscendingrevenue = true;
  int currentPagerevenue = 0;
  int itemsPerPagerevenue = 10;
  List<int> itemsPerPageOptionsrevenue = [
    10,
    25,
    50,
    100,
  ];
  Revenue_page() {
    final dateProvider = Provider.of<DateProvider>(context);
    print("calling revenue page from my screen");
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: FutureBuilder<List<Properties_Revenu_model>>(
              future: futureLeaseRevenueDetails,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: SpinKitFadingCircle(color: Colors.black, size: 40),
                  );
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Container(
                    height: MediaQuery.of(context).size.height * .5,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/images/no_data.jpg",
                              height: 200, width: 200),
                          const SizedBox(height: 10),
                          Text(
                            "No Revenue Data Available",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                                fontSize: 16),
                          )
                        ],
                      ),
                    ),
                  );
                } else {
                  var data = snapshot.data!;

                  // Search Filter
                  if (searchValuerent != null &&
                      searchValuerent!.isNotEmpty &&
                      searchValuerent != "All") {
                    data = data
                        .where((e) =>
                            e != null &&
                            e.response!
                                .toLowerCase()
                                .contains(searchValuerent!.toLowerCase()))
                        .toList();
                  }

                  // // Rental ID filter
                  // data = data
                  //     .where((e) => e. == widget.properties.rentalId)
                  //     .toList();

                  // Pagination
                  final totalPages = (data.length / itemsPerPagerevenue).ceil();
                  final currentPageData = data
                      .skip(currentPagerevenue * itemsPerPagerevenue)
                      .take(itemsPerPagerevenue)
                      .toList();
                  print("check data of revenue ${data.first.paymentType}");
                  print("check data of date  ${data.first.entry?.first.date}");
                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        const SizedBox(height: 5),
                        CustomAdminRevenueTable(
                          revenueData: currentPageData,
                          onSort: (columnIndex) {
                            setState(() {
                              switch (columnIndex) {
                                case 1:
                                  data.sort((a, b) => (a.response ?? '')
                                      .compareTo(b.response ?? ''));
                                  break;
                                case 2:
                                  data.sort((a, b) => (a
                                              .tenantData?.tenantFirstName ??
                                          '')
                                      .compareTo(
                                          b.tenantData?.tenantFirstName ?? ''));
                                  break;
                                case 3:
                                  data.sort((a, b) => (a.paymentType ?? '')
                                      .compareTo(b.paymentType ?? ''));
                                  break;
                              }
                            });
                          },
                          blueColor: blueColor,
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                Material(
                                  elevation: 3,
                                  child: Container(
                                    height: 40,
                                    padding:
                                        const EdgeInsets.symmetric(horizontal: 12.0),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.grey),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<int>(
                                        value: itemsPerPagerevenue,
                                        items: itemsPerPageOptionsrevenue
                                            .map((int value) {
                                          return DropdownMenuItem<int>(
                                            value: value,
                                            child: Text(value.toString()),
                                          );
                                        }).toList(),
                                        onChanged: (newValue) {
                                          setState(() {
                                            itemsPerPagerevenue = newValue!;
                                            currentPagerevenue = 0;
                                          });
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                IconButton(
                                  icon: FaIcon(
                                    FontAwesomeIcons.circleChevronLeft,
                                    color: currentPagerevenue == 0
                                        ? Colors.grey
                                        : blueColor,
                                  ),
                                  onPressed: currentPagerevenue == 0
                                      ? null
                                      : () {
                                          setState(() {
                                            currentPagerevenue--;
                                          });
                                        },
                                ),
                                Text(
                                    'Page ${currentPagerevenue + 1} of $totalPages'),
                                IconButton(
                                  icon: FaIcon(
                                    FontAwesomeIcons.circleChevronRight,
                                    color: currentPagerevenue < totalPages - 1
                                        ? blueColor
                                        : Colors.grey,
                                  ),
                                  onPressed: currentPagerevenue < totalPages - 1
                                      ? () {
                                          setState(() {
                                            currentPagerevenue++;
                                          });
                                        }
                                      : null,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent(BuildContext context) {
    return FutureBuilder<Rentals>(
      future: futureRentalDetails,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: SpinKitFadingCircle(
              color: Colors.black,
              size: 50.0,
            ),
          );
        }
        final bool isMultiUnit =
            snapshot.data?.propertyTypeData?.isMultiunit ?? false;

        if (_selectedIndex == 0) {
          return Summary_page();
        } else if (_selectedIndex == 1) {
          if (isMultiUnit) {
            return showdetails
                ? unitScreen1(context, unit!)
                : Unit_page(context);
          } else {
            return Tenants(context);
          }
        } else if (_selectedIndex == 2) {
          if (isMultiUnit) {
            return Tenants(context);
          } else {
            return Workorder(context);
          }
        } else if (_selectedIndex == 3) {
          if (isMultiUnit) {
            return Workorder(context);
          } else {
            return Lease_page();
          }
        } else if (_selectedIndex == 4) {
          if (isMultiUnit) {
            return Lease_page();
          } else {
            return Revenue_page();
          }
        } else if (_selectedIndex == 5) {
          if (isMultiUnit) {
            return Revenue_page();
          } else {
            return Infrastructure_page(data);
          }
        } else if (_selectedIndex == 6 && isMultiUnit) {
          return Infrastructure_page(data);
        } else if (_selectedIndex == 6) {
          if (isMultiUnit) {
            return Infrastructure_page(data);
          } else {
            return Mortgage_page(data);
          }
        } else if (_selectedIndex == 7 && isMultiUnit) {
          return Mortgage_page(data);
        } else if (_selectedIndex == 7) {
          if (isMultiUnit) {
            return Mortgage_page(data);
          } else {
            return PropertyTax_page(data);
          }
        } else if (_selectedIndex == 8 && isMultiUnit) {
          return PropertyTax_page(data);
        }

        return Container();
      },
    );
  }

  final purchaseDateController = TextEditingController();
  final purchasePriceController = TextEditingController();
  final parcelNumberController = TextEditingController();
  DateTime? selectedDate;
  bool is_Loading = true;
  Summary_page() {
    print("$image_url${widget.properties.rentalImage}");
    final dateProvider = Provider.of<DateProvider>(context);
    return FutureBuilder<Rentals>(
      future: futureRentalDetails,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: SpinKitFadingCircle(
              color: Colors.black,
              size: 40,
            ),
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/no_internet.json'),
                Text('Error: ${snapshot.error}'),
              ],
            ),
          );
        } else if (!snapshot.hasData) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/no_data.jpg'),
                const Text('No data available'),
              ],
            ),
          );
        }
        final rentalDetails = snapshot.data!;
        print("property data summery with api ${rentalDetails.rentalAddress}");
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Container(
                  // height: 150,
                  // width: MediaQuery.of(context).size.width * .94,
                  decoration: BoxDecoration(
                    border: Border.all(color: blueColor),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20, bottom: 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // const SizedBox(
                        //   height: 4,
                        // ),
                        Row(
                          children: [
                            const SizedBox(
                              width: 15,
                            ),
                            // Container(
                            //   // height: 150,
                            //   width: 150,
                            //   decoration: BoxDecoration(color: Colors.blue),
                            //   child: Image.network(
                            //     "$image_url${widget.properties.rentalImage}"??'https://st.depositphotos.com/1763233/3344/i/450/depositphotos_33445577-stock-photo-wooden-house.jpg',
                            //     fit: BoxFit.fill,
                            //     height: 100,
                            //   ),
                            // ),

                            Container(
                              width: MediaQuery.of(context).size.width < 500
                                  ? 150
                                  : 250,
                              height: MediaQuery.of(context).size.width < 500
                                  ? 120
                                  : 200,
                              child: SizedBox(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8.0),
                                  child: CachedNetworkImage(
                                    imageUrl: (rentalDetails.rentalImage !=
                                                null &&
                                            rentalDetails
                                                .rentalImage!.isNotEmpty
                                        ? "$image_url${rentalDetails.rentalImage}"
                                        : 'assets/images/no_image.jpg'),
                                    fit: BoxFit.cover,
                                    height:
                                        MediaQuery.of(context).size.width < 500
                                            ? 140
                                            : 220,
                                    width:
                                        MediaQuery.of(context).size.width < 500
                                            ? 160
                                            : 220,
                                    placeholder: (context, url) =>
                                        Shimmer.fromColors(
                                      baseColor: Colors.grey[300]!,
                                      highlightColor: Colors.grey[100]!,
                                      child: Container(
                                        color: Colors.grey[300],
                                        height:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 140
                                                : 220,
                                        width:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 160
                                                : 220,
                                      ),
                                    ),
                                    errorWidget: (context, url, error) =>
                                        Image.asset(
                                      "assets/images/no_image.jpg",
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            if (MediaQuery.of(context).size.width < 500)
                              const SizedBox(
                                width: 15,
                              ),
                            if (MediaQuery.of(context).size.width > 500)
                              const SizedBox(
                                width: 25,
                              ),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Text(
                                      'Property Detailss',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 14
                                                : 22,
                                        color: blueColor,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Text('Address',
                                        style: TextStyle(
                                          color: const Color(0xFF8A95A8),
                                          fontSize: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 13
                                              : 18,
                                        )),
                                  ),
                                  const SizedBox(height: 5),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Text(
                                      '${rentalDetails.propertyTypeData?.propertyType}',
                                      style: TextStyle(
                                        color: blueColor,
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 13
                                                : 18,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Text(
                                      '${rentalDetails.rentalAddress}',
                                      maxLines: 4,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 13
                                                : 18,
                                        color: blueColor,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Text(
                                      [
                                        rentalDetails.rentalCity,
                                        rentalDetails.rentalState,
                                        rentalDetails.rentalCountry,
                                        rentalDetails.rentalPostcode,
                                      ]
                                          .where((element) =>
                                              element != null &&
                                              element.isNotEmpty)
                                          .map((element) => element!)
                                          .join(' , '),
                                      style: TextStyle(
                                        color: blueColor,
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 13
                                                : 18,
                                      ),
                                      maxLines: 6,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),

                                  // Row(
                                  //   children: [
                                  //     SizedBox(
                                  //       width: 10,
                                  //     ),
                                  //     Text(
                                  //       '${widget.properties.rentalCountry},',
                                  //       style: TextStyle(
                                  //         color: blueColor,
                                  //         fontSize:
                                  //             MediaQuery.of(context).size.width < 500
                                  //                 ? 13
                                  //                 : 18,
                                  //       ),
                                  //     ),
                                  //     SizedBox(width: 3),
                                  //     Text(
                                  //       '${widget.properties.rentalPostcode}',
                                  //       style: TextStyle(
                                  //         color: blueColor,
                                  //         fontSize:
                                  //             MediaQuery.of(context).size.width < 500
                                  //                 ? 13
                                  //                 : 18,
                                  //       ),
                                  //     ),
                                  //   ],
                                  // ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            const SizedBox(
                              width: 15,
                            ),
                            Container(
                              height: 30,
                              width: 90,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: blueColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                                onPressed: () async {
                                  _pickImage().then((_) {
                                    setState(
                                        () {}); // Rebuild the widget after selecting the image
                                  });
                                },
                                child: const Text(
                                  'Upload',
                                  style: TextStyle(color: Color(0xFFf7f8f9)),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                            if (_imageUrls.isNotEmpty ||
                                rentalDetails.rentalImage != '')
                              Container(
                                height: 30,
                                width: 100,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: blueColor,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                  onPressed: () async {
                                    _removeImage();
                                  },
                                  child: const Text(
                                    'Delete',
                                    style: TextStyle(color: Color(0xFFf7f8f9)),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    if (MediaQuery.of(context).size.width > 500)
                      const SizedBox(
                        width: 6,
                      ),
                    if (MediaQuery.of(context).size.width < 500)
                      const SizedBox(
                        width: 10,
                      ),
                    Text(
                      "Rental Owners",
                      style: TextStyle(
                          color: blueColor,
                          fontSize:
                              MediaQuery.of(context).size.width < 500 ? 16 : 20,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                if (MediaQuery.of(context).size.width > 500)
                  const SizedBox(height: 10),
                if (MediaQuery.of(context).size.width > 500)
                  const SizedBox(height: 5),
                if (MediaQuery.of(context).size.width < 500)
                  Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: FutureBuilder<List<Rentals>>(
                      future: futurerentalowners,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                              child: SpinKitFadingCircle(
                            color: Colors.black,
                            size: 40.0,
                          ));
                        } else if (snapshot.hasError) {
                          return Center(
                              child: Text('Error: ${snapshot.error}'));
                        } else if (!snapshot.hasData ||
                            snapshot.data!.isEmpty) {
                          return Container(
                            height: MediaQuery.of(context).size.height * .5,
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.asset(
                                    "assets/images/no_data.jpg",
                                    height: 200,
                                    width: 200,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "No Data Available",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor,
                                        fontSize: 16),
                                  )
                                ],
                              ),
                            ),
                          );
                        } else {
                          var data = snapshot.data!;
                          if (searchValuerent == null ||
                              searchValuerent!.isEmpty) {
                            data = snapshot.data!;
                          } else if (searchValuerent == "All") {
                            data = snapshot.data!;
                          } else if (searchValuerent!.isNotEmpty) {
                            data = snapshot.data!
                                .where((rentals) => rentals
                                    .rentalOwnerData!.rentalOwnerName!
                                    .toLowerCase()
                                    .contains(searchValuerent!.toLowerCase()))
                                .toList();
                          } else {
                            data = snapshot.data!
                                .where((rentals) =>
                                    rentals.rentalOwnerData!
                                        .rentalOwnerCompanyName! ==
                                    searchValuerent)
                                .toList();
                          }
                          data = data
                              .where((e) =>
                                  e.rentalId == widget.properties.rentalId)
                              .toList();
                          final totalPages =
                              (data.length / itemsPerPagerent).ceil();
                          final currentPageData = data
                              .skip(currentPagerent * itemsPerPagerent)
                              .take(itemsPerPagerent)
                              .toList();

                          print("currentpage data ${currentPageData.length}");
                          return SingleChildScrollView(
                            child: Column(
                              children: [
                                const SizedBox(height: 5),
                                //  _buildHeadersrent(),
                                // SizedBox(height: 20),
                                Container(
                                  child: Column(
                                    children: currentPageData
                                        .asMap()
                                        .entries
                                        .map((entry) {
                                      int index = entry.key;
                                      bool isExpanded = expandedIndex == index;
                                      Rentals rentals = entry.value;
                                      //return CustomExpansionTile(data: Propertytype, index: index);
                                      return Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFEAF1FB),
                                          borderRadius: BorderRadius.only(
                                            topLeft: const Radius.circular(16),
                                            topRight: const Radius.circular(16),
                                            bottomLeft: isExpanded
                                                ? Radius.zero
                                                : const Radius.circular(16),
                                            bottomRight: isExpanded
                                                ? Radius.zero
                                                : const Radius.circular(16),
                                          ),
                                          border: Border.all(
                                            color: const Color(
                                                0x4D636363), // Translucent gray border
                                            width: 1.0,
                                          ),
                                        ),
                                        child: Column(
                                          children: <Widget>[
                                            ListTile(
                                              contentPadding: EdgeInsets.zero,
                                              title: Padding(
                                                padding:
                                                    const EdgeInsets.all(2.0),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: <Widget>[
                                                    InkWell(
                                                      onTap: () {
                                                        // setState(() {
                                                        //    isExpanded = !isExpanded;
                                                        // //  expandedIndex = !expandedIndex;
                                                        //
                                                        // });
                                                        // setState(() {
                                                        //   if (isExpanded) {
                                                        //     expandedIndex = null;
                                                        //     isExpanded = !isExpanded;
                                                        //   } else {
                                                        //     expandedIndex = index;
                                                        //   }
                                                        // });
                                                        setState(() {
                                                          if (expandedIndex ==
                                                              index) {
                                                            expandedIndex =
                                                                null;
                                                          } else {
                                                            expandedIndex =
                                                                index;
                                                          }
                                                        });
                                                      },
                                                      child: Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 5, right: 5),
                                                        padding: !isExpanded
                                                            ? const EdgeInsets.only(
                                                                bottom: 10)
                                                            : const EdgeInsets.only(
                                                                top: 10),
                                                        child: FaIcon(
                                                          isExpanded
                                                              ? FontAwesomeIcons
                                                                  .sortUp
                                                              : FontAwesomeIcons
                                                                  .sortDown,
                                                          size: 20,
                                                          color: blueColor,
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 8),
                                                    Text(
                                                      'Rental Owner',
                                                      style: TextStyle(
                                                        color: blueColor,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 14,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            if (isExpanded)
                                              Container(
                                                width: double.infinity,
                                                decoration: const BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border(
                                                    top: BorderSide(
                                                      color: Color(0x4D636363),
                                                      width: 1.0,
                                                    ),
                                                  ),
                                                ),
                                                child: SingleChildScrollView(
                                                  child: Column(
                                                    children: [
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          FaIcon(
                                                            isExpanded
                                                                ? FontAwesomeIcons
                                                                    .sortUp
                                                                : FontAwesomeIcons
                                                                    .sortDown,
                                                            size: 50,
                                                            color: Colors
                                                                .transparent,
                                                          ),
                                                          Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <Widget>[
                                                                const SizedBox(
                                                                    height: 3),
                                                                SizedBox(
                                                                  height: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .height *
                                                                      .01,
                                                                ),
                                                                Text.rich(
                                                                  TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            'Rental Owner Name : ',
                                                                        style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color: blueColor),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            '\n${(rentals.rentalOwnerData?.rentalOwnerName ?? "").isEmpty ? 'N/A' : rentals.rentalOwnerData?.rentalOwnerName}',
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.w700,
                                                                            color: Colors.grey),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const SizedBox(
                                                                    height: 8),
                                                                Text.rich(
                                                                  TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            'Rental Company Name :',
                                                                        style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color: blueColor),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            '\n${(rentals.rentalOwnerData?.rentalOwnerCompanyName ?? "").isEmpty ? 'N/A' : rentals.rentalOwnerData?.rentalOwnerCompanyName}',
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.w700,
                                                                            color: Colors.grey),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const SizedBox(
                                                                    height: 8),
                                                                Text.rich(
                                                                  TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            'Owner E-Mail Address : ',
                                                                        style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color: blueColor), // Bold and black
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            '\n${(rentals.rentalOwnerData?.rentalOwnerPrimaryEmail ?? "").isEmpty ? 'N/A' : rentals.rentalOwnerData?.rentalOwnerPrimaryEmail}',
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.w700,
                                                                            color: Colors.grey), // Light and grey
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const SizedBox(
                                                                    height: 8),
                                                                Text.rich(
                                                                  TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            'Owner Phone Number : ',
                                                                        style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color: blueColor),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            "\n${formatPhoneNumber(rentals.rentalOwnerData?.rentalOwnerPhoneNumber ?? "N/A")}",
                                                                        style: const TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.w700,
                                                                            color: Colors.grey),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  height: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .height *
                                                                      .01,
                                                                ),
                                                                const SizedBox(
                                                                    height: 3),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            //SizedBox(height: 13,),
                                          ],
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ),
                                // SizedBox(height: 20),
                                // Row(
                                //   mainAxisAlignment: MainAxisAlignment.end,
                                //   children: [
                                //     Row(
                                //       children: [
                                //         // Text('Rows per page:'),
                                //         SizedBox(width: 10),
                                //         Material(
                                //           elevation: 3,
                                //           child: Container(
                                //             height: 40,
                                //             padding: EdgeInsets.symmetric(
                                //                 horizontal: 12.0),
                                //             decoration: BoxDecoration(
                                //               border: Border.all(
                                //                   color: Colors.grey),
                                //             ),
                                //             child: DropdownButtonHideUnderline(
                                //               child: DropdownButton<int>(
                                //                 value: itemsPerPagerent,
                                //                 items: itemsPerPageOptionsrent
                                //                     .map((int value) {
                                //                   return DropdownMenuItem<int>(
                                //                     value: value,
                                //                     child:
                                //                         Text(value.toString()),
                                //                   );
                                //                 }).toList(),
                                //                 onChanged: (newValue) {
                                //                   setState(() {
                                //                     itemsPerPagerent =
                                //                         newValue!;
                                //                     currentPagerent =
                                //                         0; // Reset to first page when items per page change
                                //                   });
                                //                 },
                                //               ),
                                //             ),
                                //           ),
                                //         ),
                                //       ],
                                //     ),
                                //     Row(
                                //       children: [
                                //         IconButton(
                                //           icon: FaIcon(
                                //             FontAwesomeIcons.circleChevronLeft,
                                //             color: currentPagerent == 0
                                //                 ? Colors.grey
                                //                 : blueColor,
                                //           ),
                                //           onPressed: currentPagerent == 0
                                //               ? null
                                //               : () {
                                //                   setState(() {
                                //                     currentPagerent--;
                                //                   });
                                //                 },
                                //         ),
                                //         // IconButton(
                                //         //   icon: Icon(Icons.arrow_back),
                                //         //   onPressed: currentPage > 0
                                //         //       ? () {
                                //         //     setState(() {
                                //         //       currentPage--;
                                //         //     });
                                //         //   }
                                //         //       : null,
                                //         // ),
                                //         Text(
                                //             'Page ${currentPagerent + 1} of $totalPages'),
                                //         // IconButton(
                                //         //   icon: Icon(Icons.arrow_forward),
                                //         //   onPressed: currentPage < totalPages - 1
                                //         //       ? () {
                                //         //     setState(() {
                                //         //       currentPage++;
                                //         //     });
                                //         //   }
                                //         //       : null,
                                //         // ),
                                //         IconButton(
                                //           icon: FaIcon(
                                //             FontAwesomeIcons.circleChevronRight,
                                //             color:
                                //                 currentPagerent < totalPages - 1
                                //                     ? blueColor
                                //                     : Colors.grey,
                                //           ),
                                //           onPressed:
                                //               currentPagerent < totalPages - 1
                                //                   ? () {
                                //                       setState(() {
                                //                         currentPagerent++;
                                //                       });
                                //                     }
                                //                   : null,
                                //         ),
                                //       ],
                                //     ),
                                //   ],
                                // ),
                              ],
                            ),
                          );
                        }
                      },
                    ),
                  ),
                if (MediaQuery.of(context).size.width > 500)
                  FutureBuilder<List<Rentals>>(
                    future: futurerentalowners,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                            child: SpinKitFadingCircle(
                          color: Colors.black,
                          size: 40.0,
                        ));
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Container(
                          height: MediaQuery.of(context).size.height * .5,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset(
                                  "assets/images/no_data.jpg",
                                  height: 200,
                                  width: 200,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "No Data Available",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: blueColor,
                                      fontSize: 16),
                                )
                              ],
                            ),
                          ),
                        );
                      } else {
                        List<Rentals>? filteredData = [];
                        _tableDatarent = snapshot.data!;
                        if (selectedRolerent == null && searchValuerent == "") {
                          filteredData = snapshot.data;
                        } else if (selectedRolerent == "All") {
                          filteredData = snapshot.data;
                        } else if (searchValuerent.isNotEmpty) {
                          filteredData = snapshot.data!
                              .where((staff) =>
                                  staff.rentalOwnerData!.rentalOwnerName!
                                      .toLowerCase()
                                      .contains(
                                          searchValuerent.toLowerCase()) ||
                                  staff.rentalOwnerData!.rentalOwnerPhoneNumber!
                                      .toLowerCase()
                                      .contains(searchValuerent.toLowerCase()))
                              .toList();
                        }

                        _tableDatarent = filteredData!;
                        totalrecordsrent = _tableDatarent.length;
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: Column(
                            children: [
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Container(
                                  // width: MediaQuery.of(context).size.width * .91,
                                  child: Table(
                                    defaultColumnWidth: const IntrinsicColumnWidth(),
                                    children: [
                                      TableRow(
                                        decoration:
                                            BoxDecoration(border: Border.all()),
                                        children: [
                                          _buildHeaderrent(
                                              'Contact Name',
                                              0,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerFirstName!),
                                          _buildHeaderrent(
                                              'Company Name',
                                              1,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerCompanyName!),
                                          _buildHeaderrent(
                                              'Email',
                                              2,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerPrimaryEmail!),
                                          _buildHeaderrent(
                                              'Phone Number',
                                              3,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerPhoneNumber!),
                                          _buildHeaderrent(
                                              'Home Number',
                                              4,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerHomeNumber!),
                                          _buildHeaderrent(
                                              'Business Number',
                                              5,
                                              (rental) => rental
                                                  .rentalOwnerData!
                                                  .rentalOwnerBuisinessNumber!),
                                        ],
                                      ),
                                      TableRow(
                                        decoration: const BoxDecoration(
                                          border: Border.symmetric(
                                              horizontal: BorderSide.none),
                                        ),
                                        children: List.generate(
                                            6,
                                            (index) => TableCell(
                                                child: Container(height: 20))),
                                      ),
                                      for (var i = 0;
                                          i < _pagedDatarent.length;
                                          i++)
                                        TableRow(
                                          decoration: BoxDecoration(
                                            border: Border(
                                              left: const BorderSide(
                                                  color: Color.fromRGBO(
                                                      21, 43, 81, 1)),
                                              right: const BorderSide(
                                                  color: Color.fromRGBO(
                                                      21, 43, 81, 1)),
                                              top: const BorderSide(
                                                  color: Color.fromRGBO(
                                                      21, 43, 81, 1)),
                                              bottom: i ==
                                                      _pagedDatarent.length - 1
                                                  ? BorderSide(color: blueColor)
                                                  : BorderSide.none,
                                            ),
                                          ),
                                          children: [
                                            _buildDataCellrent(
                                                '${_pagedDatarent[i].rentalOwnerData!.rentalOwnerName!}'),
                                            // _buildDataCell('${_pagedData[i].rentalOwnerFirstName ?? ''} ${_pagedData[i].rentalOwnerLastName ?? ''}'),
                                            _buildDataCellrent(
                                              _pagedDatarent[i]
                                                  .rentalOwnerData!
                                                  .rentalOwnerCompanyName!,
                                            ),
                                            _buildDataCellrent(_pagedDatarent[i]
                                                .rentalOwnerData!
                                                .rentalOwnerPrimaryEmail!),
                                            _buildDataCellrent(_pagedDatarent[i]
                                                .rentalOwnerData!
                                                .rentalOwnerPhoneNumber!),
                                            _buildDataCellrent(_pagedDatarent[i]
                                                .rentalOwnerData!
                                                .rentalOwnerHomeNumber!),
                                            _buildDataCellrent(_pagedDatarent[i]
                                                .rentalOwnerData!
                                                .rentalOwnerBuisinessNumber!),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                              if (_tableDatarent.isEmpty)
                                const Text("No Search Records Found"),
                              const SizedBox(height: 25),
                              _buildPaginationControlsrent(),
                            ],
                          ),
                        );
                      }
                    },
                  ),
                const SizedBox(
                  height: 10,
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(6.0),
                      child: Text(
                        "Purchase Information",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: blueColor,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 30,
                        width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: blueColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                          onPressed: () {
                            // Initialize with current values
                            // Get dateProvider to format the date according to user's preference
                            final dateProvider = Provider.of<DateProvider>(
                                context,
                                listen: false);
                            String purchaseDate =
                                rentalDetails.purchaseDate ?? '';
                            if (purchaseDate.isNotEmpty &&
                                purchaseDate != 'N/A') {
                              purchaseDateController.text =
                                  dateProvider.formatCurrentDate(purchaseDate);
                            } else {
                              purchaseDateController.text = '';
                            }
                            purchasePriceController.text =
                                rentalDetails.purchasePrice?.toString() ?? '';
                            parcelNumberController.text =
                                rentalDetails.parcelNumber ?? '';
                            selectedDate =
                                (rentalDetails.purchaseDate != null &&
                                        rentalDetails.purchaseDate != 'N/A' &&
                                        rentalDetails.purchaseDate!.isNotEmpty)
                                    ? DateTime.tryParse(
                                            rentalDetails.purchaseDate!) ??
                                        null
                                    : null;

                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return StatefulBuilder(
                                  builder: (context, setState) {
                                    return AlertDialog(
                                      title: Text(
                                        'Edit Purchase Information',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: blueColor),
                                      ),
                                      content: SingleChildScrollView(
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Purchase Date",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: blueColor),
                                            ),
                                            const SizedBox(height: 6),
                                            InkWell(
                                              onTap: () async {
                                                final DateTime? picked =
                                                    await showDatePicker(
                                                  context: context,
                                                  initialDate: selectedDate ??
                                                      DateTime.now(),
                                                  firstDate: DateTime(2000),
                                                  lastDate: DateTime(2100),
                                                      builder: (BuildContext context, Widget? child) {
                                                        return Theme(
                                                          data: ThemeData.light().copyWith(
                                                            primaryColor: blueColor, // Header background color
                                                            // accentColor: Colors.white, // Button text color
                                                            colorScheme: ColorScheme.light(
                                                              primary: blueColor, // Selection color
                                                              onPrimary: Colors.white, // Text color
                                                              surface: Colors.white, // Calendar background color
                                                              onSurface: Colors.black, // Calendar text color
                                                            ),
                                                            dialogBackgroundColor: Colors.white, // Background color
                                                          ),
                                                          child: child!,
                                                        );
                                                      },
                                                );
                                                if (picked != null) {
                                                  setState(() {
                                                    selectedDate = picked;
                                                    // Get dateProvider to format the date according to user's preference
                                                    final dateProvider =
                                                        Provider.of<
                                                                DateProvider>(
                                                            context,
                                                            listen: false);
                                                    // Display format: Use provider's format for user display
                                                    String apiFormatDate =
                                                        DateFormat('yyyy-MM-dd')
                                                            .format(picked);
                                                    purchaseDateController
                                                            .text =
                                                        dateProvider
                                                            .formatCurrentDate(
                                                                apiFormatDate);
                                                  });
                                                }
                                              },
                                              child: AbsorbPointer(
                                                child: TextField(
                                                  controller:
                                                      purchaseDateController,
                                                  decoration: InputDecoration(
                                                    hintText:
                                                        'Enter purchase date',
                                                    suffixIcon: const Icon(
                                                        Icons.calendar_today),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 16),
                                            Text(
                                              "Purchase Price",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: blueColor),
                                            ),
                                            const SizedBox(height: 6),
                                            TextField(
                                              controller:
                                                  purchasePriceController,
                                              keyboardType:
                                                  TextInputType.number,
                                              decoration: InputDecoration(
                                                hintText:
                                                    'Enter purchase price',
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 16),
                                            Text(
                                              "Parcel Number",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: blueColor),
                                            ),
                                            const SizedBox(height: 6),
                                            TextField(
                                              controller:
                                                  parcelNumberController,
                                              decoration: InputDecoration(
                                                hintText: 'Enter parcel number',
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          child: const Text('Cancel'),
                                        ),
                                        ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: blueColor,
                                          ),
                                          onPressed: () async {
                                            SharedPreferences prefs =
                                                await SharedPreferences
                                                    .getInstance();
                                            String? token =
                                                prefs.getString('token');
                                            String? id =
                                                prefs.getString('adminId');

                                            try {
                                              final response = await http.put(
                                                Uri.parse(
                                                    '${Api_url}/api/rentals/rental/${widget.properties.rentalId}/purchase_info'),
                                                headers: {
                                                  "authorization": "CRM $token",
                                                  "id": "CRM $id",
                                                  "Content-Type":
                                                      "application/json",
                                                },
                                                body: json.encode({
                                                  "purchase_date":
                                                      _convertToApiFormat(
                                                          purchaseDateController
                                                              .text),
                                                  "purchase_price": double.tryParse(
                                                          purchasePriceController
                                                              .text) ??
                                                      0,
                                                  "parcel_number":
                                                      parcelNumberController
                                                          .text,
                                                }),
                                              );

                                              if (response.statusCode == 200) {
                                                reload_Screen();
                                                Navigator.pop(context);
                                                Fluttertoast.showToast(
                                                  msg:
                                                      "Purchase information updated successfully",
                                                  toastLength:
                                                      Toast.LENGTH_LONG,
                                                );
                                                if (mounted) {
                                                  setState(() {
                                                    futureRentalDetails =
                                                        Properies_summery_Repo()
                                                            .fetchrentalDetails(
                                                                widget
                                                                    .properties
                                                                    .rentalId!);
                                                  });
                                                }
                                              } else {
                                                Fluttertoast.showToast(
                                                  msg:
                                                      "Failed to update purchase information",
                                                  toastLength:
                                                      Toast.LENGTH_LONG,
                                                );
                                              }
                                            } catch (e) {
                                              print(
                                                  'Error updating purchase info: $e');
                                              Fluttertoast.showToast(
                                                msg:
                                                    "Error updating purchase information",
                                                toastLength: Toast.LENGTH_LONG,
                                              );
                                            }
                                          },
                                          child: const Text(
                                            'Save',
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            );
                          },
                          child: const Text(
                            'Edit',
                            style: TextStyle(color: Color(0xFFf7f8f9)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Padding(
                  padding: const EdgeInsets.only(left: 6, right: 6),
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF4F8FF),
                      borderRadius:
                          BorderRadius.circular(16), // Increased corner radius
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                          16), // Ensure content inside respects corners
                      child: Table(
                        columnWidths: const {
                          0: FlexColumnWidth(2),
                          1: FlexColumnWidth(2),
                          2: FlexColumnWidth(2),
                        },
                        border: TableBorder(
                          horizontalInside:
                              BorderSide(color: Colors.grey.shade400, width: 1),
                          top: BorderSide.none,
                          bottom: BorderSide.none,
                          left: BorderSide.none,
                          right: BorderSide.none,
                        ),
                        children: [
                          // Header Row
                          TableRow(
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A2F5B).withOpacity(0.08),
                            ),
                            children: [
                              const Padding(
                                padding: EdgeInsets.all(12.0),
                                child: Text(
                                  "Purchase Date",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1A2F5B),
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.all(12.0),
                                child: Text(
                                  "Parcel Number #",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1A2F5B),
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.all(12.0),
                                child: Text(
                                  "Purchase Price",
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1A2F5B),
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          // Data Row
                          TableRow(
                            decoration: const BoxDecoration(
                              color: Colors.white,
                            ),
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  (rentalDetails.purchaseDate == null ||
                                          rentalDetails.purchaseDate!.isEmpty)
                                      ? "N/A"
                                      : dateProvider.formatCurrentDate(
                                          '${rentalDetails.purchaseDate!}'),
                                  style: const TextStyle(
                                      fontSize: 14, color: Colors.black),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  (rentalDetails.parcelNumber == null ||
                                          rentalDetails.parcelNumber!.isEmpty)
                                      ? "N/A"
                                      : rentalDetails.parcelNumber!,
                                  style: const TextStyle(
                                      fontSize: 14, color: Colors.black),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  (rentalDetails.purchasePrice == null ||
                                          rentalDetails.purchasePrice == 0)
                                      ? "N/A"
                                      : "\$${rentalDetails.purchasePrice!.toStringAsFixed(0)}",
                                  textAlign: TextAlign.right,
                                  style: const TextStyle(
                                      fontSize: 14, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (MediaQuery.of(context).size.width > 500)
                      const SizedBox(
                        width: 6,
                      ),
                    if (MediaQuery.of(context).size.width < 500)
                      const SizedBox(
                        width: 5,
                      ),
                    Text(
                      "Staff Details",
                      style: TextStyle(
                          color: blueColor,
                          fontSize:
                              MediaQuery.of(context).size.width < 500 ? 17 : 20,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF1FB),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft:
                          staffExpanded ? Radius.zero : const Radius.circular(16),
                      bottomRight:
                          staffExpanded ? Radius.zero : const Radius.circular(16),
                    ),
                    border: Border.all(
                      color: const Color(0x4D636363), // Translucent gray border
                      width: 1.0,
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    staffExpanded = !staffExpanded;
                                  });
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(left: 5, right: 5),
                                  padding: !staffExpanded
                                      ? const EdgeInsets.only(bottom: 10)
                                      : const EdgeInsets.only(top: 10),
                                  child: FaIcon(
                                    staffExpanded
                                        ? FontAwesomeIcons.sortUp
                                        : FontAwesomeIcons.sortDown,
                                    size: 20,
                                    color: blueColor,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Staff Details',
                                style: TextStyle(
                                  color: blueColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (staffExpanded)
                        Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            border: Border(
                              top: BorderSide(
                                color: Color(0x4D636363),
                                width: 1.0,
                              ),
                            ),
                          ),
                          child: SingleChildScrollView(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 25, right: 25, top: 10, bottom: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Staff Member',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    rentalDetails.staffMemberData
                                                    ?.staffmemberName !=
                                                null &&
                                            rentalDetails.staffMemberData!
                                                .staffmemberName!.isNotEmpty
                                        ? rentalDetails
                                            .staffMemberData!.staffmemberName!
                                        : 'N/A',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      //SizedBox(height: 13,),
                    ],
                  ),
                ),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: Container(
                //     decoration: BoxDecoration(
                //       color: const Color(0xFFF4F8FF),
                //       borderRadius: BorderRadius.circular(16),
                //       border: Border.all(color: Colors.grey.shade400),
                //     ),
                //     child: Column(
                //       children: [
                //         // Header Row
                //         InkWell(
                //           onTap: () {
                //             setState(() {
                //               staffExpanded = !staffExpanded;
                //             });
                //           },
                //           child: Container(
                //             padding: const EdgeInsets.symmetric(
                //                 horizontal: 16, vertical: 14),
                //             decoration: const BoxDecoration(
                //               borderRadius: BorderRadius.vertical(
                //                   top: Radius.circular(16)),
                //               color: Color(0xFFF4F8FF),
                //             ),
                //             child: Row(
                //               //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //               children: [
                //                 FaIcon(
                //                   staffExpanded
                //                       ? FontAwesomeIcons
                //                       .sortUp
                //                       : FontAwesomeIcons
                //                       .sortDown,
                //                   size: 20,
                //                   color: blueColor,
                //                 ),
                //
                //                 SizedBox(width: 13,),
                //                 Text(
                //                   'Staff Details',
                //                   style: TextStyle(
                //                     color: blueColor,
                //                     fontWeight:
                //                     FontWeight.bold,
                //                     fontSize: 14,
                //                   ),
                //                 ),
                //
                //               ],
                //             ),
                //           ),
                //         ),
                //
                //         if (staffExpanded)
                //             Container(
                //               width: double.infinity,
                //               decoration: const BoxDecoration(
                //                 color: Colors.white,
                //                 borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
                //               ),
                //               padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                //               child: Padding(
                //                 padding: const EdgeInsets.all(8.0),
                //                 child: Column(
                //                   crossAxisAlignment: CrossAxisAlignment.start,
                //                   children: [
                //                     Text(
                //                       'Staff Member',
                //                       style: TextStyle(
                //                           fontWeight:
                //                           FontWeight.bold,
                //                           color: blueColor),
                //                     ),
                //                     const SizedBox(height: 4),
                //                     Text(
                //                       rentalDetails.staffMemberData?.staffmemberName != null &&
                //                           rentalDetails.staffMemberData!.staffmemberName!.isNotEmpty
                //                           ? rentalDetails.staffMemberData!.staffmemberName!
                //                           : 'N/A',
                //                       style: TextStyle(
                //                           fontWeight:
                //                           FontWeight.w700,
                //                           color: Colors.grey),
                //                     ),
                //                   ],
                //                 ),
                //               ),
                //             ),
                //       ],
                //     ),
                //   ),
                // ),

                // Padding(
                //   padding: const EdgeInsets.only(left: 5, right: 5),
                //   child: Table(
                //     border: TableBorder.all(color: blueColor),
                //     children: [
                //       TableRow(
                //           decoration: BoxDecoration(
                //             color: blueColor,
                //             //  borderRadius: BorderRadius.circular(10),
                //           ),
                //           children: [
                //             TableCell(
                //               child: Padding(
                //                 padding: EdgeInsets.all(8.0),
                //                 child: Text(
                //                   'Staff Member',
                //                   style: TextStyle(
                //                       color: Colors.white,
                //                       fontSize:
                //                           MediaQuery.of(context).size.width <
                //                                   500
                //                               ? 16
                //                               : 19,
                //                       fontWeight: FontWeight.bold),
                //                 ),
                //               ),
                //             ),
                //           ]),
                //       TableRow(children: [
                //         TableCell(
                //           child: Padding(
                //             padding: const EdgeInsets.all(8.0),
                //             child: Text(
                //               rentalDetails.staffMemberData?.staffmemberName !=
                //                           null &&
                //                       rentalDetails.staffMemberData!
                //                           .staffmemberName!.isNotEmpty
                //                   ? '${rentalDetails.staffMemberData!.staffmemberName}'
                //                   : 'N/A',
                //               style: TextStyle(
                //                 fontSize:
                //                     MediaQuery.of(context).size.width < 500
                //                         ? 16
                //                         : 19,
                //               ),
                //             ),
                //           ),
                //         ),
                //       ])
                //     ],
                //   ),
                // ),
                const SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  bool recurringswith = false;
  Tenants(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        bool isTablet = constraints.maxWidth > 600;
        return FutureBuilder<List<TenantData>>(
          future: Properies_summery_Repo()
              .fetchPropertiessummery(widget.properties.rentalId!),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: SpinKitFadingCircle(
                  color: Colors.black,
                  size: 40.0,
                ),
              );
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              List<TenantData> tenants = snapshot.data ?? [];
              bool hasRecurringTenants =
                  tenants.any((tenant) => tenant!.recurring ?? false) ?? false;
              print(hasRecurringTenants);
              recurringswith = hasRecurringTenants;
              if (snapshot.data!.length == 0) {
                return Container(
                  height: MediaQuery.of(context).size.height * .5,
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/images/no_data.jpg",
                          height: 200,
                          width: 200,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(
                          "No Data Available",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: blueColor,
                              fontSize: 16),
                        )
                      ],
                    ),
                  ),
                );
              }

              return isTablet
                  ? SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                        padding: const EdgeInsets.only(
                          left: 35,
                          right: 35,
                          top: 30,
                        ),
                        child: Wrap(
                          alignment: WrapAlignment.start,
                          spacing: MediaQuery.of(context).size.width * 0.03,
                          runSpacing: MediaQuery.of(context).size.width * 0.035,
                          children: List.generate(
                            tenants.length,
                            (index) => Material(
                              elevation: 3,
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                height: 245,
                                width: MediaQuery.of(context).size.width * .44,
                                decoration: BoxDecoration(
                                  color:
                                      Colors.white, // Change as per your need
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: blueColor),
                                ),
                                child: buildTenantCard(tenants[index],
                                    tenants: tenants),
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  : SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        children: [
                          // if (tenants.length > 0)
                          //   Padding(
                          //     padding: const EdgeInsets.symmetric(
                          //         horizontal: 10.0, vertical: 5),
                          //     child: Row(
                          //       mainAxisAlignment: MainAxisAlignment.end,
                          //       children: [
                          //         Text("Enable Recurring Payments"),
                          //         Switch(
                          //           value: recurringswith,
                          //           onChanged: (value) async {
                          //             if (value == true) {
                          //               recurringCardDialog(tenants);
                          //             } else if (value == false) {
                          //               await tenant_cards()
                          //                   .disableCard(
                          //                       widget.properties.rentalId!)
                          //                   .then((element) {
                          //                 setState(() {
                          //                   recurringswith = value;
                          //                 });
                          //               });
                          //             }
                          //           },
                          //           activeColor: blueColor,
                          //         )
                          //       ],
                          //     ),
                          //   ),
                          const SizedBox(
                            height: 10,
                          ),
                          Wrap(
                            alignment: WrapAlignment.start,
                            spacing: MediaQuery.of(context).size.width * 0.03,
                            runSpacing:
                                MediaQuery.of(context).size.width * 0.02,
                            children: List.generate(tenants.length, (index) {
                              DateTime currentDate = DateTime.now();
                              DateTime moveoutDate;
                              bool? ismove = false;

                              if (snapshot.data![index].moveoutDate != null &&
                                  snapshot.data![index].moveoutDate! != "") {
                                moveoutDate = DateFormat('yyyy-MM-dd')
                                    .parse(snapshot.data![index].moveoutDate!);
                                ismove =
                                    moveoutDate.difference(currentDate).inDays <
                                        1;
                              }
                              return Padding(
                                padding: EdgeInsets.only(
                                  left: 20,
                                  right: 20,
                                  top: index == 0 ? 0 : 20,
                                ),
                                child: Material(
                                  elevation: 3,
                                  borderRadius: BorderRadius.circular(10),
                                  child: Container(
                                    //height: 230,
                                    //  width: MediaQuery.of(context).size.width * .44,
                                    decoration: BoxDecoration(
                                      color: Colors
                                          .white, // Change as per your need
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(color: blueColor),
                                    ),
                                    child: buildTenantCard(tenants[index],
                                        isMoveouts: (snapshot.data![index]
                                                        .moveoutDate ==
                                                    "" ||
                                                ismove == false)
                                            ? false
                                            : (snapshot.data![index]
                                                            .moveoutDate !=
                                                        "" &&
                                                    ismove)
                                                ? true
                                                : false,
                                        tenants: tenants),
                                  ),
                                ),
                              );
                            }),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    );
            }
          },
        );
      },
    );
  }

  List<String> tenantCardControllers = [];
  List<TextEditingController> amountControllers = [];

// Add this where you define the dialog.
  recurringCardDialog(List<TenantData> tenants) async {
    List<List<BillingData>>? billingDataList;
    List<String> tenant_card =
        List<String>.generate(tenants.length, (index) => '').toList();

    // Fetch the response to determine if credit or debit cards are accepted
    Map<String, Map<String, bool>> cardAcceptanceResponses = {};
    for (var tenant in tenants) {
      var response = await tenant_cards()
          .fetchCardAcceptance(tenant.tenantId!.first, tenant.leaseId!);
      cardAcceptanceResponses[tenant.tenantId!.first] = response;
    }

    // Initialize one row at the start.
    tenantCardControllers.add('');
    amountControllers.add(TextEditingController());

    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          child: Container(
            width: 999,
            height: 400,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  Text(
                    "Select Recurring Cards",
                    style: TextStyle(
                      color: blueColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Divider(
                    color: grey,
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: FutureBuilder<List<Map<String, dynamic>>>(
                      future: Future.wait(
                        tenants.map((tenant) async {
                          var paymentSettings =
                              await tenant_cards().fetchCardAcceptance(
                            tenant.tenantId!.first,
                            tenant.leaseId!,
                          );

                          bool creditAccepted =
                              paymentSettings['creditCardAccepted']!;
                          bool debitAccepted =
                              paymentSettings['debitCardAccepted']!;

                          // Fetch and filter cards based on payment settings.
                          var cards = await tenant_cards()
                              .fetchcreditcard(tenant.tenantId!.first);
                          var filteredCards = cards.where((card) {
                            if (creditAccepted && card.binResult == 'CREDIT')
                              return true;
                            if (debitAccepted && card.binResult == 'DEBIT')
                              return true;
                            return false;
                          }).toList();

                          // Return the tenant and their valid cards
                          return {'tenant': tenant, 'cards': filteredCards};
                        }).toList(),
                      ),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          List<Map<String, dynamic>> tenantsWithCards = snapshot
                              .data!
                              .where((entry) => entry['cards'].isNotEmpty)
                              .toList();

                          // If no tenants have valid cards, show a message
                          if (tenantsWithCards.isEmpty) {
                            return const Center(
                                child: Text('No tenants with valid cards.'));
                          }
                          List<List<BillingData>> Cardsdata = tenantsWithCards
                              .map((e) => e['cards'] as List<BillingData>)
                              .toList();

                          // Initialize the tenant card data in the provider
                          Provider.of<DropdownProvider>(context, listen: false)
                              .initializeTenantCard(tenantsWithCards
                                  .map((e) => e['cards'] as List<BillingData>)
                                  .toList());

                          return StatefulBuilder(
                            builder: (context, setState) {
                              return ListView.builder(
                                shrinkWrap: true,
                                physics: const ClampingScrollPhysics(),
                                itemCount: tenantCardControllers.length,
                                itemBuilder: (context, index) {
                                  TenantData tenantsdata =
                                      tenantsWithCards[index]["tenant"];
                                  String tenantId = tenantsdata.tenantId!.first;
                                  Map<String, bool> cardAcceptanceResponse =
                                      cardAcceptanceResponses[tenantId]!;

                                  List<BillingData> filteredCards =
                                      tenant_cards().filterCards(
                                    Cardsdata[index],
                                    cardAcceptanceResponse,
                                  );
                                  Provider.of<DropdownProvider>(context,
                                          listen: false)
                                      .initializeTenantCard(tenantsWithCards
                                          .map((e) =>
                                              e['cards'] as List<BillingData>)
                                          .toList());

                                  return Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "${tenantsdata.firstName} ${tenantsdata.lastName}",
                                          style: TextStyle(
                                            fontSize: 15,
                                            color: blueColor,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 5),
                                        Row(
                                          children: [
                                            Container(
                                              height: 45,
                                              decoration: BoxDecoration(
                                                border: Border.all(),
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                              ),
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 2),
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: DropdownButton<String>(
                                                  isExpanded: true,
                                                  //  value: , // Use ccNumber as selected value
                                                  // Custom display of the selected item:
                                                  selectedItemBuilder:
                                                      (BuildContext context) {
                                                    return filteredCards
                                                        .map((card) {
                                                      return Align(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        child: Text(
                                                          card.ccNumber!, // Only display ccNumber in selected state
                                                          style: const TextStyle(
                                                              fontSize: 16,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500),
                                                        ),
                                                      );
                                                    }).toList();
                                                  },
                                                  // Expanded dropdown list items:
                                                  items:
                                                      filteredCards.map((card) {
                                                    return DropdownMenuItem(
                                                      value: card
                                                          .ccNumber, // ccNumber remains the value
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            card.ccNumber!,
                                                            style: const TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold),
                                                          ),
                                                          Text(
                                                            card.binResult ??
                                                                '',
                                                            style: const TextStyle(
                                                                color: Colors
                                                                    .grey),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged:
                                                      (String? selectedCard) {
                                                    // if (selectedCard != null) {
                                                    //   provider.updateTenantCard(
                                                    //       index, selectedCard);
                                                    // }
                                                  },
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 15, right: 15),
                                                child: CustomTextField(
                                                  controller:
                                                      amountControllers[index],
                                                  validator: (value) {
                                                    if (value == null ||
                                                        value.isEmpty) {
                                                      return 'Please enter amount';
                                                    }
                                                    return null;
                                                  },
                                                  keyboardType:
                                                      TextInputType.number,
                                                  hintText: 'Enter Amount',
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        } else if (snapshot.hasError) {
                          return Text('Error: ${snapshot.error}');
                        } else {
                          return const Center(
                            child: SpinKitFadingCircle(
                              color: Colors.black,
                              size: 40.0,
                            ),
                          );
                        }
                      },
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        tenantCardControllers.add('');
                        amountControllers.add(TextEditingController());
                      });
                    },
                    child: Row(
                      children: [
                        const SizedBox(width: 15),
                        const Icon(Icons.add, color: Colors.green, size: 30),
                        const SizedBox(width: 6),
                        Text(
                          "Add Row",
                          style: TextStyle(
                            color: blueColor,
                            fontWeight: FontWeight.bold,
                            fontSize: MediaQuery.of(context).size.width < 500
                                ? 16
                                : 17,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          height: 45,
                          width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(color: blueColor),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Center(
                            child: Text(
                              "Cancel",
                              style: TextStyle(color: blueColor, fontSize: 16),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildTenantCard(TenantData tenant,
      {bool? isMoveouts, List<TenantData>? tenants}) {
    final dateProvider = Provider.of<DateProvider>(context);
    return Column(
      children: [
        const SizedBox(height: 10),
        Row(
          children: [
            const SizedBox(width: 15),
            Container(
              height: 30,
              width: 30,
              decoration: BoxDecoration(
                color: blueColor,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Center(
                child: FaIcon(
                  FontAwesomeIcons.user,
                  size: MediaQuery.of(context).size.width < 500 ? 16 : 20,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Row(
                  children: [
                    const SizedBox(width: 2),
                    Container(
                      width: 150,
                      child: Text(
                        '${tenant.firstName} ${tenant.lastName}',
                        style: TextStyle(
                          fontSize:
                              MediaQuery.of(context).size.width < 500 ? 16 : 19,
                          fontWeight: FontWeight.bold,
                          color: blueColor,
                        ),
                      ),
                    ),
                    const SizedBox(width: 2),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const SizedBox(width: 2),
                    Text(
                      dateProvider.formatCurrentDate('${tenant.endDate}'),
                      style: TextStyle(
                        fontSize:
                            MediaQuery.of(context).size.width < 500 ? 15 : 17,
                        color: const Color(0xFF8A95A8),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const Spacer(),
            if (tenant.moveoutDate == null)
              InkWell(
                onTap: () async {
                  // showDialog(
                  //   context: context,
                  //   builder: (BuildContext context) {
                  //     bool isChecked =
                  //         false; // Moved isChecked inside the StatefulBuilder
                  //     return StatefulBuilder(
                  //       builder: (BuildContext context, StateSetter setState) {
                  //         return Dialog(
                  //           backgroundColor: Colors.white,
                  //           surfaceTintColor: Colors.white,
                  //           shape: RoundedRectangleBorder(
                  //               borderRadius: BorderRadius.circular(10.0)),
                  //           child: Padding(
                  //             padding: const EdgeInsets.only(
                  //                 left: 16, right: 16, top: 10, bottom: 10),
                  //             child: Container(
                  //                 // width: MediaQuery.of(context).size.width - 10,
                  //                 width: 900,
                  //                 child: buildMoveout(tenant,tenants: tenants)),
                  //           ),
                  //         );
                  //       },
                  //     );
                  //   },
                  // );
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Moveout_properties(
                        properties: widget.properties,
                        moveOutDate: moveOutDate ?? "",
                        leaseId: widget.tenants?.leaseId ?? "",
                        tenant: tenant,
                        tenants: tenants ?? [],
                      ),
                    ),
                  );
                  if (result == true) {
                    setState(() {
                      futureUnitsummery = Properies_summery_Repo()
                          .fetchunit(widget.properties.rentalId ?? "");
                    });
                  }
                },
                child: Row(
                  children: [
                    FaIcon(
                      FontAwesomeIcons.rightFromBracket,
                      size: 17,
                      color: blueColor,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "Move out",
                      style: TextStyle(
                        fontSize:
                            MediaQuery.of(context).size.width < 500 ? 15 : 15,
                        fontWeight: FontWeight.w500,
                        color: blueColor,
                      ),
                    ),
                  ],
                ),
              ),
            // if (isMoveouts == true)
            if (tenant.moveoutDate != null)
              InkWell(
                onTap: () async {
                  print("calling movein");
                  String? tenantId =
                      tenant.tenantId != null && tenant.tenantId!.isNotEmpty
                          ? tenant.tenantId?.first
                          : null;
                  print(tenantId);
                  SharedPreferences prefs =
                      await SharedPreferences.getInstance();
                  String? id = prefs.getString("adminId");
                  LeaseMoveoutRepository()
                      .addMoveInTenant(
                    adminId: id!,
                    tenantId: tenantId,
                    leaseId: tenant.leaseId,
                  )
                      .then((value) {
                    setState(() {
                      futurePropertysummery = Properies_summery_Repo()
                          .fetchPropertiessummery(widget.properties.rentalId!);
                      isLoading = false;
                      isMovedOut = true;
                    });

                    Navigator.pop(context, true);
                  }).catchError((e) {
                    setState(() {
                      isLoading = false;
                    });
                  });
                },
                child: Row(
                  children: [
                    FaIcon(
                      FontAwesomeIcons.circleArrowLeft,
                      size: 17,
                      color: blueColor,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "Move In",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: blueColor,
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(width: 8),
          ],
        ),
        const SizedBox(height: 15),
        Row(
          children: [
            const SizedBox(width: 65),
            Text(
              '${dateProvider.formatCurrentDate('${tenant.startDate}')}  to',
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.width < 500 ? 15 : 16,
                color: blueColor,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 5),
            Text(
              '${dateProvider.formatCurrentDate('${tenant.endDate}')}',
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.width < 500 ? 15 : 16,
                color: blueColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const SizedBox(width: 65),
            FaIcon(
              FontAwesomeIcons.phone,
              size: 15,
              color: blueColor,
            ),
            const SizedBox(width: 5),
            Text(
              formatPhoneNumber(
                '${tenant.phoneNumber}',
              ),
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.width < 500 ? 15 : 16,
                color: blueColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const SizedBox(width: 65),
            FaIcon(
              FontAwesomeIcons.solidEnvelope,
              size: 15,
              color: blueColor,
            ),
            const SizedBox(width: 5),
            SizedBox(
              width: 230,
              child: Text(
                '${tenant.email}',
                maxLines: 2,
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width < 500 ? 15 : 16,
                  color: blueColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        if (tenant.moveoutDate != null) const SizedBox(height: 10),
        if (tenant.moveoutDate != null)
          Row(
            children: [
              const SizedBox(width: 65),
              Text(
                'Notice Date : ',
                maxLines: 3, // Set maximum number of lines
                overflow:
                    TextOverflow.ellipsis, // Handle overflow with ellipsis
                style: TextStyle(
                    fontSize: 15,
                    color: blueColor,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                formatDate('${tenant.moveoutNoticeGivenDate}'),
                style: TextStyle(
                  fontSize: 15,
                  color: blueColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        if (tenant.moveoutDate != null) const SizedBox(height: 8),
        if (tenant.moveoutDate != null)
          Row(
            children: [
              const SizedBox(width: 65),
              Text(
                'Move out : ',
                maxLines: 3, // Set maximum number of lines
                overflow:
                    TextOverflow.ellipsis, // Handle overflow with ellipsis
                style: TextStyle(
                    fontSize: 15,
                    color: blueColor,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                formatDate('${tenant.moveoutDate}'),
                style: TextStyle(
                  fontSize: 15,
                  color: blueColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget buildMoveout(TenantData tenant, {List<TenantData>? tenants}) {
    final dateProvider = Provider.of<DateProvider>(context, listen: false);
    moveOutDate = formatDate(tenant.endDate!);
    startdateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
    // Convert to stateful list to track selection changes
    Map<String, TextEditingController> startDateControllers = {};
    Map<String, TextEditingController> moveoutDateControllers = {};
    Map<String, String> moveOutDates = {};

    List<TenantData> selectedTenants = tenants ?? [];

    for (var t in selectedTenants!) {
      if (!startDateControllers.containsKey(t.tenantId)) {
        startDateControllers[t.tenantId!.first] = TextEditingController();
      }
      if (!moveoutDateControllers.containsKey(t.tenantId)) {
        moveoutDateControllers[t.tenantId!.first] = TextEditingController();
      }

      // Set default values for each tenant
      startDateControllers[t.tenantId!.first]!.text =
          DateFormat('yyyy-MM-dd').format(DateTime.now());
      moveoutDateControllers[t.tenantId!.first]!.text = formatDate(t.endDate!);

      // Set default selection
      t.isSelected = (t.tenantId == tenant.tenantId);
    }
    return StatefulBuilder(
      builder: (context, setState) {
        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Move out Tenants",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: blueColor,
                    fontSize:
                        MediaQuery.of(context).size.width < 500 ? 18 : 22),
              ),
              const SizedBox(height: 13),
              Text(
                "Select tenants to move out. If everyone is moving, the lease will end on the last move-out date. If some tenants are staying, you'll need to renew the lease. Note: Renters insurance policies will be permanently deleted upon move-out.",
                textAlign: TextAlign.justify,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: MediaQuery.of(context).size.width < 500 ? 14 : 18,
                  color: const Color(0xFF8A95A8),
                ),
              ),
              const SizedBox(height: 15),

              Column(
                children: [
                  Row(
                    children: [
                      Text(
                        'Property Details',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: MediaQuery.of(context).size.width < 500
                                ? 16
                                : 20,
                            color: blueColor),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: blueColor),
                    ),
                    child: Table(
                      //border: TableBorder.all(color:blueColor),
                      border: TableBorder(
                        horizontalInside: BorderSide(
                          color: blueColor,
                          width: 1.0,
                        ),
                      ),
                      columnWidths: {
                        0: const FlexColumnWidth(2),
                        1: const FlexColumnWidth(3),
                      },
                      children: [
                        TableRow(
                          children: [
                            buildTableCell(Text(
                              'Address/Unit',
                              style: TextStyle(
                                color: blueColor,
                                fontWeight: FontWeight.bold,
                                fontSize:
                                    MediaQuery.of(context).size.width < 500
                                        ? 15
                                        : 17,
                              ),
                            )),
                            buildTableCell(
                                Text('${widget.properties.rentalAddress}')),
                          ],
                        ),
                        TableRow(
                          children: [
                            buildTableCell(Text('Lease Type',
                                style: TextStyle(
                                  color: blueColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 15
                                          : 17,
                                ))),
                            buildTableCell(Text('${tenant.leaseType}')),
                          ],
                        ),
                        TableRow(
                          children: [
                            buildTableCell(Text('Start End',
                                style: TextStyle(
                                  color: blueColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 15
                                          : 17,
                                ))),
                            buildTableCell(Text(
                                '${tenant.startDate} to ${tenant.endDate}')),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    'Tenant Details',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize:
                            MediaQuery.of(context).size.width < 500 ? 16 : 20,
                        color: blueColor),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              // List of checkboxes for tenants
              Column(
                children: selectedTenants.map((tenant) {
                  return Column(
                    children: [
                      Container(
                        //color: Colors.green,
                        padding: const EdgeInsets.symmetric(vertical: 0.0),
                        child: Row(
                          children: [
                            Checkbox(
                              value: tenant.isSelected ?? false,
                              onChanged: (bool? value) {
                                setState(() {
                                  tenant.isSelected = value ?? false;
                                });
                              },
                            ),
                            const SizedBox(width: 8),
                            Text("${tenant.firstName} ${tenant.lastName}"),
                          ],
                        ),
                      ),
                      if (tenant.isSelected)
                        Table(
                          border: TableBorder.all(color: blueColor),
                          columnWidths: {
                            0: const FlexColumnWidth(2),
                            1: const FlexColumnWidth(3),
                          },
                          children: [
                            TableRow(
                              children: [
                                buildTableCell(Text('Tenants',
                                    style: TextStyle(
                                      color: blueColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          MediaQuery.of(context).size.width <
                                                  500
                                              ? 15
                                              : 17,
                                    ))),
                                buildTableCell(Text(
                                    '${tenant.firstName} ${tenant.lastName}')),
                              ],
                            ),
                            TableRow(
                              children: [
                                buildTableCell(Text('Notice Given Date',
                                    style: TextStyle(
                                      color: blueColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          MediaQuery.of(context).size.width <
                                                  500
                                              ? 15
                                              : 17,
                                    ))),
                                buildTableCell(buildDateField(
                                    startDateControllers[
                                        tenant.tenantId!.first]!)),
                              ],
                            ),
                            TableRow(
                              children: [
                                buildTableCell(Text('Move-Out Date',
                                    style: TextStyle(
                                      color: blueColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          MediaQuery.of(context).size.width <
                                                  500
                                              ? 15
                                              : 17,
                                    ))),
                                buildTableCell(buildDateField(
                                    moveoutDateControllers[
                                        tenant.tenantId!.first]!)),
                              ],
                            ),
                          ],
                        ),
                    ],
                  );
                }).toList(),
              ),

              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      // print(startDateControllers);
                      Navigator.pop(context);
                    },
                    child: Material(
                      elevation: 3,
                      borderRadius: const BorderRadius.all(Radius.circular(5)),
                      child: Container(
                        height:
                            MediaQuery.of(context).size.width < 500 ? 40 : 50,
                        width: 90,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                        ),
                        child: Center(
                            child: Text(
                          "Close",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: MediaQuery.of(context).size.width < 500
                                  ? 15
                                  : 18,
                              color: blueColor),
                        )),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  InkWell(
                    onTap: () async {
                      String? tenantId =
                          tenant.tenantId != null && tenant.tenantId!.isNotEmpty
                              ? tenant.tenantId!.first
                              : null;
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      String? id = prefs.getString("adminId");

                      List<Map<String, dynamic>> multipletenant = [];
                      for (tenant in selectedTenants) {
                        if (tenant.isSelected) {
                          String moveoutNoticeGivenDate =
                              startDateControllers[tenant.tenantId!.first]!
                                  .text;
                          String moveoutdate =
                              moveoutDateControllers[tenant.tenantId!.first]!
                                  .text;
                          multipletenant.add({
                            'admin_id': id,
                            'tenant_id': tenant.tenantId!.first,
                            'lease_id': tenant.leaseId,
                            'moveout_notice_given_date':
                                moveoutNoticeGivenDate!,
                            'moveout_date': moveoutdate!,
                          });
                        }
                      }
                      print(multipletenant);

                      await LeaseMoveoutRepository()
                          .addMoveoutTenant(
                              adminId: id!,
                              tenantId: tenantId,
                              leaseId: tenant.leaseId,
                              moveoutDate: moveOutDate,
                              moveoutNoticeGivenDate: startdateController.text,
                              multitenantdata: multipletenant)
                          .then((value) {
                        setState(() {
                          isLoading = false;
                          isMovedOut = true;
                        });
                        reload_Screen();
                        Navigator.pop(context, true);
                      }).catchError((e) {
                        setState(() {
                          isLoading = false;
                        });
                      });
                    },
                    child: Material(
                      elevation: 3,
                      borderRadius: const BorderRadius.all(Radius.circular(5)),
                      child: Container(
                        height:
                            MediaQuery.of(context).size.width < 500 ? 40 : 50,
                        width:
                            MediaQuery.of(context).size.width < 500 ? 100 : 130,
                        decoration: BoxDecoration(
                          color: blueColor,
                          borderRadius: const BorderRadius.all(Radius.circular(5)),
                        ),
                        child: Center(
                            child: Text(
                          "Move Out",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: MediaQuery.of(context).size.width < 500
                                ? 15
                                : 17,
                          ),
                        )),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 15),
            ],
          ),
        );
      },
    );
  }

  Widget buildTableCell(Widget child) {
    return TableCell(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: child,
      ),
    );
  }

  Widget buildDateField(TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(left: 5, right: 2),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: BorderRadius.circular(5),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.only(left: 5),
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Select Date',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                      builder: (BuildContext context, Widget? child) {
                        return Theme(
                          data: ThemeData.light().copyWith(
                            colorScheme: const ColorScheme.light(
                              primary: Color.fromRGBO(
                                  21, 43, 83, 1), // header background color
                              onPrimary: Colors.white, // header text color
                              onSurface: Color.fromRGBO(
                                  21, 43, 83, 1), // body text color
                            ),
                            textButtonTheme: TextButtonThemeData(
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: const Color.fromRGBO(
                                    21, 43, 83, 1), // button text color
                              ),
                            ),
                          ),
                          child: child!,
                        );
                      },
                    );
                    if (pickedDate != null) {
                      // setState(() {
                      controller.text = moveOutDate!;
                      controller.text =
                          DateFormat('dd-MM-yyyy').format(pickedDate);
                      //});
                    }
                  },
                ),
              ),
              readOnly: true,
            ),
          ),
        ),
      ),
    );
  }

// Add these helper functions to normalize and format values
  String formatBedValue(String value) {
    if (value.isEmpty) return '';
    if (!value.toLowerCase().contains('bed')) {
      return '$value Bed';
    }
    return value;
  }

  String formatBathValue(String value) {
    if (value.isEmpty) return '';
    if (!value.toLowerCase().contains('bath')) {
      return '$value Bath';
    }
    return value;
  }

// Create a dropdown widget that safely handles any value
  Widget buildSafeDropdown({
    required TextEditingController controller,
    required List<String> items,
    required String label,
    required Function(String?) onChanged,
    required bool isBed,
  }) {
    // Get the current value from controller
    String currentValue = controller.text;

    // Format the current value if needed
    if (currentValue.isNotEmpty) {
      currentValue =
          isBed ? formatBedValue(currentValue) : formatBathValue(currentValue);
    }

    // Create a list of items including the current value if it's not in the list
    List<String> dropdownItems = [...items];
    if (currentValue.isNotEmpty && !dropdownItems.contains(currentValue)) {
      dropdownItems.insert(0, currentValue);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Material(
          elevation: 3,
          borderRadius: BorderRadius.circular(3),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(3),
              border: Border.all(color: const Color(0xFF8A95A8)),
            ),
            child: DropdownButtonFormField<String>(
              value: currentValue.isEmpty ? null : currentValue,
              items: dropdownItems.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: onChanged,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(3),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(3),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(3),
                  borderSide: BorderSide.none,
                ),
              ),
              isExpanded: true,
              hint: Text('Select ${label}'),
            ),
          ),
        ),
      ],
    );
  }

  Unit_page(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            /*this for single unit*/
            if (!showdetails &&
                widget.properties.propertyTypeData!.isMultiunit! == false)
              FutureBuilder<List<unit_properties>>(
                future: Properies_summery_Repo()
                    .fetchunit(widget.properties.rentalId!),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: SpinKitFadingCircle(
                      color: Colors.black,
                      size: 40.0,
                    ));
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text('No data available'));
                  }
                  final data = snapshot.data!;
                  print('unit images ${widget.unit?.rentalImages!.first}');
                  String? imageUrl = widget.unit?.rentalImages?.isNotEmpty ??
                          false
                      ? "$image_url${widget.unit!.rentalImages!.first}"
                      : 'https://i.pinimg.com/originals/59/11/81/591181790b40c5e1f8cc04b55ebdbf25.jpg';
                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Container(
                            //height: screenHeight * 0.82,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12.0),
                              color: Colors.white,
                              border: Border.all(
                                color: blueColor,
                                width: 1,
                              ),
                            ),
                            child: Column(
                              // mainAxisAlignment: MainAxisAlignment.start,
                              // crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Container(
                                        height:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 36
                                                : 45,
                                        width:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 120
                                                : 150,
                                        child: ElevatedButton(
                                          onPressed: () {
                                            setState(() {
                                              sqft3.text = data[0].rentalsqft!;
                                              bath3.text = data[0].rentalbath!;
                                              bed3.text = data[0].rentalbed!;
                                              // Normalize the values to match available options
                                              normalizeBathValue();
                                              normalizeBedValue();
                                            });
                                            street3.text =
                                                data[0].rentalunitadress!;
                                            unitnum.text = data[0].rentalunit!;
                                            //_image = data[0].p;
                                            String? imageUrl = data[0]
                                                            .rentalImages !=
                                                        null &&
                                                    data[0]
                                                        .rentalImages!
                                                        .isNotEmpty
                                                ? "$image_url${data[0].rentalImages!.first}" // Assuming image_url is the base URL
                                                : null;
                                            if (widget
                                                        .properties
                                                        .propertyTypeData!
                                                        .isMultiunit! ==
                                                    false &&
                                                widget
                                                        .properties
                                                        .propertyTypeData!
                                                        .propertyType ==
                                                    'Residential') {
                                              showDialog(
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  bool isChecked =
                                                      false; // Moved isChecked inside the StatefulBuilder
                                                  return StatefulBuilder(
                                                    builder: (BuildContext
                                                            context,
                                                        StateSetter setState) {
                                                      return AlertDialog(
                                                        backgroundColor:
                                                            Colors.white,
                                                        surfaceTintColor:
                                                            Colors.white,
                                                        content:
                                                            SingleChildScrollView(
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  const Text(
                                                                    "Edit Unit Details",
                                                                    style:
                                                                        TextStyle(
                                                                      color: Color
                                                                          .fromRGBO(
                                                                              21,
                                                                              43,
                                                                              81,
                                                                              1),
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  ),
                                                                  const Spacer(),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () {
                                                                        Navigator.pop(
                                                                            context);
                                                                      },
                                                                      child: const Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              Colors.black),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    "SQFT",
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xFF8A95A8),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                            1),
                                                                child: Material(
                                                                  elevation: 3,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  child:
                                                                      TextFormField(
                                                                    controller:
                                                                        sqft3,
                                                                    cursorColor:
                                                                        Colors
                                                                            .black,
                                                                    decoration:
                                                                        InputDecoration(
                                                                      //  hintText: label,
                                                                      // labelText: label,
                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                      filled:
                                                                          true,
                                                                      fillColor:
                                                                          Colors
                                                                              .white,
                                                                      border:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide:
                                                                            BorderSide.none,
                                                                      ),
                                                                      enabledBorder:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide:
                                                                            const BorderSide(color: Color(0xFF8A95A8)),
                                                                      ),
                                                                      focusedBorder:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide: const BorderSide(
                                                                            color:
                                                                                Color(0xFF8A95A8),
                                                                            width: 2),
                                                                      ),
                                                                      contentPadding: const EdgeInsets
                                                                          .symmetric(
                                                                          vertical:
                                                                              10.0,
                                                                          horizontal:
                                                                              10.0),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    "bath",
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xFF8A95A8),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ],
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                            1),
                                                                child: Material(
                                                                  elevation: 3,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  child:
                                                                      Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            10),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .white,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              3),
                                                                      border: Border.all(
                                                                          color:
                                                                              const Color(0xFF8A95A8)),
                                                                    ),
                                                                    child:
                                                                        DropdownButtonHideUnderline(
                                                                      child: DropdownButton<
                                                                          String>(
                                                                        isExpanded:
                                                                            true,
                                                                        value: bath3.text.isNotEmpty
                                                                            ? bath3.text
                                                                            : null,
                                                                        hint: const Text(
                                                                            'Select Bath'),
                                                                        items: bathArray.map((String
                                                                            value) {
                                                                          return DropdownMenuItem<
                                                                              String>(
                                                                            value:
                                                                                value,
                                                                            child:
                                                                                Text(value),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged:
                                                                            (String?
                                                                                newValue) {
                                                                          setState(
                                                                              () {
                                                                            bath3.text =
                                                                                newValue ?? '';
                                                                          });
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    "bed",
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xFF8A95A8),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ],
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                            1),
                                                                child: Material(
                                                                  elevation: 3,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  child:
                                                                      Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            10),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .white,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              3),
                                                                      border: Border.all(
                                                                          color:
                                                                              const Color(0xFF8A95A8)),
                                                                    ),
                                                                    child:
                                                                        DropdownButtonHideUnderline(
                                                                      child: DropdownButton<
                                                                          String>(
                                                                        isExpanded:
                                                                            true,
                                                                        value: bed3.text.isNotEmpty
                                                                            ? bed3.text
                                                                            : null,
                                                                        hint: const Text(
                                                                            'Select Bed'),
                                                                        items: roomsArray.map((String
                                                                            value) {
                                                                          return DropdownMenuItem<
                                                                              String>(
                                                                            value:
                                                                                value,
                                                                            child:
                                                                                Text(value),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged:
                                                                            (String?
                                                                                newValue) {
                                                                          setState(
                                                                              () {
                                                                            bed3.text =
                                                                                newValue ?? '';
                                                                          });
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    'Photo',
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .black),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              Row(
                                                                children: [
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      _pickImage()
                                                                          .then(
                                                                              (_) {
                                                                        setState(
                                                                            () {}); // Rebuild the widget after selecting the image
                                                                      });
                                                                    },
                                                                    child:
                                                                        const Text(
                                                                      '+ Add',
                                                                      style: TextStyle(
                                                                          color:
                                                                              Colors.green),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              // _image != null
                                                              //     ? Column(
                                                              //         children: [
                                                              //           Image
                                                              //               .file(
                                                              //             _image!,
                                                              //             height:
                                                              //                 80,
                                                              //             width:
                                                              //                 80,
                                                              //             fit: BoxFit
                                                              //                 .cover,
                                                              //           ),
                                                              //           Text(_uploadedFileName ??
                                                              //               ""),
                                                              //         ],
                                                              //       )
                                                              //     : const Text(
                                                              //         ''),
                                                              _image != null
                                                                  ? Column(
                                                                      children: [
                                                                        Row(
                                                                          children: [
                                                                            Image.file(
                                                                              _image!,
                                                                              height: 80,
                                                                              width: 80,
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        // Text(_uploadedFileName ??
                                                                        //     ""),
                                                                      ],
                                                                    )
                                                                  : imageUrl !=
                                                                          null
                                                                      ? Column(
                                                                          children: [
                                                                            Row(
                                                                              children: [
                                                                                CachedNetworkImage(
                                                                                  imageUrl: imageUrl,
                                                                                  height: 80,
                                                                                  width: 80,
                                                                                  fit: BoxFit.cover,
                                                                                  placeholder: (context, url) => const CircularProgressIndicator(),
                                                                                  errorWidget: (context, url, error) => Image.asset(
                                                                                    "assets/images/no_image.jpg",
                                                                                    fit: BoxFit.fill,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                            const SizedBox(height: 8.0),
                                                                          ],
                                                                        )
                                                                      : const Text(
                                                                          'No image available'),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              Row(
                                                                children: [
                                                                  const SizedBox(
                                                                    width: 0,
                                                                  ),
                                                                  GestureDetector(
                                                                    onTap:
                                                                        () async {
                                                                      if (sqft3
                                                                          .text
                                                                          .isEmpty) {
                                                                        setState(
                                                                            () {
                                                                          iserror =
                                                                              true;
                                                                        });
                                                                      } else {
                                                                        setState(
                                                                            () {
                                                                          isLoading =
                                                                              true;
                                                                          iserror =
                                                                              false;
                                                                        });
                                                                        SharedPreferences
                                                                            prefs =
                                                                            await SharedPreferences.getInstance();

                                                                        String?
                                                                            id =
                                                                            prefs.getString("adminId");

                                                                        print(
                                                                            "Rental Images: $_uploadedFileNames");
                                                                        List<String>
                                                                            rentalImages =
                                                                            _uploadedFileNames ??
                                                                                [];
                                                                        Properies_summery_Repo()
                                                                            .Editunit(
                                                                          rentalImages:
                                                                              rentalImages,
                                                                          rentalsqft:
                                                                              sqft3.text,
                                                                          rentalunitadress:
                                                                              street3.text,
                                                                          rentalbath:
                                                                              bath3.text,
                                                                          rentalbed:
                                                                              bed3.text,
                                                                          //   unitId: unit?.unitId,
                                                                          unitId: data
                                                                              .first
                                                                              .unitId,
                                                                          adminId:
                                                                              id,
                                                                          //  rentalId: unit?.rentalId
                                                                          rentalId: data
                                                                              .first
                                                                              .rentalId,
                                                                        )
                                                                            .then((value) {
                                                                          setState(
                                                                              () {
                                                                            isLoading =
                                                                                false;
                                                                          });
                                                                          Navigator.of(context)
                                                                              .pop(true);
                                                                          reload_Screen();
                                                                        }).catchError((e) {
                                                                          setState(
                                                                              () {
                                                                            isLoading =
                                                                                false;
                                                                          });
                                                                        });
                                                                      }
                                                                    },
                                                                    child:
                                                                        Material(
                                                                      elevation:
                                                                          3,
                                                                      borderRadius:
                                                                          const BorderRadius
                                                                              .all(
                                                                        Radius.circular(
                                                                            5),
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        height:
                                                                            30,
                                                                        width:
                                                                            80,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              blueColor,
                                                                          borderRadius:
                                                                              const BorderRadius.all(
                                                                            Radius.circular(5),
                                                                          ),
                                                                        ),
                                                                        child: const Center(
                                                                            child: Text(
                                                                          "Save",
                                                                          style: TextStyle(
                                                                              fontWeight: FontWeight.w500,
                                                                              color: Colors.white),
                                                                        )),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  const SizedBox(
                                                                      width:
                                                                          10),
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                    },
                                                                    child:
                                                                        Material(
                                                                      elevation:
                                                                          3,
                                                                      borderRadius:
                                                                          const BorderRadius
                                                                              .all(
                                                                        Radius.circular(
                                                                            5),
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        height:
                                                                            30,
                                                                        width:
                                                                            80,
                                                                        decoration:
                                                                            const BoxDecoration(
                                                                          color:
                                                                              Colors.white,
                                                                          borderRadius:
                                                                              BorderRadius.all(
                                                                            Radius.circular(5),
                                                                          ),
                                                                        ),
                                                                        child: Center(
                                                                            child: Text(
                                                                          "Cancel",
                                                                          style: TextStyle(
                                                                              fontWeight: FontWeight.w500,
                                                                              color: blueColor),
                                                                        )),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              if (iserror)
                                                                const Text(
                                                                  "Please fill in all fields correctly.",
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .redAccent),
                                                                ),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  );
                                                },
                                              );
                                            }
                                            if (widget
                                                        .properties
                                                        .propertyTypeData!
                                                        .isMultiunit! ==
                                                    false &&
                                                widget
                                                        .properties
                                                        .propertyTypeData!
                                                        .propertyType ==
                                                    'Commercial') {
                                              showDialog(
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  bool isChecked =
                                                      false; // Moved isChecked inside the StatefulBuilder
                                                  return StatefulBuilder(
                                                    builder: (BuildContext
                                                            context,
                                                        StateSetter setState) {
                                                      return AlertDialog(
                                                        backgroundColor:
                                                            Colors.white,
                                                        surfaceTintColor:
                                                            Colors.white,
                                                        content:
                                                            SingleChildScrollView(
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  const Text(
                                                                    "Edit Unit Details",
                                                                    style:
                                                                        TextStyle(
                                                                      color: Color
                                                                          .fromRGBO(
                                                                              21,
                                                                              43,
                                                                              81,
                                                                              1),
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  ),
                                                                  const Spacer(),
                                                                  Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerRight,
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () {
                                                                        Navigator.pop(
                                                                            context);
                                                                      },
                                                                      child: const Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              Colors.black),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    "SQFT",
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xFF8A95A8),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ],
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                            1),
                                                                child: Material(
                                                                  elevation: 3,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  child:
                                                                      TextFormField(
                                                                    controller:
                                                                        sqft3,
                                                                    cursorColor:
                                                                        Colors
                                                                            .black,
                                                                    decoration:
                                                                        InputDecoration(
                                                                      //  hintText: label,
                                                                      // labelText: label,
                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                      filled:
                                                                          true,
                                                                      fillColor:
                                                                          Colors
                                                                              .white,
                                                                      border:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide:
                                                                            BorderSide.none,
                                                                      ),
                                                                      enabledBorder:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide:
                                                                            const BorderSide(color: Color(0xFF8A95A8)),
                                                                      ),
                                                                      focusedBorder:
                                                                          OutlineInputBorder(
                                                                        borderRadius:
                                                                            BorderRadius.circular(3),
                                                                        borderSide: const BorderSide(
                                                                            color:
                                                                                Color(0xFF8A95A8),
                                                                            width: 2),
                                                                      ),
                                                                      contentPadding: const EdgeInsets
                                                                          .symmetric(
                                                                          vertical:
                                                                              10.0,
                                                                          horizontal:
                                                                              10.0),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              const Row(
                                                                children: [
                                                                  Text(
                                                                    'Photo',
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .black),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              Row(
                                                                children: [
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      _pickImage()
                                                                          .then(
                                                                              (_) {
                                                                        setState(
                                                                            () {}); // Rebuild the widget after selecting the image
                                                                      });
                                                                    },
                                                                    child:
                                                                        const Text(
                                                                      '+ Add',
                                                                      style: TextStyle(
                                                                          color:
                                                                              Colors.green),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              // _image != null
                                                              //     ? Column(
                                                              //         children: [
                                                              //           Image
                                                              //               .file(
                                                              //             _image!,
                                                              //             height:
                                                              //                 80,
                                                              //             width:
                                                              //                 80,
                                                              //             fit: BoxFit
                                                              //                 .cover,
                                                              //           ),
                                                              //           Text(_uploadedFileName ??
                                                              //               ""),
                                                              //         ],
                                                              //       )
                                                              //     : const Text(
                                                              //         ''),
                                                              _image != null
                                                                  ? Column(
                                                                      children: [
                                                                        Row(
                                                                          children: [
                                                                            Image.file(
                                                                              _image!,
                                                                              height: 80,
                                                                              width: 80,
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        // Text(_uploadedFileName ??
                                                                        //     ""),
                                                                      ],
                                                                    )
                                                                  : imageUrl !=
                                                                          null
                                                                      ? Column(
                                                                          children: [
                                                                            Row(
                                                                              children: [
                                                                                CachedNetworkImage(
                                                                                  imageUrl: imageUrl,
                                                                                  height: 80,
                                                                                  width: 80,
                                                                                  fit: BoxFit.cover,
                                                                                  placeholder: (context, url) => const CircularProgressIndicator(),
                                                                                  errorWidget: (context, url, error) => Image.asset(
                                                                                    "assets/images/no_image.jpg",
                                                                                    fit: BoxFit.fill,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                            const SizedBox(height: 8.0),
                                                                          ],
                                                                        )
                                                                      : const Text(
                                                                          'No image available'),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              Row(
                                                                children: [
                                                                  const SizedBox(
                                                                    width: 0,
                                                                  ),
                                                                  GestureDetector(
                                                                    onTap:
                                                                        () async {
                                                                      if (sqft3
                                                                          .text
                                                                          .trim()
                                                                          .isEmpty) {
                                                                        setState(
                                                                            () {
                                                                          iserror =
                                                                              true;
                                                                        });
                                                                      } else {
                                                                        setState(
                                                                            () {
                                                                          isLoading =
                                                                              true;
                                                                          iserror =
                                                                              false;
                                                                        });
                                                                        SharedPreferences
                                                                            prefs =
                                                                            await SharedPreferences.getInstance();
                                                                        String?
                                                                            id =
                                                                            prefs.getString("adminId");
                                                                        List<String>
                                                                            rentalImages =
                                                                            _uploadedFileNames ??
                                                                                [];
                                                                        Properies_summery_Repo()
                                                                            .Editunit(
                                                                          rentalImages:
                                                                              rentalImages,
                                                                          rentalsqft:
                                                                              sqft3.text,
                                                                          unitId: data
                                                                              .first
                                                                              .unitId,
                                                                          rentalId: data
                                                                              .first
                                                                              .rentalId,
                                                                          adminId:
                                                                              id,
                                                                        )
                                                                            .then((value) {
                                                                          setState(
                                                                              () {
                                                                            isLoading =
                                                                                false;
                                                                          });

                                                                          Navigator.of(context)
                                                                              .pop(true);
                                                                          reload_Screen();
                                                                        }).catchError((e) {
                                                                          setState(
                                                                              () {
                                                                            isLoading =
                                                                                false;
                                                                          });
                                                                        });
                                                                      }
                                                                    },
                                                                    child:
                                                                        Material(
                                                                      elevation:
                                                                          3,
                                                                      borderRadius:
                                                                          const BorderRadius
                                                                              .all(
                                                                        Radius.circular(
                                                                            5),
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        height:
                                                                            30,
                                                                        width:
                                                                            80,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              blueColor,
                                                                          borderRadius:
                                                                              const BorderRadius.all(
                                                                            Radius.circular(5),
                                                                          ),
                                                                        ),
                                                                        child: const Center(
                                                                            child: Text(
                                                                          "Save",
                                                                          style: TextStyle(
                                                                              fontWeight: FontWeight.w500,
                                                                              color: Colors.white),
                                                                        )),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  const SizedBox(
                                                                      width:
                                                                          10),
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                    },
                                                                    child:
                                                                        Material(
                                                                      elevation:
                                                                          3,
                                                                      borderRadius:
                                                                          const BorderRadius
                                                                              .all(
                                                                        Radius.circular(
                                                                            5),
                                                                      ),
                                                                      child:
                                                                          Container(
                                                                        height:
                                                                            30,
                                                                        width:
                                                                            80,
                                                                        decoration:
                                                                            const BoxDecoration(
                                                                          color:
                                                                              Colors.white,
                                                                          borderRadius:
                                                                              BorderRadius.all(
                                                                            Radius.circular(5),
                                                                          ),
                                                                        ),
                                                                        child: Center(
                                                                            child: Text(
                                                                          "Cancel",
                                                                          style: TextStyle(
                                                                              fontWeight: FontWeight.w500,
                                                                              color: blueColor),
                                                                        )),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              const SizedBox(
                                                                  height: 8.0),
                                                              if (iserror)
                                                                const Text(
                                                                  "Please fill in all fields correctly.",
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .redAccent),
                                                                ),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  );
                                                },
                                              );
                                            }
                                          },
                                          child: Text(
                                            'Update unit',
                                            style: TextStyle(
                                                fontSize: MediaQuery.of(context)
                                                            .size
                                                            .width <
                                                        500
                                                    ? 13
                                                    : 18,
                                                color: Colors.white),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor: blueColor,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12.0))),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    const SizedBox(
                                      width: 15,
                                    ),
                                    SizedBox(
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                        child: CachedNetworkImage(
                                          imageUrl: data.first.rentalImages !=
                                                      null &&
                                                  data.first.rentalImages!
                                                      .isNotEmpty
                                              ? "$image_url${data.first.rentalImages?.first}"
                                              : 'assets/images/no_image.jpg',
                                          fit: BoxFit.cover,
                                          height: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 140
                                              : 220,
                                          width: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 160
                                              : 220,
                                          placeholder: (context, url) =>
                                              Shimmer.fromColors(
                                            baseColor: Colors.grey[300]!,
                                            highlightColor: Colors.grey[100]!,
                                            child: Container(
                                              color: Colors.grey[300],
                                              height: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 140
                                                  : 220,
                                              width: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 160
                                                  : 220,
                                            ),
                                          ),
                                          errorWidget: (context, url, error) =>
                                              Image.asset(
                                            "assets/images/no_image.jpg",
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Spacer(),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 16),
                                          child: Text(
                                            'ADDRESS',
                                            style: TextStyle(
                                                fontSize: MediaQuery.of(context)
                                                            .size
                                                            .width <
                                                        500
                                                    ? 14
                                                    : 20,
                                                color: Colors.grey[800],
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                      .size
                                                      .width >
                                                  500
                                              ? 200
                                              : 159,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 16),
                                            child: Text(
                                              '${widget.properties?.rentalAddress}',
                                              maxLines:
                                                  5, // Set maximum number of lines
                                              overflow: TextOverflow
                                                  .ellipsis, // Handle overflow with ellipsis
                                              style: TextStyle(
                                                fontSize: MediaQuery.of(context)
                                                            .size
                                                            .width <
                                                        500
                                                    ? 13
                                                    : 18,
                                                color: blueColor,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        SizedBox(
                                          width: MediaQuery.of(context)
                                                      .size
                                                      .width >
                                                  500
                                              ? 200
                                              : 159,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 16),
                                            child: Text(
                                              [
                                                widget.properties.rentalCity,
                                                widget.properties.rentalState,
                                                widget.properties.rentalCountry,
                                                widget
                                                    .properties.rentalPostcode,
                                              ]
                                                  .where((element) =>
                                                      element != null &&
                                                      element
                                                          .isNotEmpty) // Filter out null or empty elements
                                                  .map((element) =>
                                                      element!) // Ensure non-null elements
                                                  .join(' , '),
                                              style: TextStyle(
                                                color: blueColor,
                                                fontSize: MediaQuery.of(context)
                                                            .size
                                                            .width <
                                                        500
                                                    ? 13
                                                    : 18,
                                              ),
                                              maxLines: 6,
                                            ),
                                          ),
                                        ),
                                        // Padding(
                                        //   padding:
                                        //       const EdgeInsets.only(left: 16),
                                        //   child: Text(
                                        //     '${widget.properties?.rentalCity} ${widget.properties?.rentalState}',
                                        //     style: TextStyle(
                                        //         fontSize: MediaQuery.of(context)
                                        //                     .size
                                        //                     .width <
                                        //                 500
                                        //             ? 13
                                        //             : 18,
                                        //         color: Colors.grey[800]),
                                        //   ),
                                        // ),
                                        // SizedBox(
                                        //   height: 5,
                                        // ),
                                        // Padding(
                                        //   padding:
                                        //       const EdgeInsets.only(left: 14),
                                        //   child: Text(
                                        //     '${widget.properties?.rentalCountry} ${widget.properties?.rentalPostcode}',
                                        //     style: TextStyle(
                                        //         fontSize: MediaQuery.of(context)
                                        //                     .size
                                        //                     .width <
                                        //                 500
                                        //             ? 13
                                        //             : 18,
                                        //         color: Colors.grey[800]),
                                        //   ),
                                        // ),
                                      ],
                                    ),
                                    const Spacer(),
                                    if (MediaQuery.of(context).size.width > 500)
                                      Row(
                                        children: [
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          Container(
                                            width: 250,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(12.0),
                                              color: Colors.white,
                                              border: Border.all(
                                                color: blueColor,
                                                width: 1,
                                              ),
                                            ),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                SizedBox(
                                                  // width: double.infinity,
                                                  child: Text(
                                                    'Add Lease',
                                                    textAlign: TextAlign.start,
                                                    style: TextStyle(
                                                      fontSize:
                                                          MediaQuery.of(context)
                                                                      .size
                                                                      .width <
                                                                  500
                                                              ? 14
                                                              : 18,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: blueColor,
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Container(
                                                    height:
                                                        MediaQuery.of(context)
                                                                    .size
                                                                    .width <
                                                                500
                                                            ? 36
                                                            : 48,
                                                    // width: double.infinity,
                                                    child: ElevatedButton(
                                                      onPressed: () {},
                                                      child: Text(
                                                        '       Add Lease    ',
                                                        style: TextStyle(
                                                            fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width <
                                                                    500
                                                                ? 14
                                                                : 18,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor:
                                                              blueColor,
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10.0))),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(left: 10),
                                                  child: SizedBox(
                                                    //  width: double.infinity,
                                                    child: Text(
                                                      'Rental Applicant',
                                                      style: TextStyle(
                                                        fontSize: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width <
                                                                500
                                                            ? 14
                                                            : 18,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: blueColor,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Container(
                                                    height:
                                                        MediaQuery.of(context)
                                                                    .size
                                                                    .width <
                                                                500
                                                            ? 36
                                                            : 48,
                                                    //  width: double.infinity,
                                                    child: ElevatedButton(
                                                      onPressed: () {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        Applicants_table()));
                                                      },
                                                      child: Text(
                                                        'Create Applicant',
                                                        style: TextStyle(
                                                            fontSize: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width <
                                                                    500
                                                                ? 14
                                                                : 18,
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor:
                                                              blueColor,
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10.0))),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 20,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    const SizedBox(
                                      width: 15,
                                    ),
                                  ],
                                ),
                                if (MediaQuery.of(context).size.width < 500)
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Container(
                                      // height: screenHeight * 0.26,
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                        color: Colors.white,
                                        border: Border.all(
                                          color: const Color.fromRGBO(
                                              21, 43, 83, 1),
                                          width: 1,
                                        ),
                                      ),
                                      child: Column(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                'Add Lease',
                                                style: TextStyle(
                                                  fontSize:
                                                      MediaQuery.of(context)
                                                                  .size
                                                                  .width <
                                                              500
                                                          ? 14
                                                          : 18,
                                                  fontWeight: FontWeight.bold,
                                                  color: blueColor,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Container(
                                              height: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 36
                                                  : 48,
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  Provider.of<SelectedTenantsProvider>(
                                                          context,
                                                          listen: false)
                                                      .clearTenant();
                                                  Provider.of<SelectedCosignersProvider>(
                                                          context,
                                                          listen: false)
                                                      .clearCosigner();
                                                  Navigator.of(context).push(
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              addLease3(
                                                                rentalId: widget
                                                                    .properties
                                                                    .rentalId,
                                                              )));
                                                },
                                                child: Text(
                                                  'Add Lease',
                                                  style: TextStyle(
                                                      fontSize:
                                                          MediaQuery.of(context)
                                                                      .size
                                                                      .width <
                                                                  500
                                                              ? 14
                                                              : 18,
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor: blueColor,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0))),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: SizedBox(
                                              width: double.infinity,
                                              child: Text(
                                                'Rental Applicant',
                                                style: TextStyle(
                                                  fontSize:
                                                      MediaQuery.of(context)
                                                                  .size
                                                                  .width <
                                                              500
                                                          ? 14
                                                          : 18,
                                                  fontWeight: FontWeight.bold,
                                                  color: blueColor,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Container(
                                              height: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 36
                                                  : 48,
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              Applicants_table()));
                                                },
                                                child: Text(
                                                  'Create Applicant',
                                                  style: TextStyle(
                                                      fontSize:
                                                          MediaQuery.of(context)
                                                                      .size
                                                                      .width <
                                                                  500
                                                              ? 14
                                                              : 18,
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor: blueColor,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0))),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                if (MediaQuery.of(context).size.width > 500)
                                  const SizedBox(
                                    height: 20,
                                  ),
                              ],
                            ),
                          ),
                        ),
                        // LeasesTable(unit: widget.unit),
                        LeasesTable(
                          unit: data.first,
                        ),
                        // AppliancesPart(
                        //   unit: widget.unit,
                        // ),

                        AppliancesPart(
                          unit: data.first,
                        ),
                      ],
                    ),
                  );
                },
              ),
            //this for add ubit button
            if (widget.properties.propertyTypeData!.isMultiunit!)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      unitnum.clear();
                      street3.clear();
                      sqft3.clear();
                      bath3.clear();
                      bed3.clear();
                      _imageUrls.clear();

                      if (widget.properties.propertyTypeData!.isMultiunit! &&
                          widget.properties.propertyTypeData!.propertyType ==
                              'Residential') {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            bool isChecked =
                                false; // Moved isChecked inside the StatefulBuilder
                            return StatefulBuilder(
                              builder:
                                  (BuildContext context, StateSetter setState) {
                                return AlertDialog(
                                  backgroundColor: Colors.white,
                                  surfaceTintColor: Colors.white,
                                  content: SingleChildScrollView(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              "Add Unit Details",
                                              style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const Spacer(),
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: InkWell(
                                                onTap: () {
                                                  Navigator.pop(context);
                                                },
                                                child: const Icon(Icons.close,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Unit Number *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: unitnum,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Street Address *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: street3,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "SQFT *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: sqft3,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Bath",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 10),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                border: Border.all(
                                                    color: const Color(0xFF8A95A8)),
                                              ),
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: DropdownButton<String>(
                                                  isExpanded: true,
                                                  value: bathArray
                                                          .contains(bath3.text)
                                                      ? bath3.text
                                                      : null,
                                                  hint: const Text('Select Bath'),
                                                  items: bathArray
                                                      .map((String value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value,
                                                      child: Text(value),
                                                    );
                                                  }).toList(),
                                                  onChanged:
                                                      (String? newValue) {
                                                    setState(() {
                                                      bath3.text =
                                                          newValue ?? '';
                                                    });
                                                  },
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Bed",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: Container(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 10),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                border: Border.all(
                                                    color: const Color(0xFF8A95A8)),
                                              ),
                                              child:
                                                  DropdownButtonHideUnderline(
                                                child: DropdownButton<String>(
                                                  isExpanded: true,
                                                  value: roomsArray
                                                          .contains(bed3.text)
                                                      ? bed3.text
                                                      : null,
                                                  hint: const Text('Select Bed'),
                                                  items: roomsArray
                                                      .map((String value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value,
                                                      child: Text(value),
                                                    );
                                                  }).toList(),
                                                  onChanged:
                                                      (String? newValue) {
                                                    setState(() {
                                                      bed3.text =
                                                          newValue ?? '';
                                                    });
                                                  },
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              'Photo',
                                              style: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8.0),
                                        if (_images.isEmpty)
                                          Row(
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  _pickImage().then((_) {
                                                    setState(
                                                        () {}); // Rebuild the widget after selecting the image
                                                  });
                                                },
                                                child: const Text(
                                                  '+ Add',
                                                  style: TextStyle(
                                                      color: Colors.green),
                                                ),
                                              ),
                                            ],
                                          ),
                                        if (_images.isEmpty)
                                          const SizedBox(
                                            height: 10,
                                          ),
                                        _images.isNotEmpty
                                            ? Row(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      //color: Colors.blue,
                                                      child: Wrap(
                                                        spacing:
                                                            8.0, // Horizontal spacing between items
                                                        runSpacing:
                                                            8.0, // Vertical spacing between rows
                                                        children: List.generate(
                                                          _images.length,
                                                          (index) {
                                                            return Container(
                                                              // color: Colors.green,
                                                              width: 85,
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Row(
                                                                    children: [
                                                                      const SizedBox(
                                                                        width:
                                                                            60,
                                                                      ),
                                                                      GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          setState(
                                                                              () {
                                                                            _images.removeAt(index);
                                                                          });
                                                                        },
                                                                        child:
                                                                            const Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              Colors.grey,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Container(
                                                                        // color:Colors.blue,
                                                                        child: Image
                                                                            .file(
                                                                          _images[
                                                                              index],
                                                                          height:
                                                                              80,
                                                                          width:
                                                                              80,
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : const Center(
                                                child:
                                                    Text("No images selected."),
                                              ),
                                        const SizedBox(height: 8.0),
                                        Row(
                                          children: [
                                            const SizedBox(
                                              width: 0,
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                if (_uploadedFileNames.length !=
                                                    _images.length)
                                                  await _uploadAllImages();
                                                if (unitnum.text.trim().isEmpty ||
                                                    street3.text
                                                        .trim()
                                                        .isEmpty ||
                                                    sqft3.text.trim().isEmpty) {
                                                  setState(() {
                                                    iserror = true;
                                                  });
                                                } else {
                                                  setState(() {
                                                    isLoading = true;
                                                    iserror = false;
                                                  });
                                                  SharedPreferences prefs =
                                                      await SharedPreferences
                                                          .getInstance();
                                                  String? id = prefs
                                                      .getString("adminId");
                                                  Properies_summery_Repo()
                                                      .addUnit(
                                                          adminId: id!,
                                                          rentalId: widget
                                                              .properties
                                                              .rentalId,
                                                          rentalunit: unitnum
                                                              .text
                                                              .trim(),
                                                          rentalunitadress:
                                                              street3.text
                                                                  .trim(),
                                                          rentalsqft:
                                                              sqft3.text.trim(),
                                                          rentalbath:
                                                              bath3.text.trim(),
                                                          rentalbed:
                                                              bed3.text.trim(),
                                                          rentalImages:
                                                              _uploadedFileNames!)
                                                      .then((value) async {
                                                    setState(() {
                                                      futureUnitsummery =
                                                          Properies_summery_Repo()
                                                              .fetchunit(widget
                                                                      .properties
                                                                      .rentalId ??
                                                                  "");
                                                      isLoading = false;
                                                      data.add(unit_properties(
                                                          adminId: id!,
                                                          rentalId: widget
                                                              .properties
                                                              .rentalId,
                                                          rentalunit: unitnum
                                                              .text
                                                              .trim(),
                                                          rentalunitadress:
                                                              street3.text
                                                                  .trim(),
                                                          rentalsqft:
                                                              sqft3.text.trim(),
                                                          rentalbath:
                                                              bath3.text.trim(),
                                                          rentalbed:
                                                              bed3.text.trim(),
                                                          rentalImages:
                                                              _uploadedFileNames!));
                                                      // Update unit count
                                                      unitCount = data.length;
                                                    });
                                                    reload_Screen();
                                                    Navigator.pop(
                                                        context, true);
                                                  }).catchError((e) {
                                                    setState(() {
                                                      isLoading = false;
                                                    });
                                                  });
                                                }
                                              },
                                              child: Material(
                                                elevation: 3,
                                                borderRadius: const BorderRadius.all(
                                                  Radius.circular(5),
                                                ),
                                                child: Container(
                                                  height: 30,
                                                  width: 80,
                                                  decoration: BoxDecoration(
                                                    color: blueColor,
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                      Radius.circular(5),
                                                    ),
                                                  ),
                                                  child: const Center(
                                                      child: Text(
                                                    "Save",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: Colors.white),
                                                  )),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            GestureDetector(
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                              child: Material(
                                                elevation: 3,
                                                borderRadius: const BorderRadius.all(
                                                  Radius.circular(5),
                                                ),
                                                child: Container(
                                                  height: 30,
                                                  width: 80,
                                                  decoration: const BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.all(
                                                      Radius.circular(5),
                                                    ),
                                                  ),
                                                  child: Center(
                                                      child: Text(
                                                    "Cancel",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: blueColor),
                                                  )),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8.0),
                                        if (iserror)
                                          const Text(
                                            "Please fill in all fields correctly.",
                                            style: TextStyle(
                                                color: Colors.redAccent),
                                          ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        );
                      }
                      if (widget.properties.propertyTypeData!.isMultiunit! &&
                          widget.properties.propertyTypeData!.propertyType ==
                              'Commercial') {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            bool isChecked =
                                false; // Moved isChecked inside the StatefulBuilder
                            return StatefulBuilder(
                              builder:
                                  (BuildContext context, StateSetter setState) {
                                return AlertDialog(
                                  backgroundColor: Colors.white,
                                  surfaceTintColor: Colors.white,
                                  content: SingleChildScrollView(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              "Add Unit Details",
                                              style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const Spacer(),
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: InkWell(
                                                onTap: () {
                                                  Navigator.pop(context);
                                                },
                                                child: const Icon(Icons.close,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Unit Number *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: unitnum,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "Street Address *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: street3,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              "SQFT *",
                                              style: TextStyle(
                                                  color: Color(0xFF8A95A8),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 1),
                                          child: Material(
                                            elevation: 3,
                                            borderRadius:
                                                BorderRadius.circular(3),
                                            child: TextFormField(
                                              controller: sqft3,
                                              cursorColor: Colors.black,
                                              decoration: InputDecoration(
                                                //  hintText: label,
                                                // labelText: label,
                                                // labelStyle: TextStyle(color: Colors.grey[700]),
                                                filled: true,
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: BorderSide.none,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8)),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  borderSide: const BorderSide(
                                                      color: Color(0xFF8A95A8),
                                                      width: 2),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 10.0,
                                                        horizontal: 10.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Row(
                                          children: [
                                            Text(
                                              'Photo',
                                              style: TextStyle(
                                                  color: Colors.black),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8.0),
                                        if (_images.isEmpty)
                                          Row(
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  _pickImage().then((_) {
                                                    setState(
                                                        () {}); // Rebuild the widget after selecting the image
                                                  });
                                                },
                                                child: const Text(
                                                  '+ Add',
                                                  style: TextStyle(
                                                      color: Colors.green),
                                                ),
                                              ),
                                            ],
                                          ),
                                        if (_images.isEmpty)
                                          const SizedBox(height: 8.0),
                                        _images.isNotEmpty
                                            ? Row(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      //color: Colors.blue,
                                                      child: Wrap(
                                                        spacing:
                                                            8.0, // Horizontal spacing between items
                                                        runSpacing:
                                                            8.0, // Vertical spacing between rows
                                                        children: List.generate(
                                                          _images.length,
                                                          (index) {
                                                            return Container(
                                                              // color: Colors.green,
                                                              width: 85,
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Row(
                                                                    children: [
                                                                      const SizedBox(
                                                                        width:
                                                                            60,
                                                                      ),
                                                                      GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          setState(
                                                                              () {
                                                                            _images.removeAt(index);
                                                                          });
                                                                        },
                                                                        child:
                                                                            const Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              Colors.grey,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Container(
                                                                        // color:Colors.blue,
                                                                        child: Image
                                                                            .file(
                                                                          _images[
                                                                              index],
                                                                          height:
                                                                              80,
                                                                          width:
                                                                              80,
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : const Center(
                                                child:
                                                    Text("No images selected."),
                                              ),
                                        const SizedBox(height: 8.0),
                                        Row(
                                          children: [
                                            const SizedBox(
                                              width: 0,
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                if (_uploadedFileNames.length !=
                                                    _images.length)
                                                  await _uploadAllImages();
                                                if (unitnum.text.trim().isEmpty ||
                                                    street3.text
                                                        .trim()
                                                        .isEmpty ||
                                                    sqft3.text.trim().isEmpty) {
                                                  setState(() {
                                                    iserror = true;
                                                  });
                                                } else {
                                                  print("unit calling");
                                                  setState(() {
                                                    isLoading = true;
                                                    iserror = false;
                                                  });

                                                  SharedPreferences prefs =
                                                      await SharedPreferences
                                                          .getInstance();
                                                  String? id = prefs
                                                      .getString("adminId");
                                                  Properies_summery_Repo()
                                                      .addUnit(
                                                          adminId: id!,
                                                          rentalId: widget
                                                              .properties
                                                              .rentalId,
                                                          rentalunitadress:
                                                              street3.text
                                                                  .trim(),
                                                          rentalsqft:
                                                              sqft3.text.trim(),
                                                          rentalunit: unitnum
                                                              .text
                                                              .trim(),
                                                          rentalImages:
                                                              _uploadedFileNames!)
                                                      .then((value) {
                                                    print(
                                                        "valuesss....${value}");
                                                    setState(() {
                                                      isLoading = false;
                                                      data.add(unit_properties(
                                                        adminId: id!,
                                                        rentalId: widget
                                                            .properties
                                                            .rentalId,
                                                        rentalunitadress:
                                                            street3.text.trim(),
                                                        rentalsqft:
                                                            sqft3.text.trim(),
                                                        rentalunit:
                                                            unitnum.text.trim(),
                                                      ));
                                                      // Update unit count
                                                      unitCount = data.length;
                                                    });
                                                    reload_Screen();
                                                    Navigator.pop(
                                                        context, true);
                                                  }).catchError((e) {
                                                    setState(() {
                                                      isLoading = false;
                                                    });
                                                  });
                                                }
                                                print("calling.............");
                                              },
                                              child: Material(
                                                elevation: 3,
                                                borderRadius: const BorderRadius.all(
                                                  Radius.circular(5),
                                                ),
                                                child: Container(
                                                  height: 30,
                                                  width: 80,
                                                  decoration: BoxDecoration(
                                                    color: blueColor,
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                      Radius.circular(5),
                                                    ),
                                                  ),
                                                  child: const Center(
                                                      child: Text(
                                                    "Save",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: Colors.white),
                                                  )),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            GestureDetector(
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                              child: Material(
                                                elevation: 3,
                                                borderRadius: const BorderRadius.all(
                                                  Radius.circular(5),
                                                ),
                                                child: Container(
                                                  height: 30,
                                                  width: 80,
                                                  decoration: const BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.all(
                                                      Radius.circular(5),
                                                    ),
                                                  ),
                                                  child: Center(
                                                      child: Text(
                                                    "Cancel",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: blueColor),
                                                  )),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8.0),
                                        if (iserror)
                                          const Text(
                                            "Please fill in all fields correctly.",
                                            style: TextStyle(
                                                color: Colors.redAccent),
                                          ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        );
                      }
                    },
                    child: Material(
                      elevation: 3,
                      borderRadius: const BorderRadius.all(
                        Radius.circular(5),
                      ),
                      child: Container(
                        height: 35,
                        width: 95,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: const BorderRadius.all(
                            Radius.circular(5),
                          ),
                          border: Border.all(
                            color: blueColor,
                          ),
                        ),
                        child: Center(
                            child: Text(
                          "Add Unit",
                          style: TextStyle(
                              fontWeight: FontWeight.w500, color: blueColor),
                        )),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                ],
              ),

            //and this is mutiunit table show this is as it is
            if (!showdetails &&
                widget.properties.propertyTypeData!.isMultiunit!)
              if (MediaQuery.of(context).size.width < 500)
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: FutureBuilder<List<unit_properties>>(
                    future: futureUnitsummery,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                            child: SpinKitFadingCircle(
                          color: Colors.black,
                          size: 40.0,
                        ));
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Container(
                          height: MediaQuery.of(context).size.height * .5,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset(
                                  "assets/images/no_data.jpg",
                                  height: 200,
                                  width: 200,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "No Data Available",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: blueColor,
                                      fontSize: 16),
                                )
                              ],
                            ),
                          ),
                        );
                      } else {
                        print("data update...");
                        var data = snapshot.data!;
                        if (selectedValue == null && searchvalue!.isEmpty) {
                          data = snapshot.data!;
                        } else if (selectedValue == "All") {
                          data = snapshot.data!;
                        } else if (searchvalue!.isNotEmpty) {
                          data = snapshot.data!;
                        }
                        // sortData(data);
                        //countupdateunit(data.length);
                        final totalPages =
                            (data.length / itemsPerPagemulti).ceil();
                        final currentPageData = data
                            .skip(currentPagemulti * itemsPerPagemulti)
                            .take(itemsPerPagemulti)
                            .toList();
                        return SingleChildScrollView(
                          child: Column(
                            children: [
                              const SizedBox(height: 20),
                              _buildHeadersmulti(),
                              const SizedBox(height: 10),
                              Container(
                                child: Column(
                                  children: currentPageData
                                      .asMap()
                                      .entries
                                      .map((entry) {
                                    int index = entry.key;
                                    bool isExpanded = expandedIndex == index;
                                    unit_properties Propertytype = entry.value;
                                    //return CustomExpansionTile(data: Propertytype, index: index);
                                    return Container(
                                      margin: const EdgeInsets.symmetric(vertical: 6),
                                      decoration: BoxDecoration(
                                        color: index % 2 != 0
                                            ? const Color(0xFFF4F8FF)
                                            : Colors.white,
                                        border: Border.all(
                                            color: const Color(0xFFDBE0E5)),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      // decoration: BoxDecoration(
                                      //   border: Border.all(color: blueColor),
                                      // ),
                                      child: Column(
                                        children: <Widget>[
                                          ListTile(
                                            contentPadding: EdgeInsets.zero,
                                            title: Padding(
                                              padding:
                                                  const EdgeInsets.all(2.0),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    onTap: () {
                                                      // setState(() {
                                                      //    isExpanded = !isExpanded;
                                                      // //  expandedIndex = !expandedIndex;
                                                      //
                                                      // });
                                                      // setState(() {
                                                      //   if (isExpanded) {
                                                      //     expandedIndex = null;
                                                      //     isExpanded = !isExpanded;
                                                      //   } else {
                                                      //     expandedIndex = index;
                                                      //   }
                                                      // });
                                                      setState(() {
                                                        if (expandedIndex ==
                                                            index) {
                                                          expandedIndex = null;
                                                        } else {
                                                          expandedIndex = index;
                                                        }
                                                      });
                                                    },
                                                    child: Container(
                                                      margin: const EdgeInsets.only(
                                                          left: 5),
                                                      padding: !isExpanded
                                                          ? const EdgeInsets.only(
                                                              bottom: 10)
                                                          : const EdgeInsets.only(
                                                              top: 10),
                                                      child: FaIcon(
                                                        isExpanded
                                                            ? FontAwesomeIcons
                                                                .sortUp
                                                            : FontAwesomeIcons
                                                                .sortDown,
                                                        size: 20,
                                                        color: blueColor,
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: InkWell(
                                                      onTap: () {
                                                        setState(() {
                                                          if (expandedIndex ==
                                                              index) {
                                                            expandedIndex =
                                                                null;
                                                          } else {
                                                            expandedIndex =
                                                                index;
                                                          }
                                                        });
                                                      },
                                                      child: Text(
                                                        '   ${Propertytype.rentalunit}',
                                                        style: TextStyle(
                                                          color: blueColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 13,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Text(
                                                      Propertytype.rentalunitadress
                                                                  ?.isNotEmpty ==
                                                              true
                                                          ? '${Propertytype.rentalunitadress}'
                                                          : '  N/A',
                                                      style: TextStyle(
                                                        color: blueColor,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 13,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          if (isExpanded)
                                            Container(
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 2.0),
                                              margin:
                                                  const EdgeInsets.only(bottom: 2),
                                              child: SingleChildScrollView(
                                                child: Column(
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        FaIcon(
                                                          isExpanded
                                                              ? FontAwesomeIcons
                                                                  .sortUp
                                                              : FontAwesomeIcons
                                                                  .sortDown,
                                                          size: 40,
                                                          color: Colors
                                                              .transparent,
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text.rich(
                                                                TextSpan(
                                                                  children: [
                                                                    TextSpan(
                                                                      text:
                                                                          'Tenant :',
                                                                      style: TextStyle(
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                          color:
                                                                              blueColor), // Bold and black
                                                                    ),
                                                                    TextSpan(
                                                                      text:
                                                                          ' ${Propertytype.tenantCount ?? 0}',
                                                                      style: TextStyle(
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color:
                                                                              grey), // Light and grey
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        GestureDetector(
                                                          // onTap: () {
                                                          //   unitnum.text =
                                                          //         Propertytype
                                                          //             .rentalunit!;
                                                          //     street3.text =
                                                          //         Propertytype
                                                          //             .rentalunitadress!;
                                                          //     sqft3.text =
                                                          //         Propertytype
                                                          //             .rentalsqft!;
                                                          //     bath3.text =
                                                          //         Propertytype
                                                          //             .rentalbath!;
                                                          //     bed3.text =
                                                          //         Propertytype
                                                          //             .rentalbed!;
                                                          //     if (Propertytype
                                                          //             .rentalImages !=
                                                          //         null) {
                                                          //       setState(() {
                                                          //         _imageUrls =
                                                          //             Propertytype
                                                          //                 .rentalImages!;
                                                          //       });
                                                          //     }
                                                          //   if (widget.properties.propertyTypeData!.isMultiunit! &&
                                                          //       widget.properties.propertyTypeData!.propertyType == 'Residential') {
                                                          //     // Show popup for Residential
                                                          //     showCommonPopup(
                                                          //       context: context,
                                                          //       isMultiunit: true,
                                                          //       propertyType: 'Residential',
                                                          //       onSave: () async {
                                                          //         await _uploadAllImages();
                                                          //         // Residential save logic
                                                          //         if (unitnum.text.isEmpty ||
                                                          //             street3.text.isEmpty ||
                                                          //             sqft3.text.isEmpty ||
                                                          //             bath3.text.isEmpty ||
                                                          //             bed3.text.isEmpty) {
                                                          //           setState(() {
                                                          //             iserror = true;
                                                          //           });
                                                          //         } else {
                                                          //           setState(() {
                                                          //             isLoading = true;
                                                          //             iserror = false;
                                                          //           });
                                                          //           SharedPreferences prefs = await SharedPreferences.getInstance();
                                                          //           String? id = prefs.getString("adminId");
                                                          //           Properies_summery_Repo().Editunit(
                                                          //             rentalunit: unitnum.text,
                                                          //             rentalImages: _imageUrls,
                                                          //             rentalsqft: sqft3.text,
                                                          //             rentalunitadress: street3.text,
                                                          //             rentalbath: bath3.text,
                                                          //             rentalbed: bed3.text,
                                                          //             unitId: Propertytype.unitId,
                                                          //             adminId: id,
                                                          //             rentalId: Propertytype.rentalId,
                                                          //           ).then((value) {
                                                          //             setState(() {
                                                          //               isLoading = false;
                                                          //             });
                                                          //             Navigator.of(context).pop(true);
                                                          //             reload_Screen();
                                                          //           }).catchError((e) {
                                                          //             setState(() {
                                                          //               isLoading = false;
                                                          //             });
                                                          //           });
                                                          //         }
                                                          //       },
                                                          //       unitController: unitnum,
                                                          //       sqftController: sqft3,
                                                          //       addressController: street3,
                                                          //       bathController:bath3 ,
                                                          //       bedController:bed3 ,
                                                          //       images: _images,
                                                          //       imageUrls: _imageUrls,
                                                          //       isError: iserror,
                                                          //       onImageAdd: () async {
                                                          //         await _pickImage().then((value){
                                                          //           print(_images.length);
                                                          //         });
                                                          //
                                                          //       },
                                                          //       onImageRemove: (index) {
                                                          //         setState(() {
                                                          //           _imageUrls.removeAt(index);
                                                          //         });
                                                          //       },
                                                          //     );
                                                          //   }
                                                          //   else if (widget.properties.propertyTypeData!.isMultiunit! &&
                                                          //       widget.properties.propertyTypeData!.propertyType == 'Commercial') {
                                                          //     // Show popup for Commercial
                                                          //     showCommonPopup(
                                                          //       context: context,
                                                          //       isMultiunit: true,
                                                          //       propertyType: 'Commercial',
                                                          //       isError: iserror,
                                                          //       onSave: () async {
                                                          //         await _uploadAllImages();
                                                          //         // Commercial save logic
                                                          //         if (unitnum.text.isEmpty || street3.text.isEmpty || sqft3.text.isEmpty) {
                                                          //           setState(() {
                                                          //             iserror = true;
                                                          //           });
                                                          //         } else {
                                                          //           setState(() {
                                                          //             isLoading = true;
                                                          //             iserror = false;
                                                          //           });
                                                          //           SharedPreferences prefs = await SharedPreferences.getInstance();
                                                          //           String? id = prefs.getString("adminId");
                                                          //           Properies_summery_Repo().Editunit(
                                                          //             rentalunit: unitnum.text,
                                                          //             rentalsqft: sqft3.text,
                                                          //             rentalImages: _imageUrls,
                                                          //             rentalunitadress: street3.text,
                                                          //             unitId: Propertytype.unitId!,
                                                          //             rentalId: Propertytype.rentalId!,
                                                          //           ).then((value) {
                                                          //             setState(() {
                                                          //               isLoading = false;
                                                          //             });
                                                          //             Navigator.of(context).pop(true);
                                                          //             reload_Screen();
                                                          //           }).catchError((e) {
                                                          //             setState(() {
                                                          //               isLoading = false;
                                                          //             });
                                                          //           });
                                                          //         }
                                                          //       },
                                                          //       unitController: unitnum,
                                                          //       sqftController: sqft3,
                                                          //       addressController: street3,
                                                          //    // imagess: _image,
                                                          //       images: _images,
                                                          //       imageUrls: _imageUrls,
                                                          //       onImageAdd: () async {
                                                          //         _pickImage().then((_) {
                                                          //           setState(
                                                          //                   () {}); // Rebuild the widget after selecting the image
                                                          //         });
                                                          //       },
                                                          //       onImageRemove: (index) {
                                                          //         setState(() {
                                                          //           _imageUrls.removeAt(index);
                                                          //         });
                                                          //       },
                                                          //     );
                                                          //   }
                                                          // },

                                                          onTap: () {
                                                            reload_Screen();
                                                            unitnum.text =
                                                                Propertytype
                                                                    .rentalunit!;
                                                            street3.text =
                                                                Propertytype
                                                                    .rentalunitadress!;
                                                            sqft3.text =
                                                                Propertytype
                                                                    .rentalsqft!;
                                                            bath3.text =
                                                                Propertytype
                                                                    .rentalbath!;
                                                            bed3.text =
                                                                Propertytype
                                                                    .rentalbed!;
                                                            if (Propertytype
                                                                    .rentalImages !=
                                                                null) {
                                                              setState(() {
                                                                _imageUrls =
                                                                    Propertytype
                                                                        .rentalImages!;
                                                              });
                                                            }
                                                            _images.clear();
                                                            // if (widget
                                                            //         .properties
                                                            //         .propertyTypeData!
                                                            //         .isMultiunit! &&
                                                            //     widget
                                                            //             .properties
                                                            //             .propertyTypeData!
                                                            //             .propertyType ==
                                                            //         'Residential') {
                                                            //   showDialog(
                                                            //     context:
                                                            //         context,
                                                            //     builder:
                                                            //         (BuildContext
                                                            //             context) {
                                                            //       // Moved isChecked inside the StatefulBuilder
                                                            //       return StatefulBuilder(
                                                            //         builder: (BuildContext
                                                            //                 context,
                                                            //             StateSetter
                                                            //                 setState) {
                                                            //           return AlertDialog(
                                                            //             backgroundColor:
                                                            //                 Colors.white,
                                                            //             surfaceTintColor:
                                                            //                 Colors.white,
                                                            //             content:
                                                            //                 SingleChildScrollView(
                                                            //               child:
                                                            //                   Column(
                                                            //                 children: [
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Edit Unit Details",
                                                            //                         style: TextStyle(
                                                            //                           color: blueColor,
                                                            //                           fontWeight: FontWeight.bold,
                                                            //                         ),
                                                            //                       ),
                                                            //                       const Spacer(),
                                                            //                       Align(
                                                            //                         alignment: Alignment.centerRight,
                                                            //                         child: InkWell(
                                                            //                           onTap: () {
                                                            //                             Navigator.pop(context);
                                                            //                           },
                                                            //                           child: const Icon(Icons.close, color: Colors.black),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Unit Number",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: unitnum,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Street Address",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: street3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "SQFT",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: sqft3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "bath",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: bath3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "bed",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: bed3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         'Photo',
                                                            //                         style: TextStyle(color: Colors.black),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(height: 8.0),
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       GestureDetector(
                                                            //                         onTap: () {
                                                            //                           _pickImage().then((_) {
                                                            //                             setState(() {}); // Rebuild the widget after selecting the image
                                                            //                           });
                                                            //                         },
                                                            //                         child: const Text(
                                                            //                           '+ Add',
                                                            //                           style: TextStyle(color: Colors.green),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   // _image != null
                                                            //                   //     ? Column(
                                                            //                   //         children: [
                                                            //                   //           Image.file(
                                                            //                   //             _image!,
                                                            //                   //             height: 80,
                                                            //                   //             width: 80,
                                                            //                   //             fit: BoxFit.cover,
                                                            //                   //           ),
                                                            //                   //           Text(_uploadedFileName ?? ""),
                                                            //                   //         ],
                                                            //                   //       )
                                                            //                   //     : const Text(''),
                                                            //                   _imageUrls.isNotEmpty
                                                            //                       ? Row(
                                                            //                           children: [
                                                            //                             Expanded(
                                                            //                               child: Container(
                                                            //                                 child: Wrap(
                                                            //                                   spacing: 8.0, // Horizontal spacing between items
                                                            //                                   runSpacing: 8.0, // Vertical spacing between rows
                                                            //                                   children: List.generate(
                                                            //                                     _imageUrls.length,
                                                            //                                     (index) {
                                                            //                                       return Container(
                                                            //                                         width: 85,
                                                            //                                         child: Column(
                                                            //                                           mainAxisAlignment: MainAxisAlignment.start,
                                                            //                                           crossAxisAlignment: CrossAxisAlignment.start,
                                                            //                                           children: [
                                                            //                                             Row(
                                                            //                                               children: [
                                                            //                                                 SizedBox(width: 60),
                                                            //                                                 GestureDetector(
                                                            //                                                   onTap: () {
                                                            //                                                     setState(() {
                                                            //                                                       _imageUrls.removeAt(index);
                                                            //                                                     });
                                                            //                                                   },
                                                            //                                                   child: Icon(
                                                            //                                                     Icons.close,
                                                            //                                                     color: Colors.grey,
                                                            //                                                   ),
                                                            //                                                 ),
                                                            //                                               ],
                                                            //                                             ),
                                                            //                                             Row(
                                                            //                                               mainAxisAlignment: MainAxisAlignment.start,
                                                            //                                               crossAxisAlignment: CrossAxisAlignment.start,
                                                            //                                               children: [
                                                            //                                                 Container(
                                                            //                                                   child: Image.network(
                                                            //                                                     "$image_url${_imageUrls[index]}",
                                                            //                                                     height: 80,
                                                            //                                                     width: 80,
                                                            //                                                     fit: BoxFit.cover,
                                                            //                                                     errorBuilder: (context, error, stackTrace) {
                                                            //                                                       return Icon(Icons.error); // Placeholder for errors
                                                            //                                                     },
                                                            //                                                   ),
                                                            //                                                 ),
                                                            //                                               ],
                                                            //                                             ),
                                                            //                                           ],
                                                            //                                         ),
                                                            //                                       );
                                                            //                                     },
                                                            //                                   ),
                                                            //                                 ),
                                                            //                               ),
                                                            //                             ),
                                                            //                           ],
                                                            //                         )
                                                            //                       : Center(child: Text("No images selected.")),
                                                            //                   const SizedBox(height: 8.0),
                                                            //
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       const SizedBox(
                                                            //                         width: 0,
                                                            //                       ),
                                                            //                       GestureDetector(
                                                            //                         onTap: () async {
                                                            //                           if (unitnum.text.isEmpty || street3.text.isEmpty || sqft3.text.isEmpty || bath3.text.isEmpty || bed3.text.isEmpty) {
                                                            //                             setState(() {
                                                            //                               iserror = true;
                                                            //                             });
                                                            //                           } else {
                                                            //                             setState(() {
                                                            //                               isLoading = true;
                                                            //                               iserror = false;
                                                            //                             });
                                                            //                             SharedPreferences prefs = await SharedPreferences.getInstance();
                                                            //
                                                            //                             String? id = prefs.getString("adminId");
                                                            //                             Properies_summery_Repo()
                                                            //                                 .Editunit(
                                                            //                                     rentalunit: unitnum.text,
                                                            //                                     rentalImages: _imageUrls,
                                                            //                                     rentalsqft: sqft3.text,
                                                            //                                     rentalunitadress: street3.text,
                                                            //                                     rentalbath: bath3.text,
                                                            //                                     rentalbed: bed3.text,
                                                            //                                     unitId: Propertytype.unitId,
                                                            //                                     adminId: id,
                                                            //                                     // rentalImages: _imageUrls,
                                                            //                                     rentalId: Propertytype.rentalId)
                                                            //                                 .then((value) {
                                                            //                               setState(() {
                                                            //                                 isLoading = false;
                                                            //                               });
                                                            //
                                                            //                               Navigator.of(context).pop(true);
                                                            //                               reload_Screen();
                                                            //                             }).catchError((e) {
                                                            //                               setState(() {
                                                            //                                 isLoading = false;
                                                            //                               });
                                                            //                             });
                                                            //                           }
                                                            //                         },
                                                            //                         child: Material(
                                                            //                           elevation: 3,
                                                            //                           borderRadius: const BorderRadius.all(
                                                            //                             Radius.circular(5),
                                                            //                           ),
                                                            //                           child: Container(
                                                            //                             height: 30,
                                                            //                             width: 80,
                                                            //                             decoration: BoxDecoration(
                                                            //                               color: blueColor,
                                                            //                               borderRadius: BorderRadius.all(
                                                            //                                 Radius.circular(5),
                                                            //                               ),
                                                            //                             ),
                                                            //                             child: const Center(
                                                            //                                 child: Text(
                                                            //                               "Save",
                                                            //                               style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                            //                             )),
                                                            //                           ),
                                                            //                         ),
                                                            //                       ),
                                                            //                       const SizedBox(width: 10),
                                                            //                       GestureDetector(
                                                            //                         onTap: () {
                                                            //                           Navigator.pop(context);
                                                            //                         },
                                                            //                         child: Material(
                                                            //                           elevation: 3,
                                                            //                           borderRadius: const BorderRadius.all(
                                                            //                             Radius.circular(5),
                                                            //                           ),
                                                            //                           child: Container(
                                                            //                             height: 30,
                                                            //                             width: 80,
                                                            //                             decoration: const BoxDecoration(
                                                            //                               color: Colors.white,
                                                            //                               borderRadius: BorderRadius.all(
                                                            //                                 Radius.circular(5),
                                                            //                               ),
                                                            //                             ),
                                                            //                             child: Center(
                                                            //                                 child: Text(
                                                            //                               "Cancel",
                                                            //                               style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                            //                             )),
                                                            //                           ),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(height: 8.0),
                                                            //                   if (iserror)
                                                            //                     const Text(
                                                            //                       "Please fill in all fields correctly.",
                                                            //                       style: TextStyle(color: Colors.redAccent),
                                                            //                     ),
                                                            //                 ],
                                                            //               ),
                                                            //             ),
                                                            //           );
                                                            //         },
                                                            //       );
                                                            //     },
                                                            //   );
                                                            // }
                                                            if (widget
                                                                    .properties
                                                                    .propertyTypeData!
                                                                    .isMultiunit! &&
                                                                widget
                                                                        .properties
                                                                        .propertyTypeData!
                                                                        .propertyType ==
                                                                    'Residential') {
                                                              showDialog(
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (BuildContext
                                                                        context) {
                                                                  bool
                                                                      isChecked =
                                                                      false; // Moved isChecked inside the StatefulBuilder
                                                                  return StatefulBuilder(
                                                                    builder: (BuildContext
                                                                            context,
                                                                        StateSetter
                                                                            setState) {
                                                                      return AlertDialog(
                                                                        backgroundColor:
                                                                            Colors.white,
                                                                        surfaceTintColor:
                                                                            Colors.white,
                                                                        content:
                                                                            SingleChildScrollView(
                                                                          child:
                                                                              Column(
                                                                            children: [
                                                                              Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Edit Unit Details",
                                                                                    style: TextStyle(
                                                                                      color: blueColor,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                  const Spacer(),
                                                                                  Align(
                                                                                    alignment: Alignment.centerRight,
                                                                                    child: InkWell(
                                                                                      onTap: () {
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: const Icon(Icons.close, color: Colors.black),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Unit Number *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: unitnum,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Street Address *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: street3,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "SQFT *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: sqft3,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Bath",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              buildSafeDropdown(
                                                                                controller: bath3,
                                                                                items: bathArray,
                                                                                label: "Bath",
                                                                                isBed: false,
                                                                                onChanged: (String? newValue) {
                                                                                  if (newValue != null) {
                                                                                    setState(() {
                                                                                      bath3.text = newValue;
                                                                                    });
                                                                                  }
                                                                                },
                                                                              ),
                                                                              // Padding(
                                                                              //   padding: const EdgeInsets.symmetric(vertical: 1),
                                                                              //   child: Material(
                                                                              //     elevation: 3,
                                                                              //     borderRadius: BorderRadius.circular(3),
                                                                              //     child: Container(
                                                                              //       padding: EdgeInsets.symmetric(horizontal: 10),
                                                                              //       decoration: BoxDecoration(
                                                                              //         color: Colors.white,
                                                                              //         borderRadius: BorderRadius.circular(3),
                                                                              //         border: Border.all(color: Color(0xFF8A95A8)),
                                                                              //       ),
                                                                              //       child: DropdownButtonHideUnderline(
                                                                              //         child: DropdownButton<String>(
                                                                              //           isExpanded: true,
                                                                              //           value: bath3.text.isNotEmpty ? bath3.text : null,
                                                                              //           hint: Text('Select Bath'),
                                                                              //           items: bathArray.map((String value) {
                                                                              //             return DropdownMenuItem<String>(
                                                                              //               value: value,
                                                                              //               child: Text(value),
                                                                              //             );
                                                                              //           }).toList(),
                                                                              //           onChanged: (String? newValue) {
                                                                              //             setState(() {
                                                                              //               bath3.text = newValue ?? '';
                                                                              //             });
                                                                              //           },
                                                                              //         ),
                                                                              //       ),
                                                                              //     ),
                                                                              //   ),
                                                                              // ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Bed",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              buildSafeDropdown(
                                                                                controller: bed3,
                                                                                items: roomsArray,
                                                                                label: "Bed",
                                                                                isBed: true,
                                                                                onChanged: (String? newValue) {
                                                                                  if (newValue != null) {
                                                                                    setState(() {
                                                                                      bed3.text = newValue;
                                                                                    });
                                                                                  }
                                                                                },
                                                                              ),
                                                                              // Padding(
                                                                              //   padding: const EdgeInsets.symmetric(vertical: 1),
                                                                              //   child: Material(
                                                                              //     elevation: 3,
                                                                              //     borderRadius: BorderRadius.circular(3),
                                                                              //     child: Container(
                                                                              //       padding: EdgeInsets.symmetric(horizontal: 10),
                                                                              //       decoration: BoxDecoration(
                                                                              //         color: Colors.white,
                                                                              //         borderRadius: BorderRadius.circular(3),
                                                                              //         border: Border.all(color: Color(0xFF8A95A8)),
                                                                              //       ),
                                                                              //       child: DropdownButtonHideUnderline(
                                                                              //         child: DropdownButton<String>(
                                                                              //           isExpanded: true,
                                                                              //           value: bed3.text.isNotEmpty ? bed3.text : null,
                                                                              //           hint: Text('Select Bed'),
                                                                              //           items: roomsArray.map((String value) {
                                                                              //             return DropdownMenuItem<String>(
                                                                              //               value: value,
                                                                              //               child: Text(value),
                                                                              //             );
                                                                              //           }).toList(),
                                                                              //           onChanged: (String? newValue) {
                                                                              //             setState(() {
                                                                              //               bed3.text = newValue ?? '';
                                                                              //             });
                                                                              //           },
                                                                              //         ),
                                                                              //       ),
                                                                              //     ),
                                                                              //   ),
                                                                              // ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    'Photo',
                                                                                    style: TextStyle(color: Colors.black),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 8.0),
                                                                              if (_images.isEmpty && _imageUrls.isEmpty)
                                                                                Row(
                                                                                  children: [
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        _pickImage().then((_) {
                                                                                          setState(() {}); // Rebuild the widget after selecting the image
                                                                                        });
                                                                                      },
                                                                                      child: const Text(
                                                                                        '+ Add',
                                                                                        style: TextStyle(color: Colors.green),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              if (_images.isEmpty && _imageUrls.isEmpty)
                                                                                const SizedBox(height: 8.0),
                                                                              _images.isNotEmpty || _imageUrls.isNotEmpty
                                                                                  ? Row(
                                                                                      children: [
                                                                                        Expanded(
                                                                                          child: Container(
                                                                                            child: Wrap(
                                                                                              spacing: 8.0, // Horizontal spacing between items
                                                                                              runSpacing: 8.0, // Vertical spacing between rows
                                                                                              children: [
                                                                                                // Display picked local images
                                                                                                ...List.generate(
                                                                                                  _images.length,
                                                                                                  (index) {
                                                                                                    return Container(
                                                                                                      width: 85,
                                                                                                      child: Column(
                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                        children: [
                                                                                                          Row(
                                                                                                            children: [
                                                                                                              const SizedBox(width: 60),
                                                                                                              GestureDetector(
                                                                                                                onTap: () {
                                                                                                                  setState(() {
                                                                                                                    _images.removeAt(index);
                                                                                                                  });
                                                                                                                },
                                                                                                                child: const Icon(
                                                                                                                  Icons.close,
                                                                                                                  color: Colors.grey,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                          Row(
                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                            children: [
                                                                                                              Container(
                                                                                                                child: Image.file(
                                                                                                                  _images[index],
                                                                                                                  height: 80,
                                                                                                                  width: 80,
                                                                                                                  fit: BoxFit.cover,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    );
                                                                                                  },
                                                                                                ),
                                                                                                // Display uploaded image URLs
                                                                                                ...List.generate(
                                                                                                  _imageUrls.length,
                                                                                                  (index) {
                                                                                                    return Container(
                                                                                                      width: 85,
                                                                                                      child: Column(
                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                        children: [
                                                                                                          Row(
                                                                                                            children: [
                                                                                                              const SizedBox(width: 60),
                                                                                                              GestureDetector(
                                                                                                                onTap: () {
                                                                                                                  // setState(() {
                                                                                                                  //   _imageUrls.removeAt(index);
                                                                                                                  // });
                                                                                                                  setState(() {
                                                                                                                    if (index >= 0 && index < _imageUrls.length) {
                                                                                                                      _imageUrls.removeAt(index);
                                                                                                                    }
                                                                                                                    if (index >= 0 && index < _editimageUrls.length) {
                                                                                                                      _editimageUrls.removeAt(index);
                                                                                                                    }
                                                                                                                  });
                                                                                                                },
                                                                                                                child: const Icon(
                                                                                                                  Icons.close,
                                                                                                                  color: Colors.grey,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                          Row(
                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                            children: [
                                                                                                              Container(
                                                                                                                child: Image.network(
                                                                                                                  "$image_url${_imageUrls[index]}",
                                                                                                                  height: 80,
                                                                                                                  width: 80,
                                                                                                                  fit: BoxFit.cover,
                                                                                                                  errorBuilder: (context, error, stackTrace) {
                                                                                                                    return const Icon(Icons.error); // Placeholder for errors
                                                                                                                  },
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    );
                                                                                                  },
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    )
                                                                                  : const Center(
                                                                                      child: Text("No images selected."),
                                                                                    ),
                                                                              const SizedBox(height: 8.0),
                                                                              Row(
                                                                                children: [
                                                                                  const SizedBox(
                                                                                    width: 0,
                                                                                  ),
                                                                                  GestureDetector(
                                                                                    onTap: () async {
                                                                                      await _uploadAllImages();
                                                                                      if (unitnum.text.trim().isEmpty || street3.text.trim().isEmpty || sqft3.text.trim().isEmpty) {
                                                                                        setState(() {
                                                                                          iserror = true;
                                                                                        });
                                                                                      } else {
                                                                                        setState(() {
                                                                                          isLoading = true;
                                                                                          iserror = false;
                                                                                        });
                                                                                        SharedPreferences prefs = await SharedPreferences.getInstance();

                                                                                        String? id = prefs.getString("adminId");
                                                                                        Properies_summery_Repo()
                                                                                            .Editunit(
                                                                                                rentalunit: unitnum.text.trim(),
                                                                                                rentalImages: _imageUrls,
                                                                                                rentalsqft: sqft3.text.trim(),
                                                                                                rentalunitadress: street3.text.trim(),
                                                                                                rentalbath: bath3.text.trim(),
                                                                                                rentalbed: bed3.text.trim(),
                                                                                                unitId: Propertytype.unitId,
                                                                                                adminId: id,
                                                                                                // rentalImages: _imageUrls,
                                                                                                rentalId: Propertytype.rentalId)
                                                                                            .then((value) {
                                                                                          setState(() {
                                                                                            isLoading = false;
                                                                                          });

                                                                                          Navigator.of(context).pop(true);
                                                                                          reload_Screen();
                                                                                        }).catchError((e) {
                                                                                          setState(() {
                                                                                            isLoading = false;
                                                                                          });
                                                                                        });
                                                                                      }
                                                                                    },
                                                                                    child: Material(
                                                                                      elevation: 3,
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(5),
                                                                                      ),
                                                                                      child: Container(
                                                                                        height: 30,
                                                                                        width: 80,
                                                                                        decoration: BoxDecoration(
                                                                                          color: blueColor,
                                                                                          borderRadius: const BorderRadius.all(
                                                                                            Radius.circular(5),
                                                                                          ),
                                                                                        ),
                                                                                        child: const Center(
                                                                                            child: Text(
                                                                                          "Save",
                                                                                          style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                                                        )),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  const SizedBox(width: 10),
                                                                                  GestureDetector(
                                                                                    onTap: () {
                                                                                      Navigator.pop(context);
                                                                                    },
                                                                                    child: Material(
                                                                                      elevation: 3,
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(5),
                                                                                      ),
                                                                                      child: Container(
                                                                                        height: 30,
                                                                                        width: 80,
                                                                                        decoration: const BoxDecoration(
                                                                                          color: Colors.white,
                                                                                          borderRadius: BorderRadius.all(
                                                                                            Radius.circular(5),
                                                                                          ),
                                                                                        ),
                                                                                        child: Center(
                                                                                            child: Text(
                                                                                          "Cancel",
                                                                                          style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                                                        )),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 8.0),
                                                                              if (iserror)
                                                                                const Text(
                                                                                  "Please fill in all fields correctly.",
                                                                                  style: TextStyle(color: Colors.redAccent),
                                                                                ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  );
                                                                },
                                                              );
                                                            }
                                                            // if (widget
                                                            //         .properties
                                                            //         .propertyTypeData!
                                                            //         .isMultiunit! &&
                                                            //     widget
                                                            //             .properties
                                                            //             .propertyTypeData!
                                                            //             .propertyType ==
                                                            //         'Commercial') {
                                                            //   showDialog(
                                                            //     context:
                                                            //         context,
                                                            //     builder:
                                                            //         (BuildContext
                                                            //             context) {
                                                            //       bool
                                                            //           isChecked =
                                                            //           false; // Moved isChecked inside the StatefulBuilder
                                                            //       return StatefulBuilder(
                                                            //         builder: (BuildContext
                                                            //                 context,
                                                            //             StateSetter
                                                            //                 setState) {
                                                            //           return AlertDialog(
                                                            //             backgroundColor:
                                                            //                 Colors.white,
                                                            //             surfaceTintColor:
                                                            //                 Colors.white,
                                                            //             content:
                                                            //                 SingleChildScrollView(
                                                            //               child:
                                                            //                   Column(
                                                            //                 children: [
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Edit Unit Details",
                                                            //                         style: TextStyle(
                                                            //                           color: blueColor,
                                                            //                           fontWeight: FontWeight.bold,
                                                            //                         ),
                                                            //                       ),
                                                            //                       const Spacer(),
                                                            //                       Align(
                                                            //                         alignment: Alignment.centerRight,
                                                            //                         child: InkWell(
                                                            //                           onTap: () {
                                                            //                             Navigator.pop(context);
                                                            //                           },
                                                            //                           child: const Icon(Icons.close, color: Colors.black),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Unit Number",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: unitnum,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "Street Address",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: street3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   const Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         "SQFT",
                                                            //                         style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   Padding(
                                                            //                     padding: const EdgeInsets.symmetric(vertical: 1),
                                                            //                     child: Material(
                                                            //                       elevation: 3,
                                                            //                       borderRadius: BorderRadius.circular(3),
                                                            //                       child: TextFormField(
                                                            //                         controller: sqft3,
                                                            //                         cursorColor: Colors.black,
                                                            //                         decoration: InputDecoration(
                                                            //                           //  hintText: label,
                                                            //                           // labelText: label,
                                                            //                           // labelStyle: TextStyle(color: Colors.grey[700]),
                                                            //                           filled: true,
                                                            //                           fillColor: Colors.white,
                                                            //                           border: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: BorderSide.none,
                                                            //                           ),
                                                            //                           enabledBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                            //                           ),
                                                            //                           focusedBorder: OutlineInputBorder(
                                                            //                             borderRadius: BorderRadius.circular(3),
                                                            //                             borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                            //                           ),
                                                            //                           contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ),
                                                            //                   ),
                                                            //                   const SizedBox(
                                                            //                     height: 10,
                                                            //                   ),
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       Text(
                                                            //                         'Photo',
                                                            //                         style: TextStyle(
                                                            //                             color: Colors.black),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   SizedBox(height: 8.0),
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       GestureDetector(
                                                            //                         onTap: () {
                                                            //                           _pickImage().then((_) {
                                                            //                             setState(
                                                            //                                     () {}); // Rebuild the widget after selecting the image
                                                            //                           });
                                                            //                         },
                                                            //                         child: Text(
                                                            //                           '+ Add',
                                                            //                           style: TextStyle(
                                                            //                               color: Colors.green),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   SizedBox(height: 8.0),
                                                            //                   _images.isNotEmpty
                                                            //                       ? Row(
                                                            //                     children: [
                                                            //                       Expanded(
                                                            //                         child: Container(
                                                            //                           //color: Colors.blue,
                                                            //                           child: Wrap(
                                                            //                             spacing:
                                                            //                             8.0, // Horizontal spacing between items
                                                            //                             runSpacing:
                                                            //                             8.0, // Vertical spacing between rows
                                                            //                             children: List.generate(
                                                            //                               _images.length,
                                                            //                                   (index) {
                                                            //                                 return Container(
                                                            //                                   // color: Colors.green,
                                                            //                                   width: 85,
                                                            //                                   child: Column(
                                                            //                                     mainAxisAlignment:
                                                            //                                     MainAxisAlignment
                                                            //                                         .start,
                                                            //                                     crossAxisAlignment:
                                                            //                                     CrossAxisAlignment
                                                            //                                         .start,
                                                            //                                     children: [
                                                            //                                       Row(
                                                            //                                         children: [
                                                            //                                           SizedBox(
                                                            //                                             width:
                                                            //                                             60,
                                                            //                                           ),
                                                            //                                           GestureDetector(
                                                            //                                             onTap:
                                                            //                                                 () {
                                                            //                                               setState(
                                                            //                                                       () {
                                                            //                                                     _images.removeAt(index);
                                                            //                                                   });
                                                            //                                             },
                                                            //                                             child:
                                                            //                                             Icon(
                                                            //                                               Icons
                                                            //                                                   .close,
                                                            //                                               color:
                                                            //                                               Colors.grey,
                                                            //                                             ),
                                                            //                                           ),
                                                            //                                         ],
                                                            //                                       ),
                                                            //                                       Row(
                                                            //                                         mainAxisAlignment:
                                                            //                                         MainAxisAlignment
                                                            //                                             .start,
                                                            //                                         crossAxisAlignment:
                                                            //                                         CrossAxisAlignment
                                                            //                                             .start,
                                                            //                                         children: [
                                                            //                                           Container(
                                                            //                                             // color:Colors.blue,
                                                            //                                             child: Image
                                                            //                                                 .file(
                                                            //                                               _images[
                                                            //                                               index],
                                                            //                                               height:
                                                            //                                               80,
                                                            //                                               width:
                                                            //                                               80,
                                                            //                                               fit: BoxFit
                                                            //                                                   .cover,
                                                            //                                             ),
                                                            //                                           ),
                                                            //                                         ],
                                                            //                                       ),
                                                            //                                     ],
                                                            //                                   ),
                                                            //                                 );
                                                            //                               },
                                                            //                             ),
                                                            //                           ),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   )
                                                            //                       : Center(
                                                            //                     child:
                                                            //                     Text("No images selected."),
                                                            //                   ),
                                                            //                   Row(
                                                            //                     children: [
                                                            //                       const SizedBox(
                                                            //                         width: 0,
                                                            //                       ),
                                                            //                       GestureDetector(
                                                            //                         onTap: () async {
                                                            //                           if (unitnum.text.isEmpty || street3.text.isEmpty || sqft3.text.isEmpty) {
                                                            //                             setState(() {
                                                            //                               iserror = true;
                                                            //                             });
                                                            //                           } else {
                                                            //                             setState(() {
                                                            //                               isLoading = true;
                                                            //                               iserror = false;
                                                            //                             });
                                                            //                             SharedPreferences prefs = await SharedPreferences.getInstance();
                                                            //                             String? id = prefs.getString("adminId");
                                                            //                             Properies_summery_Repo()
                                                            //                                 .Editunit(
                                                            //                               rentalunit: unitnum.text,
                                                            //                               rentalsqft: sqft3.text,
                                                            //                               rentalImages: _imageUrls,
                                                            //                               rentalunitadress: street3.text,
                                                            //                               unitId: Propertytype.unitId!,
                                                            //                               rentalId: Propertytype.rentalId!,
                                                            //                             )
                                                            //                                 .then((value) {
                                                            //                               setState(() {
                                                            //                                 isLoading = false;
                                                            //                               });
                                                            //                               Navigator.of(context).pop(true);
                                                            //                               reload_Screen();
                                                            //                             }).catchError((e) {
                                                            //                               setState(() {
                                                            //                                 isLoading = false;
                                                            //                               });
                                                            //                             });
                                                            //                           }
                                                            //                         },
                                                            //                         child: Material(
                                                            //                           elevation: 3,
                                                            //                           borderRadius: const BorderRadius.all(
                                                            //                             Radius.circular(5),
                                                            //                           ),
                                                            //                           child: Container(
                                                            //                             height: 30,
                                                            //                             width: 80,
                                                            //                             decoration: BoxDecoration(
                                                            //                               color: blueColor,
                                                            //                               borderRadius: BorderRadius.all(
                                                            //                                 Radius.circular(5),
                                                            //                               ),
                                                            //                             ),
                                                            //                             child: const Center(
                                                            //                                 child: Text(
                                                            //                               "Save",
                                                            //                               style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                            //                             )),
                                                            //                           ),
                                                            //                         ),
                                                            //                       ),
                                                            //                       const SizedBox(width: 10),
                                                            //                       GestureDetector(
                                                            //                         onTap: () {
                                                            //                           Navigator.pop(context);
                                                            //                         },
                                                            //                         child: Material(
                                                            //                           elevation: 3,
                                                            //                           borderRadius: const BorderRadius.all(
                                                            //                             Radius.circular(5),
                                                            //                           ),
                                                            //                           child: Container(
                                                            //                             height: 30,
                                                            //                             width: 80,
                                                            //                             decoration: const BoxDecoration(
                                                            //                               color: Colors.white,
                                                            //                               borderRadius: BorderRadius.all(
                                                            //                                 Radius.circular(5),
                                                            //                               ),
                                                            //                             ),
                                                            //                             child: Center(
                                                            //                                 child: Text(
                                                            //                               "Cancel",
                                                            //                               style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                            //                             )),
                                                            //                           ),
                                                            //                         ),
                                                            //                       ),
                                                            //                     ],
                                                            //                   ),
                                                            //                   const SizedBox(height: 8.0),
                                                            //                   if (iserror)
                                                            //                     const Text(
                                                            //                       "Please fill in all fields correctly.",
                                                            //                       style: TextStyle(color: Colors.redAccent),
                                                            //                     ),
                                                            //                 ],
                                                            //               ),
                                                            //             ),
                                                            //           );
                                                            //         },
                                                            //       );
                                                            //     },
                                                            //   );
                                                            // }
                                                            if (widget
                                                                    .properties
                                                                    .propertyTypeData!
                                                                    .isMultiunit! &&
                                                                widget
                                                                        .properties
                                                                        .propertyTypeData!
                                                                        .propertyType ==
                                                                    'Commercial') {
                                                              showDialog(
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (BuildContext
                                                                        context) {
                                                                  bool
                                                                      isChecked =
                                                                      false; // Moved isChecked inside the StatefulBuilder
                                                                  return StatefulBuilder(
                                                                    builder: (BuildContext
                                                                            context,
                                                                        StateSetter
                                                                            setState) {
                                                                      return AlertDialog(
                                                                        backgroundColor:
                                                                            Colors.white,
                                                                        surfaceTintColor:
                                                                            Colors.white,
                                                                        content:
                                                                            SingleChildScrollView(
                                                                          child:
                                                                              Column(
                                                                            children: [
                                                                              Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Edid Unit Details",
                                                                                    style: TextStyle(
                                                                                      color: blueColor,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                  const Spacer(),
                                                                                  Align(
                                                                                    alignment: Alignment.centerRight,
                                                                                    child: InkWell(
                                                                                      onTap: () {
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: const Icon(Icons.close, color: Colors.black),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Unit Number *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: unitnum,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "Street Address *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: street3,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    "SQFT *",
                                                                                    style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Padding(
                                                                                padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                child: Material(
                                                                                  elevation: 3,
                                                                                  borderRadius: BorderRadius.circular(3),
                                                                                  child: TextFormField(
                                                                                    controller: sqft3,
                                                                                    cursorColor: Colors.black,
                                                                                    decoration: InputDecoration(
                                                                                      //  hintText: label,
                                                                                      // labelText: label,
                                                                                      // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                      filled: true,
                                                                                      fillColor: Colors.white,
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: BorderSide.none,
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(3),
                                                                                        borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                      ),
                                                                                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              const Row(
                                                                                children: [
                                                                                  Text(
                                                                                    'Photo',
                                                                                    style: TextStyle(color: Colors.black),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 8.0),
                                                                              if (_images.isEmpty && _imageUrls.isEmpty)
                                                                                Row(
                                                                                  children: [
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        _pickImage().then((_) {
                                                                                          setState(() {}); // Rebuild the widget after selecting the image
                                                                                        });
                                                                                      },
                                                                                      child: const Text(
                                                                                        '+ Add',
                                                                                        style: TextStyle(color: Colors.green),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              if (_images.isEmpty && _imageUrls.isEmpty)
                                                                                const SizedBox(height: 8.0),
                                                                              _images.isNotEmpty || _imageUrls.isNotEmpty
                                                                                  ? Row(
                                                                                      children: [
                                                                                        Expanded(
                                                                                          child: Container(
                                                                                            child: Wrap(
                                                                                              spacing: 8.0, // Horizontal spacing between items
                                                                                              runSpacing: 8.0, // Vertical spacing between rows
                                                                                              children: [
                                                                                                // Display picked local images
                                                                                                ...List.generate(
                                                                                                  _images.length,
                                                                                                  (index) {
                                                                                                    return Container(
                                                                                                      width: 85,
                                                                                                      child: Column(
                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                        children: [
                                                                                                          Row(
                                                                                                            children: [
                                                                                                              const SizedBox(width: 60),
                                                                                                              GestureDetector(
                                                                                                                onTap: () {
                                                                                                                  setState(() {
                                                                                                                    _images.removeAt(index);
                                                                                                                  });
                                                                                                                },
                                                                                                                child: const Icon(
                                                                                                                  Icons.close,
                                                                                                                  color: Colors.grey,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                          Row(
                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                            children: [
                                                                                                              Container(
                                                                                                                child: Image.file(
                                                                                                                  _images[index],
                                                                                                                  height: 80,
                                                                                                                  width: 80,
                                                                                                                  fit: BoxFit.cover,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    );
                                                                                                  },
                                                                                                ),
                                                                                                // Display uploaded image URLs
                                                                                                ...List.generate(
                                                                                                  _imageUrls.length,
                                                                                                  (index) {
                                                                                                    return Container(
                                                                                                      width: 85,
                                                                                                      child: Column(
                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                        children: [
                                                                                                          Row(
                                                                                                            children: [
                                                                                                              const SizedBox(width: 60),
                                                                                                              GestureDetector(
                                                                                                                onTap: () {
                                                                                                                  // setState(() {
                                                                                                                  //   _imageUrls.removeAt(index);
                                                                                                                  // });
                                                                                                                  setState(() {
                                                                                                                    if (index >= 0 && index < _imageUrls.length) {
                                                                                                                      _imageUrls.removeAt(index);
                                                                                                                    }
                                                                                                                    if (index >= 0 && index < _editimageUrls.length) {
                                                                                                                      _editimageUrls.removeAt(index);
                                                                                                                    }
                                                                                                                  });
                                                                                                                },
                                                                                                                child: const Icon(
                                                                                                                  Icons.close,
                                                                                                                  color: Colors.grey,
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                          Row(
                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                            children: [
                                                                                                              Container(
                                                                                                                child: Image.network(
                                                                                                                  "$image_url${_imageUrls[index]}",
                                                                                                                  height: 80,
                                                                                                                  width: 80,
                                                                                                                  fit: BoxFit.cover,
                                                                                                                  errorBuilder: (context, error, stackTrace) {
                                                                                                                    return const Icon(Icons.error); // Placeholder for errors
                                                                                                                  },
                                                                                                                ),
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    );
                                                                                                  },
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    )
                                                                                  : const Center(
                                                                                      child: Text("No images selected."),
                                                                                    ),
                                                                              const SizedBox(height: 8.0),
                                                                              Row(
                                                                                children: [
                                                                                  const SizedBox(
                                                                                    width: 0,
                                                                                  ),
                                                                                  GestureDetector(
                                                                                    onTap: () async {
                                                                                      await _uploadAllImages();
                                                                                      if (unitnum.text.trim().isEmpty || street3.text.trim().isEmpty || sqft3.text.trim().isEmpty) {
                                                                                        setState(() {
                                                                                          iserror = true;
                                                                                        });
                                                                                      } else {
                                                                                        setState(() {
                                                                                          isLoading = true;
                                                                                          iserror = false;
                                                                                        });
                                                                                        SharedPreferences prefs = await SharedPreferences.getInstance();
                                                                                        String? id = prefs.getString("adminId");
                                                                                        List<String> combinedImageUrls = [
                                                                                          ..._imageUrls,
                                                                                          ..._editimageUrls.where((url) => !_imageUrls.contains(url))
                                                                                        ];

                                                                                        Properies_summery_Repo()
                                                                                            .Editunit(
                                                                                          rentalunit: unitnum.text.trim(),
                                                                                          rentalsqft: sqft3.text.trim(),
                                                                                          rentalImages: combinedImageUrls,
                                                                                          rentalunitadress: street3.text.trim(),
                                                                                          unitId: Propertytype.unitId!,
                                                                                          rentalId: Propertytype.rentalId!,
                                                                                        )
                                                                                            .then((value) {
                                                                                          setState(() {
                                                                                            isLoading = false;
                                                                                          });
                                                                                          Navigator.of(context).pop(true);
                                                                                          reload_Screen();
                                                                                        }).catchError((e) {
                                                                                          setState(() {
                                                                                            isLoading = false;
                                                                                          });
                                                                                        });
                                                                                      }
                                                                                    },
                                                                                    child: Material(
                                                                                      elevation: 3,
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(5),
                                                                                      ),
                                                                                      child: Container(
                                                                                        height: 30,
                                                                                        width: 80,
                                                                                        decoration: BoxDecoration(
                                                                                          color: blueColor,
                                                                                          borderRadius: const BorderRadius.all(
                                                                                            Radius.circular(5),
                                                                                          ),
                                                                                        ),
                                                                                        child: const Center(
                                                                                            child: Text(
                                                                                          "Save",
                                                                                          style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                                                        )),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  const SizedBox(width: 10),
                                                                                  GestureDetector(
                                                                                    onTap: () {
                                                                                      Navigator.pop(context);
                                                                                    },
                                                                                    child: Material(
                                                                                      elevation: 3,
                                                                                      borderRadius: const BorderRadius.all(
                                                                                        Radius.circular(5),
                                                                                      ),
                                                                                      child: Container(
                                                                                        height: 30,
                                                                                        width: 80,
                                                                                        decoration: const BoxDecoration(
                                                                                          color: Colors.white,
                                                                                          borderRadius: BorderRadius.all(
                                                                                            Radius.circular(5),
                                                                                          ),
                                                                                        ),
                                                                                        child: Center(
                                                                                            child: Text(
                                                                                          "Cancel",
                                                                                          style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                                                        )),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 8.0),
                                                                              if (iserror)
                                                                                const Text(
                                                                                  "Please fill in all fields correctly.",
                                                                                  style: TextStyle(color: Colors.redAccent),
                                                                                ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  );
                                                                },
                                                              );
                                                            }
                                                          },
                                                          child:
                                                          Container(
                                                            height: 35,
                                                            width: 35,
                                                            decoration: BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                                color: Colors
                                                                    .green
                                                                    .shade50), // color:Colors.grey[100],
                                                            child: const Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .edit,
                                                                  size: 15,
                                                                  color: Colors
                                                                      .green,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          width: 10,
                                                        ),
                                                        GestureDetector(
                                                          onTap: () {
                                                            setState(() {
                                                              showdetails =
                                                                  true;
                                                              unit =
                                                                  Propertytype;
                                                            });
                                                          },
                                                          child:
                                                          Container(
                                                            height: 35,
                                                            width: 35,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: Colors.grey
                                                                  .shade200,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          8),
                                                            ),
                                                            child: const Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                FaIcon(
                                                                  FontAwesomeIcons
                                                                      .eye,
                                                                  size: 15,
                                                                  color: Colors
                                                                      .black,
                                                                ),
                                                                SizedBox(
                                                                    width: 2),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          width: 15,
                                                        ),
                                                      ],
                                                    ),
                                                    const SizedBox(
                                                      height:10 ,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          //SizedBox(height: 13,),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Row(
                                    children: [
                                      // Text('Rows per page:'),
                                      const SizedBox(width: 10),
                                      Material(
                                        elevation: 3,
                                        child: Container(
                                          height: 40,
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 12.0),
                                          decoration: BoxDecoration(
                                            border:
                                                Border.all(color: Colors.grey),
                                          ),
                                          child: DropdownButtonHideUnderline(
                                            child: DropdownButton<int>(
                                              value: itemsPerPagemulti,
                                              items: itemsPerPageOptionsmulti
                                                  .map((int value) {
                                                return DropdownMenuItem<int>(
                                                  value: value,
                                                  child: Text(value.toString()),
                                                );
                                              }).toList(),
                                              onChanged: (newValue) {
                                                setState(() {
                                                  itemsPerPagemulti = newValue!;
                                                  currentPagemulti =
                                                      0; // Reset to first page when items per page change
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      IconButton(
                                        icon: FaIcon(
                                          FontAwesomeIcons.circleChevronLeft,
                                          color: currentPagemulti == 0
                                              ? Colors.grey
                                              : blueColor,
                                        ),
                                        onPressed: currentPagemulti == 0
                                            ? null
                                            : () {
                                                setState(() {
                                                  currentPagemulti--;
                                                });
                                              },
                                      ),
                                      // IconButton(
                                      //   icon: Icon(Icons.arrow_back),
                                      //   onPressed: currentPage > 0
                                      //       ? () {
                                      //     setState(() {
                                      //       currentPage--;
                                      //     });
                                      //   }
                                      //       : null,
                                      // ),
                                      Text(
                                          'Page ${currentPagemulti + 1} of $totalPages'),
                                      // IconButton(
                                      //   icon: Icon(Icons.arrow_forward),
                                      //   onPressed: currentPage < totalPages - 1
                                      //       ? () {
                                      //     setState(() {
                                      //       currentPage++;
                                      //     });
                                      //   }
                                      //       : null,
                                      // ),
                                      IconButton(
                                        icon: FaIcon(
                                          FontAwesomeIcons.circleChevronRight,
                                          color:
                                              currentPagemulti < totalPages - 1
                                                  ? blueColor
                                                  : Colors.grey,
                                        ),
                                        onPressed:
                                            currentPagemulti < totalPages - 1
                                                ? () {
                                                    setState(() {
                                                      currentPagemulti++;
                                                    });
                                                  }
                                                : null,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }
                    },
                  ),
                ),
            if (MediaQuery.of(context).size.width > 500)
              FutureBuilder<List<unit_properties>>(
                future: futureUnitsummery,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: SpinKitFadingCircle(
                        color: Colors.black,
                        size: 55.0,
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Container(
                      height: MediaQuery.of(context).size.height * .5,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/images/no_data.jpg",
                              height: 200,
                              width: 200,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              "No Data Available",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: blueColor,
                                  fontSize: 16),
                            )
                          ],
                        ),
                      ),
                    );
                  } else {
                    _tableDatamulti = snapshot.data!;
                    if (selectedValue == null && searchvalue.isEmpty) {
                      _tableDatamulti = snapshot.data!;
                    } else if (selectedValue == "All") {
                      _tableDatamulti = snapshot.data!;
                    } else if (searchvalue.isNotEmpty) {
                      _tableDatamulti = snapshot.data!
                          .where((property) =>
                              property.rentalunit!
                                  .toLowerCase()
                                  .contains(searchvalue.toLowerCase()) ||
                              property.rentalunitadress!
                                  .toLowerCase()
                                  .contains(searchvalue.toLowerCase()))
                          .toList();
                    } else {
                      _tableDatamulti = snapshot.data!
                          .where((property) =>
                              property.rentalunit == selectedValue)
                          .toList();
                    }
                    totalrecordsmulti = _tableDatamulti.length;

                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          const SizedBox(height: 10),
                          Container(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24.0, vertical: 5),
                              child: Column(
                                children: [
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          .91,
                                      child: Table(
                                        defaultColumnWidth:
                                            const IntrinsicColumnWidth(),
                                        children: [
                                          TableRow(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  // color: blueColor
                                                  ),
                                            ),
                                            children: [
                                              _buildHeadermulti(
                                                  'Unit',
                                                  0,
                                                  (rental) =>
                                                      rental.rentalunit!),
                                              _buildHeadermulti(
                                                  'Adress',
                                                  1,
                                                  (rental) =>
                                                      rental.rentalunitadress!),
                                              _buildHeadermulti(
                                                  'Tenants',
                                                  2,
                                                  (rental) =>
                                                      rental.tenantCount!),
                                              _buildHeadermulti(
                                                  'Actions', 3, null),
                                            ],
                                          ),
                                          TableRow(
                                            decoration: const BoxDecoration(
                                              border: Border.symmetric(
                                                  horizontal: BorderSide.none),
                                            ),
                                            children: List.generate(
                                                4,
                                                (index) => TableCell(
                                                    child:
                                                        Container(height: 20))),
                                          ),
                                          for (var i = 0;
                                              i < _pagedDatamulti.length;
                                              i++)
                                            TableRow(
                                              decoration: BoxDecoration(
                                                border: Border(
                                                  left: BorderSide(
                                                      color: blueColor),
                                                  right: BorderSide(
                                                      color: blueColor),
                                                  top: BorderSide(
                                                      color: blueColor),
                                                  bottom: i ==
                                                          _pagedDatamulti
                                                                  .length -
                                                              1
                                                      ? BorderSide(
                                                          color: blueColor)
                                                      : BorderSide.none,
                                                ),
                                              ),
                                              children: [
                                                InkWell(
                                                  onTap: () {
                                                    setState(() {
                                                      showdetails = true;
                                                      unit =
                                                          _tableDatamulti.first;
                                                    });
                                                  },
                                                  child: _buildDataCellmulti(
                                                      _pagedDatamulti[i]
                                                          .rentalunit!),
                                                ),
                                                // _buildDataCell('${_pagedData[i].rentalOwnerFirstName ?? ''} ${_pagedData[i].rentalOwnerLastName ?? ''}'),
                                                _buildDataCellmulti(
                                                    _pagedDatamulti[i]
                                                        .rentalunitadress!),
                                                _buildDataCellmulti(
                                                    _pagedDatamulti[i]
                                                        .tenantCount!
                                                        .toString()),
                                                Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    const SizedBox(
                                                      height: 13,
                                                    ),
                                                    Container(
                                                      child: Row(
                                                        children: [
                                                          const SizedBox(
                                                            width: 10,
                                                          ),
                                                          InkWell(
                                                            onTap: () {
                                                              unitnum.text =
                                                                  _tableDatamulti
                                                                      .first
                                                                      .rentalunit!;
                                                              street3.text =
                                                                  _tableDatamulti
                                                                      .first
                                                                      .rentalunitadress!;
                                                              sqft3.text =
                                                                  _tableDatamulti
                                                                      .first
                                                                      .rentalsqft!!;
                                                              bath3.text =
                                                                  _tableDatamulti
                                                                      .first
                                                                      .rentalbath!;
                                                              bed3.text =
                                                                  _tableDatamulti
                                                                      .first
                                                                      .rentalbed!;
                                                              if (widget
                                                                      .properties
                                                                      .propertyTypeData!
                                                                      .isMultiunit! &&
                                                                  widget
                                                                          .properties
                                                                          .propertyTypeData!
                                                                          .propertyType ==
                                                                      'Residential') {
                                                                showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (BuildContext
                                                                          context) {
                                                                    // Moved isChecked inside the StatefulBuilder
                                                                    return StatefulBuilder(
                                                                      builder: (BuildContext
                                                                              context,
                                                                          StateSetter
                                                                              setState) {
                                                                        return AlertDialog(
                                                                          backgroundColor:
                                                                              Colors.white,
                                                                          surfaceTintColor:
                                                                              Colors.white,
                                                                          content:
                                                                              SingleChildScrollView(
                                                                            child:
                                                                                Column(
                                                                              children: [
                                                                                Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Edit Unit Details",
                                                                                      style: TextStyle(
                                                                                        color: blueColor,
                                                                                        fontWeight: FontWeight.bold,
                                                                                      ),
                                                                                    ),
                                                                                    const Spacer(),
                                                                                    Align(
                                                                                      alignment: Alignment.centerRight,
                                                                                      child: InkWell(
                                                                                        onTap: () {
                                                                                          Navigator.pop(context);
                                                                                        },
                                                                                        child: const Icon(Icons.close, color: Colors.black),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Unit Number",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: unitnum,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Street Address",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: street3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "SQFT",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: sqft3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "bath",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: bath3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "bed",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: bed3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      'Photo',
                                                                                      style: TextStyle(color: Colors.black),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 8.0),
                                                                                Row(
                                                                                  children: [
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        _pickImage().then((_) {
                                                                                          setState(() {}); // Rebuild the widget after selecting the image
                                                                                        });
                                                                                      },
                                                                                      child: const Text(
                                                                                        '+ Add',
                                                                                        style: TextStyle(color: Colors.green),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                _image != null
                                                                                    ? Column(
                                                                                        children: [
                                                                                          Image.file(
                                                                                            _image!,
                                                                                            height: 80,
                                                                                            width: 80,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                          Text(_uploadedFileName ?? ""),
                                                                                        ],
                                                                                      )
                                                                                    : const Text(''),
                                                                                const SizedBox(height: 8.0),
                                                                                Row(
                                                                                  children: [
                                                                                    const SizedBox(
                                                                                      width: 0,
                                                                                    ),
                                                                                    GestureDetector(
                                                                                      onTap: () async {
                                                                                        if (unitnum.text.isEmpty || street3.text.isEmpty || sqft3.text.isEmpty || bath3.text.isEmpty || bed3.text.isEmpty) {
                                                                                          setState(() {
                                                                                            iserror = true;
                                                                                          });
                                                                                        } else {
                                                                                          setState(() {
                                                                                            isLoading = true;
                                                                                            iserror = false;
                                                                                          });
                                                                                          SharedPreferences prefs = await SharedPreferences.getInstance();

                                                                                          String? id = prefs.getString("adminId");
                                                                                          Properies_summery_Repo().Editunit(rentalunit: unitnum.text, rentalsqft: sqft3.text, rentalunitadress: street3.text, rentalbath: bath3.text, rentalbed: bed3.text, unitId: _tableDatamulti.first.unitId!, adminId: id, rentalId: _tableDatamulti.first.rentalId!).then((value) {
                                                                                            setState(() {
                                                                                              isLoading = false;
                                                                                            });

                                                                                            Navigator.of(context).pop(true);
                                                                                            reload_Screen();
                                                                                          }).catchError((e) {
                                                                                            setState(() {
                                                                                              isLoading = false;
                                                                                            });
                                                                                          });
                                                                                        }
                                                                                      },
                                                                                      child: Material(
                                                                                        elevation: 3,
                                                                                        borderRadius: const BorderRadius.all(
                                                                                          Radius.circular(5),
                                                                                        ),
                                                                                        child: Container(
                                                                                          height: 30,
                                                                                          width: 80,
                                                                                          decoration: BoxDecoration(
                                                                                            color: blueColor,
                                                                                            borderRadius: const BorderRadius.all(
                                                                                              Radius.circular(5),
                                                                                            ),
                                                                                          ),
                                                                                          child: const Center(
                                                                                              child: Text(
                                                                                            "Save",
                                                                                            style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                                                          )),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                    const SizedBox(width: 10),
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: Material(
                                                                                        elevation: 3,
                                                                                        borderRadius: const BorderRadius.all(
                                                                                          Radius.circular(5),
                                                                                        ),
                                                                                        child: Container(
                                                                                          height: 30,
                                                                                          width: 80,
                                                                                          decoration: const BoxDecoration(
                                                                                            color: Colors.white,
                                                                                            borderRadius: BorderRadius.all(
                                                                                              Radius.circular(5),
                                                                                            ),
                                                                                          ),
                                                                                          child: Center(
                                                                                              child: Text(
                                                                                            "Cancel",
                                                                                            style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                                                          )),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 8.0),
                                                                                if (iserror)
                                                                                  const Text(
                                                                                    "Please fill in all fields correctly.",
                                                                                    style: TextStyle(color: Colors.redAccent),
                                                                                  ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        );
                                                                      },
                                                                    );
                                                                  },
                                                                );
                                                              }
                                                              if (widget
                                                                      .properties
                                                                      .propertyTypeData!
                                                                      .isMultiunit! &&
                                                                  widget
                                                                          .properties
                                                                          .propertyTypeData!
                                                                          .propertyType ==
                                                                      'Commercial') {
                                                                showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (BuildContext
                                                                          context) {
                                                                    bool
                                                                        isChecked =
                                                                        false; // Moved isChecked inside the StatefulBuilder
                                                                    return StatefulBuilder(
                                                                      builder: (BuildContext
                                                                              context,
                                                                          StateSetter
                                                                              setState) {
                                                                        return AlertDialog(
                                                                          backgroundColor:
                                                                              Colors.white,
                                                                          surfaceTintColor:
                                                                              Colors.white,
                                                                          content:
                                                                              SingleChildScrollView(
                                                                            child:
                                                                                Column(
                                                                              children: [
                                                                                Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Edit Unit Details",
                                                                                      style: TextStyle(
                                                                                        color: blueColor,
                                                                                        fontWeight: FontWeight.bold,
                                                                                      ),
                                                                                    ),
                                                                                    const Spacer(),
                                                                                    Align(
                                                                                      alignment: Alignment.centerRight,
                                                                                      child: InkWell(
                                                                                        onTap: () {
                                                                                          Navigator.pop(context);
                                                                                        },
                                                                                        child: const Icon(Icons.close, color: Colors.black),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Unit Number",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: unitnum,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "Street Address",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: street3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      "SQFT",
                                                                                      style: TextStyle(color: Color(0xFF8A95A8), fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.symmetric(vertical: 1),
                                                                                  child: Material(
                                                                                    elevation: 3,
                                                                                    borderRadius: BorderRadius.circular(3),
                                                                                    child: TextFormField(
                                                                                      controller: sqft3,
                                                                                      cursorColor: Colors.black,
                                                                                      decoration: InputDecoration(
                                                                                        //  hintText: label,
                                                                                        // labelText: label,
                                                                                        // labelStyle: TextStyle(color: Colors.grey[700]),
                                                                                        filled: true,
                                                                                        fillColor: Colors.white,
                                                                                        border: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: BorderSide.none,
                                                                                        ),
                                                                                        enabledBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8)),
                                                                                        ),
                                                                                        focusedBorder: OutlineInputBorder(
                                                                                          borderRadius: BorderRadius.circular(3),
                                                                                          borderSide: const BorderSide(color: Color(0xFF8A95A8), width: 2),
                                                                                        ),
                                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                const SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                const Row(
                                                                                  children: [
                                                                                    Text(
                                                                                      'Photo',
                                                                                      style: TextStyle(color: Colors.black),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 8.0),
                                                                                Row(
                                                                                  children: [
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        _pickImage().then((_) {
                                                                                          setState(() {}); // Rebuild the widget after selecting the image
                                                                                        });
                                                                                      },
                                                                                      child: const Text(
                                                                                        '+ Add',
                                                                                        style: TextStyle(color: Colors.green),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 8.0),
                                                                                _image != null
                                                                                    ? Column(
                                                                                        children: [
                                                                                          Image.file(
                                                                                            _image!,
                                                                                            height: 80,
                                                                                            width: 80,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                          Text(_uploadedFileName ?? ""),
                                                                                        ],
                                                                                      )
                                                                                    : const Text(''),
                                                                                const SizedBox(height: 8.0),
                                                                                Row(
                                                                                  children: [
                                                                                    const SizedBox(
                                                                                      width: 0,
                                                                                    ),
                                                                                    GestureDetector(
                                                                                      onTap: () async {
                                                                                        if (unitnum.text.isEmpty || street3.text.isEmpty || sqft3.text.isEmpty) {
                                                                                          setState(() {
                                                                                            iserror = true;
                                                                                          });
                                                                                        } else {
                                                                                          setState(() {
                                                                                            isLoading = true;
                                                                                            iserror = false;
                                                                                          });
                                                                                          SharedPreferences prefs = await SharedPreferences.getInstance();
                                                                                          String? id = prefs.getString("adminId");
                                                                                          Properies_summery_Repo()
                                                                                              .Editunit(
                                                                                            rentalunit: unitnum.text,
                                                                                            rentalsqft: sqft3.text,
                                                                                            rentalunitadress: street3.text,
                                                                                            unitId: _tableDatamulti.first.unitId!,
                                                                                          )
                                                                                              .then((value) {
                                                                                            setState(() {
                                                                                              isLoading = false;
                                                                                            });
                                                                                            Navigator.of(context).pop(true);
                                                                                          }).catchError((e) {
                                                                                            setState(() {
                                                                                              isLoading = false;
                                                                                            });
                                                                                          });
                                                                                        }
                                                                                      },
                                                                                      child: Material(
                                                                                        elevation: 3,
                                                                                        borderRadius: const BorderRadius.all(
                                                                                          Radius.circular(5),
                                                                                        ),
                                                                                        child: Container(
                                                                                          height: 30,
                                                                                          width: 80,
                                                                                          decoration: BoxDecoration(
                                                                                            color: blueColor,
                                                                                            borderRadius: const BorderRadius.all(
                                                                                              Radius.circular(5),
                                                                                            ),
                                                                                          ),
                                                                                          child: const Center(
                                                                                              child: Text(
                                                                                            "Save",
                                                                                            style: TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
                                                                                          )),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                    const SizedBox(width: 10),
                                                                                    GestureDetector(
                                                                                      onTap: () {
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: Material(
                                                                                        elevation: 3,
                                                                                        borderRadius: const BorderRadius.all(
                                                                                          Radius.circular(5),
                                                                                        ),
                                                                                        child: Container(
                                                                                          height: 30,
                                                                                          width: 80,
                                                                                          decoration: const BoxDecoration(
                                                                                            color: Colors.white,
                                                                                            borderRadius: BorderRadius.all(
                                                                                              Radius.circular(5),
                                                                                            ),
                                                                                          ),
                                                                                          child: Center(
                                                                                              child: Text(
                                                                                            "Cancel",
                                                                                            style: TextStyle(fontWeight: FontWeight.w500, color: blueColor),
                                                                                          )),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 8.0),
                                                                                if (iserror)
                                                                                  const Text(
                                                                                    "Please fill in all fields correctly.",
                                                                                    style: TextStyle(color: Colors.redAccent),
                                                                                  ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        );
                                                                      },
                                                                    );
                                                                  },
                                                                );
                                                              }
                                                            },
                                                            child: Container(
                                                              child: FaIcon(
                                                                FontAwesomeIcons
                                                                    .edit,
                                                                size: 20,
                                                                color:
                                                                    blueColor,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 25),
                                  _buildPaginationControlsmulti(),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 25),
                        ],
                      ),
                    );
                  }
                },
              ),
          ],
        ),
      ),
    );
  }

  reloadScreen() {
    setState(() {});
  }

  unitScreen1(BuildContext context, unit_properties unit) {
    print('unit idsss ${unit?.unitId}');
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              //height: screenHeight * 0.82,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.0),
                color: Colors.white,
                border: Border.all(
                  color: blueColor,
                  width: 1,
                ),
              ),
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.start,
                // crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 5,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height:
                              MediaQuery.of(context).size.width < 500 ? 36 : 50,
                          width:
                              MediaQuery.of(context).size.width < 500 ? 76 : 80,
                          child: ElevatedButton(
                            onPressed: () {
                              setState(() {
                                showdetails = false;
                              });
                              // Navigator.pop(context);
                            },
                            child: Text(
                              'Back',
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 14
                                          : 20,
                                  color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                                backgroundColor: blueColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0))),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height:
                              MediaQuery.of(context).size.width < 500 ? 36 : 50,
                          width: MediaQuery.of(context).size.width < 500
                              ? 136
                              : 150,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: blueColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0))),
                            onPressed: () async {
                              var data = await Properies_summery_Repo()
                                  .Deleteunit(unitId: unit?.unitId!);
                              // Add your delete logic here
                              setState(() {
                                futureUnitsummery = Properies_summery_Repo()
                                    .fetchunit(
                                        widget.properties.rentalId ?? "");
                                showdetails = false;
                                // Update unit count after deletion
                                unitCount = unitCount > 0 ? unitCount - 1 : 0;
                              });
                              //Navigator.pop(context);
                            },
                            child: Text(
                              'Delete unit',
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 14
                                          : 20,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 15,
                      ),
                      SizedBox(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: CachedNetworkImage(
                            imageUrl: unit.rentalImages != null &&
                                    unit.rentalImages!.length > 0
                                ? "$image_url${unit.rentalImages!.first}"
                                : 'assets/images/no_image.jpg',
                            fit: BoxFit.cover,
                            height: MediaQuery.of(context).size.width < 500
                                ? 140
                                : 220,
                            width: MediaQuery.of(context).size.width < 500
                                ? 160
                                : 220,
                            placeholder: (context, url) => Shimmer.fromColors(
                              baseColor: Colors.grey[300]!,
                              highlightColor: Colors.grey[100]!,
                              child: Container(
                                color: Colors.grey[300],
                                height: MediaQuery.of(context).size.width < 500
                                    ? 140
                                    : 220,
                                width: MediaQuery.of(context).size.width < 500
                                    ? 160
                                    : 220,
                              ),
                            ),
                            errorWidget: (context, url, error) => Image.asset(
                              "assets/images/no_image.jpg",
                              fit: BoxFit.fill,
                            ), // Hides the error widget
                          ),
                        ),
                      ),
                      const Spacer(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12, bottom: 5),
                            child: Text(
                              '${unit?.rentalunit}',
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 14
                                          : 20,
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 12),
                            child: Text(
                              'ADDRESS',
                              style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 14
                                          : 20,
                                  color: grey,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width > 500
                                ? 200
                                : 140,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 12),
                              child: Text(
                                '${widget.properties?.rentalAddress}',
                                maxLines: 3, // Set maximum number of lines
                                overflow: TextOverflow
                                    .ellipsis, // Handle overflow with ellipsis
                                style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 13
                                          : 18,
                                  color: blueColor,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width > 500
                                ? 200
                                : 140,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 12),
                              child: Text(
                                [
                                  widget.properties.rentalCity,
                                  widget.properties.rentalState,
                                  widget.properties.rentalCountry,
                                  widget.properties.rentalPostcode,
                                ]
                                    .where((element) =>
                                        element != null &&
                                        element
                                            .isNotEmpty) // Filter out null or empty elements
                                    .map((element) =>
                                        element!) // Ensure non-null elements
                                    .join(' , '),
                                style: TextStyle(
                                  color: blueColor,
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 13
                                          : 18,
                                ),
                                maxLines: 6,
                              ),
                            ),
                          ),
                          // Padding(
                          //   padding: const EdgeInsets.only(left: 8),
                          //   child: Text(
                          //     maxLines: 4,
                          //     '${widget.properties?.rentalCity} ${widget.properties?.rentalState}',
                          //     overflow: TextOverflow.ellipsis,
                          //     style: TextStyle(
                          //         fontSize:
                          //             MediaQuery.of(context).size.width < 500
                          //                 ? 13
                          //                 : 18,
                          //         color: Colors.grey[800]),
                          //   ),
                          // ),
                          // SizedBox(
                          //   height: 5,
                          // ),
                          // Padding(
                          //   padding: const EdgeInsets.only(left: 12),
                          //   child: Text(
                          //     '${widget.properties?.rentalCountry} ${widget.properties?.rentalPostcode}',
                          //     style: TextStyle(
                          //         fontSize:
                          //             MediaQuery.of(context).size.width < 500
                          //                 ? 13
                          //                 : 18,
                          //         color: Colors.grey[800]),
                          //   ),
                          // ),
                        ],
                      ),
                      const Spacer(),
                      if (MediaQuery.of(context).size.width > 500)
                        Row(
                          children: [
                            const SizedBox(
                              width: 10,
                            ),
                            Container(
                              width: 250,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12.0),
                                color: Colors.white,
                                border: Border.all(
                                  color: blueColor,
                                  width: 1,
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  SizedBox(
                                    // width: double.infinity,
                                    child: Text(
                                      'Add Lease',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 14
                                                : 18,
                                        fontWeight: FontWeight.bold,
                                        color: blueColor,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.width <
                                                  500
                                              ? 36
                                              : 48,
                                      // width: double.infinity,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      addLease3(
                                                        rentalId: widget
                                                            .properties
                                                            .rentalId,
                                                        unitId: unit.unitId,
                                                      )));
                                        },
                                        child: Text(
                                          '       Add Lease    ',
                                          style: TextStyle(
                                              fontSize: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 14
                                                  : 18,
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: blueColor,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        10.0))),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: SizedBox(
                                      //  width: double.infinity,
                                      child: Text(
                                        'Rental Applicant',
                                        style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 14
                                              : 18,
                                          fontWeight: FontWeight.bold,
                                          color: blueColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.width <
                                                  500
                                              ? 36
                                              : 48,
                                      //  width: double.infinity,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      Applicants_table()));
                                        },
                                        child: Text(
                                          'Create Applicant',
                                          style: TextStyle(
                                              fontSize: MediaQuery.of(context)
                                                          .size
                                                          .width <
                                                      500
                                                  ? 14
                                                  : 18,
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: blueColor,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        10.0))),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      const SizedBox(
                        width: 15,
                      ),
                    ],
                  ),
                  // Padding(
                  //   padding: const EdgeInsets.all(16.0),
                  //   child:
                  //   Container(
                  //     width: double.infinity,
                  //     child:
                  //     Column(
                  //       crossAxisAlignment: CrossAxisAlignment.start,
                  //       children: [
                  //         Padding(
                  //           padding: const EdgeInsets.only(left: 16),
                  //           child: Text(
                  //             'ADDRESS',
                  //             style: TextStyle(
                  //                 fontSize:
                  //                 MediaQuery.of(context).size.width < 500
                  //                 ? 12
                  //                 : 20, color: Colors.grey[800],fontWeight: FontWeight.bold),
                  //           ),
                  //         ),
                  //         Padding(
                  //           padding: const EdgeInsets.only(left: 16),
                  //           child: Text(
                  //             '${widget.properties?.rentalAddress}',
                  //             style: TextStyle(
                  //                 fontSize:
                  //                 MediaQuery.of(context).size.width < 500
                  //                     ? 12
                  //                     : 18, color: Colors.grey[800]),
                  //           ),
                  //         ),
                  //         Padding(
                  //           padding: const EdgeInsets.only(left: 16),
                  //           child: Text(
                  //             '${widget.properties?.rentalCity} ${widget.properties?.rentalState}',
                  //             style: TextStyle(
                  //                 fontSize:
                  //                 MediaQuery.of(context).size.width < 500
                  //                     ? 12
                  //                     : 18, color: Colors.grey[800]),
                  //           ),
                  //         ),
                  //         Padding(
                  //           padding: const EdgeInsets.only(left: 16),
                  //           child: Text(
                  //             '${widget.properties?.rentalCountry} ${widget.properties?.rentalPostcode}',
                  //             style: TextStyle(
                  //                 fontSize:
                  //                 MediaQuery.of(context).size.width < 500
                  //                     ? 12
                  //                     : 18, color: Colors.grey[800]),
                  //           ),
                  //         ),
                  //       ],
                  //     ),
                  //   ),
                  // ),
                  if (MediaQuery.of(context).size.width < 500)
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Container(
                        // height: screenHeight * 0.26,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.0),
                          color: Colors.white,
                          border: Border.all(
                            color: blueColor,
                            width: 1,
                          ),
                        ),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SizedBox(
                                width: double.infinity,
                                child: Text(
                                  'Add Lease',
                                  style: TextStyle(
                                    fontSize:
                                        MediaQuery.of(context).size.width < 500
                                            ? 14
                                            : 18,
                                    fontWeight: FontWeight.bold,
                                    color: blueColor,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                height: MediaQuery.of(context).size.width < 500
                                    ? 36
                                    : 48,
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.of(context)
                                        .push(MaterialPageRoute(
                                            builder: (context) => addLease3(
                                                  rentalId: widget
                                                      .properties.rentalId,
                                                  unitId: unit.unitId,
                                                )));
                                  },
                                  child: Text(
                                    'Add Lease',
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 14
                                                : 18,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: blueColor,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10.0))),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SizedBox(
                                width: double.infinity,
                                child: Text(
                                  'Rental Applicant',
                                  style: TextStyle(
                                    fontSize:
                                        MediaQuery.of(context).size.width < 500
                                            ? 14
                                            : 18,
                                    fontWeight: FontWeight.bold,
                                    color: blueColor,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                height: MediaQuery.of(context).size.width < 500
                                    ? 36
                                    : 48,
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Applicants_table()));
                                  },
                                  child: Text(
                                    'Create Applicant',
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width <
                                                    500
                                                ? 14
                                                : 18,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: blueColor,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10.0))),
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (MediaQuery.of(context).size.width > 500)
                    const SizedBox(
                      height: 20,
                    ),
                ],
              ),
            ),
          ),
          LeasesTable(
            unit: unit,
          ),
          // LeasesTable1(context,unit!),
          // LeasesTable(context),
          AppliancesPart(
            unit: unit,
          ),
        ],
      ),
    );
  }

  Infrastructure_page(List<unit_properties> unit) {
    return InfrastructurePart(
      properties: widget.properties,
      units: unit,
    );
  }

  Mortgage_page(List<unit_properties> unit) {
    return PropertyMortgageTable(
      propertyId: widget.properties.rentalId ?? "",
      showAppBar: false,
      showDrawer: false,
      showAddButton: true,
    );
  }

  PropertyTax_page(List<unit_properties> unit) {
    return Property_tax_Table(
      propertyId: widget.properties.rentalId ?? "",
      showAppBar: false,
      showDrawer: false,
      showAddButton: true,
    );
  }

  Workorder(BuildContext context) {
    final dateProvider = Provider.of<DateProvider>(context);
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          //add Data

          Padding(
            padding: const EdgeInsets.only(left: 11, right: 11),
            child: Row(
              children: [
                if (MediaQuery.of(context).size.width < 500) const SizedBox(width: 2),
                if (MediaQuery.of(context).size.width > 500) const SizedBox(width: 8),
                Material(
                  elevation: 3,
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    // height: 40,
                    height: MediaQuery.of(context).size.width < 500 ? 45 : 50,
                    width: MediaQuery.of(context).size.width < 500
                        ? MediaQuery.of(context).size.width * .52
                        : MediaQuery.of(context).size.width * .49,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        // border: Border.all(color: Colors.grey),
                        border: Border.all(color: const Color(0xFF8A95A8))),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: TextField(
                            style: TextStyle(
                                fontSize:
                                    MediaQuery.of(context).size.width < 500
                                        ? 12
                                        : 14),
                            // onChanged: (value) {
                            //   setState(() {
                            //     cvverror = false;
                            //   });
                            // },
                            // controller: cvv,
                            onChanged: (value) {
                              setState(() {
                                searchvalue = value;
                              });
                            },
                            cursorColor: blueColor,
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: "Search here...",
                                hintStyle: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width < 500
                                          ? 14
                                          : 18,
                                  // fontWeight: FontWeight.bold,
                                  color: const Color(0xFF8A95A8),
                                ),
                                contentPadding: const EdgeInsets.only(
                                    left: 5, bottom: 10, top: 5)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                DropdownButtonHideUnderline(
                  child: Material(
                    elevation: 3,
                    borderRadius: BorderRadius.circular(8),
                    child: DropdownButton2<String>(
                      isExpanded: true,
                      hint: const Row(
                        children: [
                          SizedBox(
                            width: 4,
                          ),
                          Expanded(
                            child: Text(
                              'Type',
                              style: TextStyle(
                                fontSize: 14,
                                // fontWeight: FontWeight.bold,
                                color: Color(0xFF8A95A8),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      items: items
                          .map((String item) => DropdownMenuItem<String>(
                                value: item,
                                child: Text(
                                  item,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ))
                          .toList(),
                      value: selectedValue,
                      onChanged: (value) {
                        setState(() {
                          selectedValue = value;
                        });
                      },
                      buttonStyleData: ButtonStyleData(
                        height:
                            MediaQuery.of(context).size.width < 500 ? 45 : 50,
                        // width: 180,
                        width: MediaQuery.of(context).size.width < 500
                            ? MediaQuery.of(context).size.width * .38
                            : MediaQuery.of(context).size.width * .4,
                        padding: const EdgeInsets.only(left: 14, right: 14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            // color: Colors.black26,
                            color: const Color(0xFF8A95A8),
                          ),
                          color: Colors.white,
                        ),
                        elevation: 0,
                      ),
                      dropdownStyleData: DropdownStyleData(
                        maxHeight: 250,
                        width: 200,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          //color: Colors.redAccent,
                        ),
                        offset: const Offset(-20, 0),
                        scrollbarTheme: ScrollbarThemeData(
                          radius: const Radius.circular(40),
                          thickness: MaterialStateProperty.all(6),
                          thumbVisibility: MaterialStateProperty.all(true),
                        ),
                      ),
                      menuItemStyleData: const MenuItemStyleData(
                        height: 40,
                        padding: EdgeInsets.only(left: 14, right: 14),
                      ),
                    ),
                  ),
                ),
                if (MediaQuery.of(context).size.width < 500) const SizedBox(width: 2),
                if (MediaQuery.of(context).size.width > 500) const SizedBox(width: 8),
              ],
            ),
          ),
          // SizedBox(height: 15),
          if (MediaQuery.of(context).size.width > 500) const SizedBox(height: 20),
          if (MediaQuery.of(context).size.width < 500) const SizedBox(height: 15),
          //search
          Padding(
            padding: const EdgeInsets.only(left: 11, right: 11),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (MediaQuery.of(context).size.width < 500) const SizedBox(width: 5),
                if (MediaQuery.of(context).size.width > 500) const SizedBox(width: 8),
                Row(
                  children: [
                    Text(
                      "Show Completed Task",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: MediaQuery.of(context).size.width > 500
                              ? 20
                              : 12),
                    ),
                    if (MediaQuery.of(context).size.width < 500)
                      const SizedBox(
                        width: 10,
                      ),
                    if (MediaQuery.of(context).size.width > 500)
                      const SizedBox(width: 20),
                    SizedBox(
                      width: MediaQuery.of(context).size.width < 500 ? 24 : 50,
                      height: MediaQuery.of(context).size.width < 500 ? 24 : 50,
                      child: Checkbox(
                        value: isChecked,
                        onChanged: (value) {
                          setState(() {
                            isChecked = value ?? false;
                          });
                        },
                        activeColor: isChecked ? blueColor : Colors.black,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () async {
                    final result =
                        await Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => ResponsiveAddWorkOrder(
                                  rentalid: widget.properties.rentalId,
                                )));
                    if (result == true) {
                      setState(() {
                        futureworkordersummery = Properies_summery_Repo()
                            .fetchWorkOrders(widget.properties.rentalId!);
                      });
                    }
                  },
                  child: Container(
                    height: (MediaQuery.of(context).size.width < 500)
                        ? 40
                        : MediaQuery.of(context).size.width * 0.063,

                    // height:  MediaQuery.of(context).size.width * 0.07,
                    // height:  40,
                    width: MediaQuery.of(context).size.width * 0.29,

                    decoration: BoxDecoration(
                      border: Border.all(color: blueColor),
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Add Work Order",
                            style: TextStyle(
                              color: blueColor,
                              fontWeight: FontWeight.bold,
                              fontSize: MediaQuery.of(context).size.width > 500
                                  ? 20
                                  : 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (MediaQuery.of(context).size.width < 500) const SizedBox(width: 2),
                if (MediaQuery.of(context).size.width > 500) const SizedBox(width: 8),
              ],
            ),
          ),
          if (MediaQuery.of(context).size.width > 500) const SizedBox(height: 25),
          if (MediaQuery.of(context).size.width < 500)
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: FutureBuilder<List<propertiesworkData>>(
                future: futureworkordersummery,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: SpinKitFadingCircle(
                      color: Colors.black,
                      size: 40.0,
                    ));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Container(
                      height: MediaQuery.of(context).size.height * .5,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/images/no_data.jpg",
                              height: 200,
                              width: 200,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              "No Data Available",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: blueColor,
                                  fontSize: 16),
                            )
                          ],
                        ),
                      ),
                    );
                  } else {
                    var data = snapshot.data!;
                    if (selectedValue == null && searchvalue!.isEmpty) {
                      data = snapshot.data!;
                    } else if (selectedValue == "All") {
                      data = snapshot.data!;
                    } else if (searchvalue!.isNotEmpty) {
                      data = snapshot.data!
                          .where((workorder) =>
                              workorder.workSubject!
                                  .toLowerCase()
                                  .contains(searchvalue!.toLowerCase()) ||
                              workorder.workCategory!
                                  .toLowerCase()
                                  .contains(searchvalue!.toLowerCase()))
                          .toList();
                    } else {
                      data = snapshot.data!
                          .where(
                              (workorder) => workorder.status! == selectedValue)
                          .toList();
                      count = data
                          .where((workorder) => workorder.status != 'Completed')
                          .length;
                      complete_count = data
                          .where((workorder) => workorder.status == 'Completed')
                          .length;
                    }
                    if (isChecked) {
                      // data = data
                      //     .where((workorder) => workorder.status == 'Completed')
                      //     .toList();
                      // Provider.of<WorkOrderCountProvider>(context)
                      //     .updateCount(data.length);
                      data = data
                          .where((workorder) => workorder.status == 'Completed')
                          .toList();

                      // Schedule the update after the current frame
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        Provider.of<WorkOrderCountProvider>(context,
                                listen: false)
                            .updateCount(data.length);
                      });
                    } else {
                      data = data
                          .where((workorder) => workorder.status != 'Completed')
                          .toList();
                      /*  Provider.of<WorkOrderCountProvider>(context)
                          .updateCount(data.length);*/
                    }
                    sortData(data);
                    final totalPages = (data.length / itemsPerPage).ceil();
                    final currentPageData = data
                        .skip(currentPage * itemsPerPage)
                        .take(itemsPerPage)
                        .toList();
                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          if (data.isNotEmpty) const SizedBox(height: 10),
                          if (data.isNotEmpty) _buildHeaders(),
                          const SizedBox(height: 10),
                          if (data.isNotEmpty)
                            Container(
                              child: Column(
                                children: currentPageData
                                    .asMap()
                                    .entries
                                    .map((entry) {
                                  int index = entry.key;
                                  bool isExpanded = expandedIndex == index;
                                  propertiesworkData workOrder = entry.value;
                                  //return CustomExpansionTile(data: Data, index: index);
                                  return Container(
                                    margin: const EdgeInsets.symmetric(vertical: 6),
                                    decoration: BoxDecoration(
                                      color: index % 2 != 0
                                          ? const Color(0xFFF4F8FF)
                                          : Colors.white,
                                      border:
                                          Border.all(color: const Color(0xFFDBE0E5)),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Column(
                                      children: <Widget>[
                                        ListTile(
                                          contentPadding: EdgeInsets.zero,
                                          title: Padding(
                                            padding: const EdgeInsets.all(2.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                InkWell(
                                                  onTap: () {
                                                    // setState(() {
                                                    //    isExpanded = !isExpanded;
                                                    // //  expandedIndex = !expandedIndex;
                                                    //
                                                    // });
                                                    // setState(() {
                                                    //   if (isExpanded) {
                                                    //     expandedIndex = null;
                                                    //     isExpanded = !isExpanded;
                                                    //   } else {
                                                    //     expandedIndex = index;
                                                    //   }
                                                    // });
                                                    setState(() {
                                                      if (expandedIndex ==
                                                          index) {
                                                        expandedIndex = null;
                                                      } else {
                                                        expandedIndex = index;
                                                      }
                                                    });
                                                  },
                                                  child: Container(
                                                    margin: const EdgeInsets.only(
                                                        left: 5, right: 8),
                                                    padding: !isExpanded
                                                        ? const EdgeInsets.only(
                                                            bottom: 10)
                                                        : const EdgeInsets.only(
                                                            top: 10),
                                                    child: FaIcon(
                                                      isExpanded
                                                          ? FontAwesomeIcons
                                                              .sortUp
                                                          : FontAwesomeIcons
                                                              .sortDown,
                                                      size: 20,
                                                      color: blueColor,
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 4,
                                                  child: Text(
                                                    '${workOrder.workSubject}',
                                                    style: TextStyle(
                                                      color: blueColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            .05),
                                                Expanded(
                                                  flex: 3,
                                                  child: Text(
                                                    '${workOrder.status}',
                                                    style: TextStyle(
                                                      color: blueColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            .05),
                                                Expanded(
                                                  flex: 2,
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      if (workOrder
                                                              .isBillable ==
                                                          true)
                                                        Icon(
                                                          Icons.check,
                                                          color: blueColor,
                                                        ),
                                                      if (workOrder
                                                              .isBillable ==
                                                          false)
                                                        Icon(
                                                          Icons.close,
                                                          color: blueColor,
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            .02),
                                              ],
                                            ),
                                          ),
                                        ),
                                        if (isExpanded)
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 2),
                                            margin: const EdgeInsets.only(bottom: 1),
                                            child: SingleChildScrollView(
                                              child: Column(
                                                children: [
                                                  // Row(
                                                  //   mainAxisAlignment:
                                                  //   MainAxisAlignment.start,
                                                  //   children: [
                                                  //     FaIcon(
                                                  //       isExpanded
                                                  //           ? FontAwesomeIcons
                                                  //           .sortUp
                                                  //           : FontAwesomeIcons
                                                  //           .sortDown,
                                                  //       size: 50,
                                                  //       color: Colors.transparent,
                                                  //     ),
                                                  //     Expanded(
                                                  //       child: Column(
                                                  //         crossAxisAlignment:
                                                  //         CrossAxisAlignment
                                                  //             .start,
                                                  //         children: <Widget>[
                                                  //           Text.rich(
                                                  //             TextSpan(
                                                  //               children: [
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   ' Category : ',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .bold,
                                                  //                       color:
                                                  //                       blueColor), // Bold and black
                                                  //                 ),
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   '${workOrder.workCategory}',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .w700,
                                                  //                       color: Colors
                                                  //                           .grey), // Light and grey
                                                  //                 ),
                                                  //               ],
                                                  //             ),
                                                  //           ),
                                                  //           SizedBox(
                                                  //             height: 5,
                                                  //           ),
                                                  //           Text.rich(
                                                  //             TextSpan(
                                                  //               children: [
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   'Created At : ',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .bold,
                                                  //                       color:
                                                  //                       blueColor), // Bold and black
                                                  //                 ),
                                                  //                 TextSpan(
                                                  //                   text: formatDate(
                                                  //                       '${workOrder.createdAt}'),
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .w700,
                                                  //                       color: Colors
                                                  //                           .grey), // Light and grey
                                                  //                 ),
                                                  //               ],
                                                  //             ),
                                                  //           ),
                                                  //         ],
                                                  //       ),
                                                  //     ),
                                                  //     SizedBox(width: 5),
                                                  //     Expanded(
                                                  //       child: Column(
                                                  //         crossAxisAlignment:
                                                  //         CrossAxisAlignment
                                                  //             .start,
                                                  //         children: <Widget>[
                                                  //           Text.rich(
                                                  //             TextSpan(
                                                  //               children: [
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   'Assign ',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .bold,
                                                  //                       color:
                                                  //                       blueColor), // Bold and black
                                                  //                 ),
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   '${workOrder.staffmemberName}',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .w700,
                                                  //                       color: Colors
                                                  //                           .grey), // Light and grey
                                                  //                 ),
                                                  //               ],
                                                  //             ),
                                                  //           ),
                                                  //           SizedBox(
                                                  //             height: 5,
                                                  //           ),
                                                  //           Text.rich(
                                                  //             TextSpan(
                                                  //               children: [
                                                  //                 TextSpan(
                                                  //                   text:
                                                  //                   'Updated At : ',
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .bold,
                                                  //                       color:
                                                  //                       blueColor), // Bold and black
                                                  //                 ),
                                                  //                 TextSpan(
                                                  //                   text: formatDate(
                                                  //                       '${workOrder.updatedAt}'),
                                                  //                   style: TextStyle(
                                                  //                       fontWeight:
                                                  //                       FontWeight
                                                  //                           .w700,
                                                  //                       color: Colors
                                                  //                           .grey), // Light and grey
                                                  //                 ),
                                                  //               ],
                                                  //             ),
                                                  //           ),
                                                  //         ],
                                                  //       ),
                                                  //     ),
                                                  //   ],
                                                  // ),
                                                  Row(
                                                    children: [
                                                      FaIcon(
                                                        isExpanded
                                                            ? FontAwesomeIcons
                                                                .sortUp
                                                            : FontAwesomeIcons
                                                                .sortDown,
                                                        size: 30,
                                                        color:
                                                            Colors.transparent,
                                                      ),
                                                      Expanded(
                                                        child: Table(
                                                          columnWidths: {
                                                            0: const FlexColumnWidth(), // Distribute columns equally
                                                            1: const FlexColumnWidth(),
                                                            // 0: FixedColumnWidth(150.0), // Adjust width as needed
                                                            // 1: FlexColumnWidth(),
                                                          },
                                                          children: [
                                                            _buildTableRow(
                                                                'Category :',
                                                                _getDisplayValue(
                                                                    workOrder
                                                                        .workCategory),
                                                                'Assign :',
                                                                _getDisplayValue(
                                                                    workOrder
                                                                        .staffmemberName)),
                                                            _buildTableRow(
                                                                'Created On :',
                                                                dateProvider
                                                                    .formatCurrentDate(
                                                                        '${workOrder.createdAt}'),
                                                                'Updated On :',
                                                                dateProvider
                                                                    .formatCurrentDate(
                                                                        '${workOrder.createdAt}')),
                                                          ],
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 5,
                                                      ),
                                                      // Column(
                                                      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      //   children: [
                                                      //     IconButton(
                                                      //       icon: FaIcon(
                                                      //         FontAwesomeIcons.edit,
                                                      //         size: 20,
                                                      //         color:blueColor,
                                                      //       ),
                                                      //       onPressed: () async {
                                                      //         // handleEdit(Propertytype);
                                                      //
                                                      //                       var check = await Navigator.push(
                                                      //                           context,
                                                      //                           MaterialPageRoute(
                                                      //                               builder: (context) => ResponsiveEditWorkOrder(
                                                      //                                     workorderId: workOrder.workOrderData!.workOrderId!,
                                                      //                                   )));
                                                      //                       if (check ==
                                                      //                           true) {
                                                      //                         setState(() {
                                                      //                           futureworkorders =
                                                      //                               WorkOrderRepository()
                                                      //                                   .fetchWorkOrders();
                                                      //                         });
                                                      //                       }
                                                      //       },
                                                      //     ),
                                                      //     IconButton(
                                                      //       icon: FaIcon(
                                                      //         FontAwesomeIcons.trashCan,
                                                      //         size: 20,
                                                      //         color:blueColor,
                                                      //       ),
                                                      //       onPressed: () {
                                                      //         //handleDelete(Propertytype);
                                                      //                       _showAlert(
                                                      //                           context,
                                                      //                           workOrder
                                                      //                               .workOrderData!
                                                      //                               .workOrderId!);
                                                      //       },
                                                      //     ),
                                                      //   ],
                                                      // ),
                                                    ],
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      GestureDetector(
                                                        onTap: () {
                                                          Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          Workorder_summery(
                                                                            workorder_id:
                                                                                workOrder.workOrderId,
                                                                          )));
                                                        },
                                                        child: Container(
                                                          height: 35,
                                                          width: 35,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors
                                                                .grey.shade200,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8),
                                                          ),
                                                          child: const Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            children: [
                                                              FaIcon(
                                                                FontAwesomeIcons
                                                                    .eye,
                                                                size: 15,
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                              SizedBox(
                                                                  width: 2),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 20,
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(
                                                    height: 15,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        //SizedBox(height: 13,),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          if (data.isNotEmpty) const SizedBox(height: 20),
                          if (data.isEmpty)
                            Container(
                              height: MediaQuery.of(context).size.height * .5,
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/images/no_data.jpg",
                                      height: 200,
                                      width: 200,
                                    ),
                                    const SizedBox(height: 10),
                                    Text(
                                      "No Data Available",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: blueColor,
                                          fontSize: 16),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          if (data.isNotEmpty)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Row(
                                  children: [
                                    // Text('Rows per page:'),
                                    const SizedBox(width: 10),
                                    Material(
                                      elevation: 3,
                                      child: Container(
                                        height: 40,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12.0),
                                        decoration: BoxDecoration(
                                          border:
                                              Border.all(color: Colors.grey),
                                        ),
                                        child: DropdownButtonHideUnderline(
                                          child: DropdownButton<int>(
                                            value: itemsPerPage,
                                            items: itemsPerPageOptions
                                                .map((int value) {
                                              return DropdownMenuItem<int>(
                                                value: value,
                                                child: Text(value.toString()),
                                              );
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                itemsPerPage = newValue!;
                                                currentPage =
                                                    0; // Reset to first page when items per page change
                                              });
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    IconButton(
                                      icon: FaIcon(
                                        FontAwesomeIcons.circleChevronLeft,
                                        color: currentPage == 0
                                            ? Colors.grey
                                            : blueColor,
                                      ),
                                      onPressed: currentPage == 0
                                          ? null
                                          : () {
                                              setState(() {
                                                currentPage--;
                                              });
                                            },
                                    ),
                                    // IconButton(
                                    //   icon: Icon(Icons.arrow_back),
                                    //   onPressed: currentPage > 0
                                    //       ? () {
                                    //     setState(() {
                                    //       currentPage--;
                                    //     });
                                    //   }
                                    //       : null,
                                    // ),
                                    Text(
                                        'Page ${currentPage + 1} of $totalPages'),
                                    // IconButton(
                                    //   icon: Icon(Icons.arrow_forward),
                                    //   onPressed: currentPage < totalPages - 1
                                    //       ? () {
                                    //     setState(() {
                                    //       currentPage++;
                                    //     });
                                    //   }
                                    //       : null,
                                    // ),
                                    IconButton(
                                      icon: FaIcon(
                                        FontAwesomeIcons.circleChevronRight,
                                        color: currentPage < totalPages - 1
                                            ? blueColor
                                            : Colors.grey,
                                      ),
                                      onPressed: currentPage < totalPages - 1
                                          ? () {
                                              setState(() {
                                                currentPage++;
                                              });
                                            }
                                          : null,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ),
          if (MediaQuery.of(context).size.width > 500)
            FutureBuilder<List<propertiesworkData>>(
              future: futureworkordersummery,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: SpinKitFadingCircle(
                      color: Colors.black,
                      size: 55.0,
                    ),
                  );
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Container(
                    height: MediaQuery.of(context).size.height * .5,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset(
                            "assets/images/no_data.jpg",
                            height: 200,
                            width: 200,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            "No Data Available",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                                fontSize: 16),
                          )
                        ],
                      ),
                    ),
                  );
                } else {
                  _tableData = snapshot.data!;
                  if (selectedValue == null && searchvalue.isEmpty) {
                    _tableData = snapshot.data!;
                  } else if (selectedValue == "All") {
                    _tableData = snapshot.data!;
                  } else if (searchvalue.isNotEmpty) {
                    _tableData = snapshot.data!
                        .where((property) =>
                            property.workSubject!
                                .toLowerCase()
                                .contains(searchvalue.toLowerCase()) ||
                            property.workCategory!
                                .toLowerCase()
                                .contains(searchvalue.toLowerCase()))
                        .toList();
                  } else {
                    _tableData = snapshot.data!
                        .where((property) => property.status == selectedValue)
                        .toList();
                  }
                  if (isChecked) {
                    _tableData = snapshot.data!
                        .where((workorder) => workorder.status == 'Completed')
                        .toList();
                  } else {
                    _tableData = snapshot.data!
                        .where((workorder) => workorder.status != 'Completed')
                        .toList();
                  }
                  totalrecords = _tableData.length;
                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 5),
                            child: Column(
                              children: [
                                SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Container(
                                    // width: MediaQuery.of(context).size.width *
                                    //     .91,
                                    child: Table(
                                      defaultColumnWidth:
                                          const IntrinsicColumnWidth(),
                                      children: [
                                        TableRow(
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                // color: blueColor
                                                ),
                                          ),
                                          children: [
                                            _buildHeader(
                                                'Work Orders',
                                                0,
                                                (property) =>
                                                    property.workSubject!),
                                            _buildHeader(
                                                'Category',
                                                1,
                                                (property) =>
                                                    property.workCategory!),
                                            _buildHeader(
                                                'Billable',
                                                2,
                                                (property) => property
                                                    .isBillable!
                                                    .toString()),
                                            _buildHeader(
                                                'Assign',
                                                3,
                                                (property) =>
                                                    property.staffmemberName!),
                                            _buildHeader('Status', 4,
                                                (property) => property.status!),
                                            _buildHeader('Created At', 5, null),
                                            _buildHeader('Updated At', 6, null),
                                          ],
                                        ),
                                        TableRow(
                                          decoration: const BoxDecoration(
                                            border: Border.symmetric(
                                                horizontal: BorderSide.none),
                                          ),
                                          children: List.generate(
                                              7,
                                              (index) => TableCell(
                                                  child:
                                                      Container(height: 20))),
                                        ),
                                        for (var i = 0;
                                            i < _pagedData.length;
                                            i++)
                                          TableRow(
                                            decoration: BoxDecoration(
                                              border: Border(
                                                left: BorderSide(
                                                    color: blueColor),
                                                right: BorderSide(
                                                    color: blueColor),
                                                top: BorderSide(
                                                    color: blueColor),
                                                bottom:
                                                    i == _pagedData.length - 1
                                                        ? BorderSide(
                                                            color: blueColor)
                                                        : BorderSide.none,
                                              ),
                                            ),
                                            children: [
                                              // Text(
                                              //     '${_pagedData[i].propertyType!}'),
                                              // Text(
                                              //     '${_pagedData[i].propertysubType!}'),
                                              // Text(
                                              //     '${formatDate(_pagedData[i].createdAt!)}'),
                                              // Text(
                                              //     '${formatDate(_pagedData[i].updatedAt!)}'),
                                              _buildDataCell(_pagedData[i]
                                                  .workSubject
                                                  .toString()),
                                              _buildDataCell(_pagedData[i]
                                                  .workCategory
                                                  .toString()),
                                              _buildDataCellBillable(
                                                  _pagedData[i].isBillable ==
                                                      true),
                                              _buildDataCell(_pagedData[i]
                                                      .staffmemberName ??
                                                  ""),
                                              _buildDataCell(_pagedData[i]
                                                  .status
                                                  .toString()),
                                              _buildDataCell(
                                                formatDate(
                                                    _pagedData[i].createdAt!),
                                              ),
                                              _buildDataCell(
                                                formatDate(
                                                    _pagedData[i].updatedAt!),
                                              ),
                                            ],
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 25),
                                _buildPaginationControls(),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 25),
                      ],
                    ),
                  );
                }
              },
            ),
        ],
      ),
    );
  }

  TableRow _buildTableRow(String leftLabel, String leftValue, String rightLabel,
      String rightValue) {
    return TableRow(
      children: [
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(4.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  leftLabel,
                  style:
                      TextStyle(fontWeight: FontWeight.bold, color: blueColor),
                ),
                const SizedBox(height: 2.0), // Space between label and value
                Text(
                  leftValue,
                  style: TextStyle(color: grey),
                ),
              ],
            ),
          ),
        ),
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(4.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  rightLabel,
                  style:
                      TextStyle(fontWeight: FontWeight.bold, color: blueColor),
                ),
                const SizedBox(height: 2.0), // Space between label and value
                Text(
                  rightValue,
                  style: TextStyle(color: grey),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  String _getDisplayValue(String? value) {
    // Return 'N/A' if the value is null or empty, otherwise return the value
    return (value == null || value.trim().isEmpty) ? 'N/A' : value;
  }

  reload_Screen() {
    setState(() {
      futureUnitsummery =
          Properies_summery_Repo().fetchunit(widget.properties.rentalId ?? "");
    });
  }
}

class LeasesTable extends StatefulWidget {
  unit_properties? unit;
  LeasesTable({
    super.key,
    this.unit,
  });
  //LeasesTable({Key? key}) : super(key: key);

  @override
  State<LeasesTable> createState() => _LeasesTableState();
}

class _LeasesTableState extends State<LeasesTable> {
  final UnitData leaseRepository = UnitData();

  List<unit_lease> leases = [];

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchLeases();
    futureLease = UnitData().fetchUnitLeases(widget.unit?.unitId ?? "");
  }

  Future<void> fetchLeases() async {
    //  try {
    final fetchedLeases =
        await leaseRepository.fetchUnitLeases(widget.unit!.unitId!);
    print(widget.unit!.unitId!);
    print('hello');
    setState(() {
      print(widget.unit!.unitId!);
      print('hello');
      leases = fetchedLeases;
      isLoading = false;
    });
    //} catch (e) {
    setState(() {
      isLoading = false;
    });
    //print('Failed to load leases: $e');
    //}
  }

  String getStatus(String startDate, String endDate) {
    final now = DateTime.now();
    final start = DateTime.parse(reverseFormatDate(formatDate(startDate)));
    final end = DateTime.parse(reverseFormatDate(formatDate(endDate)));
    return (now.isAfter(start) && now.isBefore(end)) ? 'Active' : 'Inactive';
  }

  //for table

  Widget _buildHeader<T>(String text, int columnIndex,
      Comparable<T> Function(unit_lease d)? getField) {
    return TableCell(
      child: InkWell(
        onTap: getField != null
            ? () {
                _sort(getField, columnIndex, !_sortAscending);
              }
            : null,
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Row(
            children: [
              Text(text,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18)),
              if (_sortColumnIndex == columnIndex)
                Icon(_sortAscending
                    ? Icons.arrow_drop_down_outlined
                    : Icons.arrow_drop_up_outlined),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDataCell(String text) {
    return TableCell(
      child: Padding(
        padding: const EdgeInsets.only(top: 20.0, left: 16, bottom: 20),
        child: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }

  Widget _buildActionsCell(unit_lease data) {
    return TableCell(
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Container(
          height: 50,
          // color: Colors.blue,
          child: Row(
            children: [
              const SizedBox(
                width: 20,
              ),
              InkWell(
                onTap: () {
                  handleEdit(data);
                },
                child: const FaIcon(
                  FontAwesomeIcons.edit,
                  size: 30,
                ),
              ),
              const SizedBox(
                width: 15,
              ),
              InkWell(
                onTap: () {
                  handleDelete(data);
                },
                child: const FaIcon(
                  FontAwesomeIcons.trashCan,
                  size: 30,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPaginationControls() {
    int numorpages = 1;
    numorpages = (totalrecords / _rowsPerPage).ceil();
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Text('Rows per page: '),
        // SizedBox(width: 10),
        Material(
          elevation: 2,
          color: Colors.white,
          child: Container(
            height: 55,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                value: _rowsPerPage,
                items: [10, 2, 5, 1].map((int value) {
                  return DropdownMenuItem<int>(
                    value: value,
                    child: Text(value.toString()),
                  );
                }).toList(),
                onChanged: (newValue) {
                  if (newValue != null) {
                    _changeRowsPerPage(newValue);
                  }
                },
                icon: const Icon(
                  Icons.arrow_drop_down,
                  size: 40,
                ),
                style: const TextStyle(color: Colors.black, fontSize: 17),
                dropdownColor: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronLeft,
            color: _currentPage == 0 ? Colors.grey : blueColor,
          ),
          onPressed: _currentPage == 0
              ? null
              : () {
                  setState(() {
                    _currentPage--;
                  });
                },
        ),
        Text(
          'Page ${_currentPage + 1} of $numorpages',
          style: const TextStyle(fontSize: 18),
        ),
        IconButton(
          icon: FaIcon(
            size: 30,
            FontAwesomeIcons.circleChevronRight,
            color: (_currentPage + 1) * _rowsPerPage >= _tableData.length
                ? Colors.grey
                : blueColor, // Change color based on availability
          ),
          onPressed: (_currentPage + 1) * _rowsPerPage >= _tableData.length
              ? null
              : () {
                  setState(() {
                    _currentPage++;
                  });
                },
        ),
      ],
    );
  }

  //

  List<unit_lease> _tableData = [];
  int totalrecords = 0;
  int _rowsPerPage = 10;
  int _currentPage = 0;
  int? _sortColumnIndex;
  bool _sortAscending = true;

  List<unit_lease> get _pagedData {
    int startIndex = _currentPage * _rowsPerPage;
    int endIndex = startIndex + _rowsPerPage;
    return _tableData.sublist(startIndex,
        endIndex > _tableData.length ? _tableData.length : endIndex);
  }

  void _changeRowsPerPage(int selectedRowsPerPage) {
    setState(() {
      _rowsPerPage = selectedRowsPerPage;
      _currentPage = 0; // Reset to the first page when changing rows per page
    });
  }

  void _sort<T>(Comparable<T> Function(unit_lease d) getField, int columnIndex,
      bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _tableData.sort((a, b) {
        final aValue = getField(a);
        final bValue = getField(b);

        int result;
        if (aValue is String && bValue is String) {
          result = aValue
              .toString()
              .toLowerCase()
              .compareTo(bValue.toString().toLowerCase());
        } else {
          result = aValue.compareTo(bValue as T);
        }

        return _sortAscending ? result : -result;
      });
    });
  }

  void handleEdit(unit_lease rentalOwner) async {
    // Handle edit action
    // print('Edit ${rentalOwner.rentalownerId}');
    // var check = await Navigator.push(
    //     context,
    //     MaterialPageRoute(
    //         builder: (context) => Edit_rentalowners(
    //           rentalOwner: rentalOwner,
    //         )));
    // if (check == true) {
    //   setState(() {});
    // }
    // final result = await Navigator.push(
    //     context,
    //     MaterialPageRoute(
    //         builder: (context) => Edit_rentalowners(rentalOwner: rentalOwner,)));
    /* if (result == true) {
      setState(() {
        futurePropertyTypes = PropertyTypeRepository().fetchPropertyTypes();
      });
    }*/
  }

  void _showDeleteAlert(BuildContext context, String id) {
    Alert(
      context: context,
      type: AlertType.warning,
      title: "Are you sure?",
      desc: "Once deleted, you will not be able to recover this RentalOwner!",
      style: const AlertStyle(
        backgroundColor: Colors.white,
      ),
      buttons: [
        DialogButton(
          child: Text(
            "Cancel",
            style: TextStyle(
                color: blueColor, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          onPressed: () => Navigator.pop(context),
          color: Colors.white,
          radius: BorderRadius.circular(8), // Rounded corners
          border: Border.all(
            color: blueColor, // Blue border
            width: 1.5,
          ),
        ),
        DialogButton(
          child: const Text(
            "Delete",
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          onPressed: () async {
            //  await RentalOwnerService().DeleteRentalOwners(rentalownerId: id);
            setState(() {
              // futureRentalOwners = RentalOwnerService().fetchRentalOwners("");
            });
            Navigator.pop(context);
          },
          color: blueColor,
        ),
      ],
    ).show();
  }

  void handleDelete(unit_lease rental) {
    _showDeleteAlert(context, rental.leaseId!);
    // Handle delete action
    print('Delete ${rental.leaseId}');
  }

  late Future<List<unit_lease>> futureLease;
  int rowsPerPage = 5;
  int sortColumnIndex = 0;
  bool sortAscending = true;
  final List<String> roles = ['Manager', 'Employee', 'All'];
  String? selectedRole;
  String searchValue = "";
  int currentPage = 0;
  int itemsPerPage = 10;
  int? expandedIndex;
  Set<int> expandedIndices = {};

  List<int> itemsPerPageOptions = [
    10,
    25,
    50,
    100,
  ]; // Options for items per page
  late bool isExpanded;
  bool sorting1 = false;
  bool sorting2 = false;
  bool sorting3 = false;
  bool ascending1 = false;
  bool ascending2 = false;
  bool ascending3 = false;

  Widget _buildHeaders() {
    var width = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
        color: blueColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(13),
          topRight: Radius.circular(13),
        ),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              child: const Icon(
                Icons.expand_less,
                color: Colors.transparent,
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting1 == true) {
                      sorting2 = false;
                      sorting3 = false;
                      ascending1 = sorting1 ? !ascending1 : true;
                      ascending2 = false;
                      ascending3 = false;
                    } else {
                      sorting1 = !sorting1;
                      sorting2 = false;
                      sorting3 = false;
                      ascending1 = sorting1 ? !ascending1 : true;
                      ascending2 = false;
                      ascending3 = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    width < 400
                        ? const Text("Status", style: TextStyle(color: Colors.white))
                        : const Text("Status", style: TextStyle(color: Colors.white)),
                    // Text("Property", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 3),
                    ascending1
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 5),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting2) {
                      sorting1 = false;
                      sorting2 = sorting2;
                      sorting3 = false;
                      ascending2 = sorting2 ? !ascending2 : true;
                      ascending1 = false;
                      ascending3 = false;
                    } else {
                      sorting1 = false;
                      sorting2 = !sorting2;
                      sorting3 = false;
                      ascending2 = sorting2 ? !ascending2 : true;
                      ascending1 = false;
                      ascending3 = false;
                    }
                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    const Text("Tenants", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 5),
                    ascending2
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  setState(() {
                    if (sorting3) {
                      sorting1 = false;
                      sorting2 = false;
                      sorting3 = sorting3;
                      ascending3 = sorting3 ? !ascending3 : true;
                      ascending2 = false;
                      ascending1 = false;
                    } else {
                      sorting1 = false;
                      sorting2 = false;
                      sorting3 = !sorting3;
                      ascending3 = sorting3 ? !ascending3 : true;
                      ascending2 = false;
                      ascending1 = false;
                    }

                    // Sorting logic here
                  });
                },
                child: Row(
                  children: [
                    const Text("   Type", style: TextStyle(color: Colors.white)),
                    const SizedBox(width: 5),
                    ascending3
                        ? const Padding(
                            padding: EdgeInsets.only(top: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortUp,
                              size: 20,
                              color: Colors.white,
                            ),
                          )
                        : const Padding(
                            padding: EdgeInsets.only(bottom: 7, left: 2),
                            child: FaIcon(
                              FontAwesomeIcons.sortDown,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dateProvider = Provider.of<DateProvider>(context);
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                if (MediaQuery.of(context).size.width < 500)
                  const SizedBox(
                    width: 10,
                  ),
                if (MediaQuery.of(context).size.width > 500)
                  const SizedBox(
                    width: 20,
                  ),
                Text(
                  'Leases',
                  style: TextStyle(
                      fontSize:
                          MediaQuery.of(context).size.width < 500 ? 17 : 20,
                      color: blueColor,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          if (MediaQuery.of(context).size.width < 500)
            Padding(
              padding: const EdgeInsets.only(left: 2, right: 2, bottom: 10),
              child: FutureBuilder<List<unit_lease>>(
                future: futureLease,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: SpinKitFadingCircle(
                      color: Colors.black,
                      size: 40.0,
                    ));
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(
                        child: Text(
                            'You don\'t have any lease for this unit right now ..'));
                  } else {
                    var data = snapshot.data!;
                    // if (searchValue == null || searchValue!.isEmpty) {
                    //   data = snapshot.data!;
                    // } else if (searchValue == "All") {
                    //   data = snapshot.data!;
                    // } else if (searchValue!.isNotEmpty) {
                    //   data = snapshot.data!
                    //       .where((rentals) => rentals.!
                    //       .toLowerCase()
                    //       .contains(searchValue!.toLowerCase()))
                    //       .toList();
                    // } else {
                    //   data = snapshot.data!
                    //       .where((rentals) =>
                    //   rentals.applianceName == searchValue)
                    //       .toList();
                    // }
                    // sortData(data);
                    final totalPages = (data.length / itemsPerPage).ceil();
                    final currentPageData = data
                        .skip(currentPage * itemsPerPage)
                        .take(itemsPerPage)
                        .toList();
                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          const SizedBox(height: 10),
                          _buildHeaders(),
                          const SizedBox(height: 20),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: const Color.fromRGBO(152, 162, 179, .5))),
                            // decoration: BoxDecoration(
                            //     border: Border.all(color: blueColor)),
                            child: Column(
                              children:
                                  currentPageData.asMap().entries.map((entry) {
                                int index = entry.key;
                                bool isExpanded = expandedIndex == index;
                                unit_lease rentals = entry.value;
                                //return CustomExpansionTile(data: Propertytype, index: index);
                                return Container(
                                  decoration: BoxDecoration(
                                    color: index % 2 != 0
                                        ? Colors.white
                                        : blueColor.withOpacity(0.09),
                                    border: Border.all(
                                        color:
                                            const Color.fromRGBO(152, 162, 179, .5)),
                                  ),
                                  // decoration: BoxDecoration(
                                  //   border: Border.all(color: blueColor),
                                  // ),
                                  child: Column(
                                    children: <Widget>[
                                      ListTile(
                                        contentPadding: EdgeInsets.zero,
                                        title: Padding(
                                          padding: const EdgeInsets.all(2.0),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              InkWell(
                                                onTap: () {
                                                  // setState(() {
                                                  //    isExpanded = !isExpanded;
                                                  // //  expandedIndex = !expandedIndex;
                                                  //
                                                  // });
                                                  // setState(() {
                                                  //   if (isExpanded) {
                                                  //     expandedIndex = null;
                                                  //     isExpanded = !isExpanded;
                                                  //   } else {
                                                  //     expandedIndex = index;
                                                  //   }
                                                  // });
                                                  setState(() {
                                                    if (expandedIndex ==
                                                        index) {
                                                      expandedIndex = null;
                                                    } else {
                                                      expandedIndex = index;
                                                    }
                                                  });
                                                },
                                                child: Container(
                                                  margin:
                                                      const EdgeInsets.only(left: 5),
                                                  padding: !isExpanded
                                                      ? const EdgeInsets.only(
                                                          bottom: 10)
                                                      : const EdgeInsets.only(
                                                          top: 10),
                                                  child: FaIcon(
                                                    isExpanded
                                                        ? FontAwesomeIcons
                                                            .sortUp
                                                        : FontAwesomeIcons
                                                            .sortDown,
                                                    size: 20,
                                                    color: blueColor,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              Expanded(
                                                child: InkWell(
                                                  onTap: () {
                                                    // Navigator.push(
                                                    //     context,
                                                    //     MaterialPageRoute(
                                                    //         builder: (context) =>
                                                    //             Rentalowners_summery(
                                                    //               rentalOwnersid: rentals.rentalownerId!,)));
                                                  },
                                                  child: Text(
                                                    (getStatus(
                                                        rentals.startDate!,
                                                        rentals.endDate!)),
                                                    style: TextStyle(
                                                      color: blueColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 13,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      .08),
                                              Expanded(
                                                child: Text(
                                                  '${rentals.tenantFirstName} ${rentals.tenantLastName}',
                                                  style: TextStyle(
                                                    color: blueColor,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      .08),
                                              Expanded(
                                                child: Text(
                                                  '${rentals.leaseType}',
                                                  style: TextStyle(
                                                    color: blueColor,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      .02),
                                            ],
                                          ),
                                        ),
                                      ),
                                      if (isExpanded)
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0),
                                          margin: const EdgeInsets.only(bottom: 20),
                                          child: SingleChildScrollView(
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    FaIcon(
                                                      isExpanded
                                                          ? FontAwesomeIcons
                                                              .sortUp
                                                          : FontAwesomeIcons
                                                              .sortDown,
                                                      size: 50,
                                                      color: Colors.transparent,
                                                    ),
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Text.rich(
                                                            TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                  text:
                                                                      'Start-End : ',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                      color:
                                                                          blueColor), // Bold and black
                                                                ),
                                                                TextSpan(
                                                                  text:
                                                                      '${dateProvider.formatCurrentDate('${rentals.startDate}')} - ${dateProvider.formatCurrentDate('${rentals.endDate}')}',
                                                                  style: const TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                      color: Colors
                                                                          .grey), // Light and grey
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .height *
                                                                .01,
                                                          ),
                                                          Text.rich(
                                                            TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                  text:
                                                                      'Rent : ',
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                      color:
                                                                          blueColor), // Bold and black
                                                                ),
                                                                TextSpan(
                                                                  text:
                                                                      '${rentals.amount}',
                                                                  style: const TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                      color: Colors
                                                                          .grey), // Light and grey
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      //SizedBox(height: 13,),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Row(
                                children: [
                                  // Text('Rows per page:'),
                                  const SizedBox(width: 10),
                                  Material(
                                    elevation: 3,
                                    child: Container(
                                      height: 40,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12.0),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Colors.grey),
                                      ),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<int>(
                                          value: itemsPerPage,
                                          items: itemsPerPageOptions
                                              .map((int value) {
                                            return DropdownMenuItem<int>(
                                              value: value,
                                              child: Text(value.toString()),
                                            );
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              itemsPerPage = newValue!;
                                              currentPage =
                                                  0; // Reset to first page when items per page change
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  IconButton(
                                    icon: FaIcon(
                                      FontAwesomeIcons.circleChevronLeft,
                                      color: currentPage == 0
                                          ? Colors.grey
                                          : blueColor,
                                    ),
                                    onPressed: currentPage == 0
                                        ? null
                                        : () {
                                            setState(() {
                                              currentPage--;
                                            });
                                          },
                                  ),
                                  // IconButton(
                                  //   icon: Icon(Icons.arrow_back),
                                  //   onPressed: currentPage > 0
                                  //       ? () {
                                  //     setState(() {
                                  //       currentPage--;
                                  //     });
                                  //   }
                                  //       : null,
                                  // ),
                                  Text(
                                      'Page ${currentPage + 1} of $totalPages'),
                                  // IconButton(
                                  //   icon: Icon(Icons.arrow_forward),
                                  //   onPressed: currentPage < totalPages - 1
                                  //       ? () {
                                  //     setState(() {
                                  //       currentPage++;
                                  //     });
                                  //   }
                                  //       : null,
                                  // ),
                                  IconButton(
                                    icon: FaIcon(
                                      FontAwesomeIcons.circleChevronRight,
                                      color: currentPage < totalPages - 1
                                          ? blueColor
                                          : Colors.grey,
                                    ),
                                    onPressed: currentPage < totalPages - 1
                                        ? () {
                                            setState(() {
                                              currentPage++;
                                            });
                                          }
                                        : null,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ),
          if (MediaQuery.of(context).size.width > 500)
            FutureBuilder<List<unit_lease>>(
              future: futureLease,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child: SpinKitFadingCircle(
                    color: Colors.black,
                    size: 40.0,
                  ));
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(
                      child: Text(
                          'You don\'t have any lease for this unit right now ..'));
                } else {
                  List<unit_lease>? filteredData = [];
                  _tableData = snapshot.data!;
                  if (selectedRole == null && searchValue == "") {
                    filteredData = snapshot.data;
                  } else if (selectedRole == "All") {
                    filteredData = snapshot.data;
                  } else if (searchValue.isNotEmpty) {
                    filteredData = snapshot.data!
                        .where((staff) =>
                            staff.tenantFirstName!
                                .toLowerCase()
                                .contains(searchValue.toLowerCase()) ||
                            staff.leaseType!
                                .toLowerCase()
                                .contains(searchValue.toLowerCase()))
                        .toList();
                  }

                  _tableData = filteredData!;
                  totalrecords = _tableData.length;
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 20),
                    child: Column(
                      children: [
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Container(
                            width: MediaQuery.of(context).size.width * .91,
                            child: Table(
                              defaultColumnWidth: const IntrinsicColumnWidth(),
                              children: [
                                TableRow(
                                  decoration:
                                      BoxDecoration(border: Border.all()),
                                  children: [
                                    _buildHeader('Status', 0,
                                        (rental) => rental.startDate!),
                                    _buildHeader('Start-End', 1,
                                        (rental) => rental.endDate!),
                                    _buildHeader('Tenant', 2,
                                        (rental) => rental.tenantFirstName!),
                                    _buildHeader('Type', 3,
                                        (rental) => rental.leaseType!),
                                    _buildHeader(
                                        'Type', 4, (rental) => rental.amount!),
                                  ],
                                ),
                                TableRow(
                                  decoration: const BoxDecoration(
                                    border: Border.symmetric(
                                        horizontal: BorderSide.none),
                                  ),
                                  children: List.generate(
                                      5,
                                      (index) => TableCell(
                                          child: Container(height: 20))),
                                ),
                                for (var i = 0; i < _pagedData.length; i++)
                                  TableRow(
                                    decoration: BoxDecoration(
                                      border: Border(
                                        left: BorderSide(color: blueColor),
                                        right: BorderSide(color: blueColor),
                                        top: BorderSide(color: blueColor),
                                        bottom: i == _pagedData.length - 1
                                            ? BorderSide(color: blueColor)
                                            : BorderSide.none,
                                      ),
                                    ),
                                    children: [
                                      _buildDataCell(
                                        (getStatus(_pagedData[i].startDate!,
                                            _pagedData[i].endDate!)),
                                      ),
                                      // _buildDataCell('${_pagedData[i].rentalOwnerFirstName ?? ''} ${_pagedData[i].rentalOwnerLastName ?? ''}'),
                                      _buildDataCell(
                                          '${_pagedData[i].startDate} - ${_pagedData[i].endDate}'),
                                      _buildDataCell(
                                          '${_pagedData[i].tenantFirstName} - ${_pagedData[i].tenantLastName}'),
                                      _buildDataCell(
                                          '${_pagedData[i].leaseType}'),
                                      _buildDataCell('${_pagedData[i].amount}'),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                        ),
                        if (_tableData.isEmpty) const Text("No Search Records Found"),
                        const SizedBox(height: 25),
                        _buildPaginationControls(),
                      ],
                    ),
                  );
                }
              },
            ),
        ],
      ),
    );
  }
}

class Lease {
  final String status;
  final String startEndDate;
  final String tenant;
  final String type;
  final String rent;

  Lease({
    required this.status,
    required this.startEndDate,
    required this.tenant,
    required this.type,
    required this.rent,
  });
}

List<Lease> leases = [
  Lease(
    status: 'Active',
    startEndDate: '05-15-2024-06-15-2024',
    tenant: 'Alex Wilkins',
    type: 'Fixed',
    rent: '30',
  ),
  Lease(
    status: 'Active',
    startEndDate: '05-15-2024-06-15-2024',
    tenant: 'Alex Wilkins',
    type: 'Fixed',
    rent: '30',
  ),
  // Add more leases as needed
];

void showCommonPopup({
  required BuildContext context,
  required bool isMultiunit,
  required String propertyType,
  required Function onSave,
  required TextEditingController unitController,
  required TextEditingController sqftController,
  required TextEditingController addressController,
  TextEditingController? bathController, // For Commercial
  TextEditingController? bedController, // For Commercial
  List<File>? images,
  File? imagess,
  List<String>? imageUrls,
  Function? onImageAdd,
  bool isError = false,
  Function(int)? onImageRemove,
}) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        "Edit Unit Details",
                        style: TextStyle(
                          color: blueColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      Align(
                        alignment: Alignment.centerRight,
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: const Icon(Icons.close, color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Row(
                    children: [
                      Text(
                        "Unit Number",
                        style: TextStyle(
                            color: Color(0xFF8A95A8),
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1),
                    child: Material(
                      elevation: 3,
                      borderRadius: BorderRadius.circular(3),
                      child: TextFormField(
                        controller: unitController,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          //  hintText: label,
                          // labelText: label,
                          // labelStyle: TextStyle(color: Colors.grey[700]),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide:
                                const BorderSide(color: Color(0xFF8A95A8)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: const BorderSide(
                                color: Color(0xFF8A95A8), width: 2),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 10.0),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Row(
                    children: [
                      Text(
                        "Street Address",
                        style: TextStyle(
                            color: Color(0xFF8A95A8),
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1),
                    child: Material(
                      elevation: 3,
                      borderRadius: BorderRadius.circular(3),
                      child: TextFormField(
                        controller: addressController,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          //  hintText: label,
                          // labelText: label,
                          // labelStyle: TextStyle(color: Colors.grey[700]),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide:
                                const BorderSide(color: Color(0xFF8A95A8)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: const BorderSide(
                                color: Color(0xFF8A95A8), width: 2),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 10.0),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Row(
                    children: [
                      Text(
                        "SQFT",
                        style: TextStyle(
                            color: Color(0xFF8A95A8),
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1),
                    child: Material(
                      elevation: 3,
                      borderRadius: BorderRadius.circular(3),
                      child: TextFormField(
                        controller: sqftController,
                        cursorColor: Colors.black,
                        decoration: InputDecoration(
                          //  hintText: label,
                          // labelText: label,
                          // labelStyle: TextStyle(color: Colors.grey[700]),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide:
                                const BorderSide(color: Color(0xFF8A95A8)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(3),
                            borderSide: const BorderSide(
                                color: Color(0xFF8A95A8), width: 2),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 10.0),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  if (propertyType == 'Residential') ...[
                    const Row(
                      children: [
                        Text(
                          "bath",
                          style: TextStyle(
                              color: Color(0xFF8A95A8),
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 1),
                      child: Material(
                        elevation: 3,
                        borderRadius: BorderRadius.circular(3),
                        child: TextFormField(
                          controller: bathController,
                          cursorColor: Colors.black,
                          decoration: InputDecoration(
                            //  hintText: label,
                            // labelText: label,
                            // labelStyle: TextStyle(color: Colors.grey[700]),
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide: BorderSide.none,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide:
                                  const BorderSide(color: Color(0xFF8A95A8)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide: const BorderSide(
                                  color: Color(0xFF8A95A8), width: 2),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Row(
                      children: [
                        Text(
                          "bed",
                          style: TextStyle(
                              color: Color(0xFF8A95A8),
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 1),
                      child: Material(
                        elevation: 3,
                        borderRadius: BorderRadius.circular(3),
                        child: TextFormField(
                          controller: bedController,
                          cursorColor: Colors.black,
                          decoration: InputDecoration(
                            //  hintText: label,
                            // labelText: label,
                            // labelStyle: TextStyle(color: Colors.grey[700]),
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide: BorderSide.none,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide:
                                  const BorderSide(color: Color(0xFF8A95A8)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(3),
                              borderSide: const BorderSide(
                                  color: Color(0xFF8A95A8), width: 2),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                  ],

                  const Row(
                    children: [
                      Text(
                        'Photo',
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          onImageAdd?.call();
                          setState(() {});
                        },
                        child: const Text(
                          '+ Add',
                          style: TextStyle(color: Colors.green),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  // _image != null
                  //     ? Column(
                  //         children: [
                  //           Image.file(
                  //             _image!,
                  //             height: 80,
                  //             width: 80,
                  //             fit: BoxFit.cover,
                  //           ),
                  //           Text(_uploadedFileName ?? ""),
                  //         ],
                  //       )
                  //     : const Text(''),
                  images!.isNotEmpty
                      ? Row(
                          children: [
                            Expanded(
                              child: Container(
                                //color: Colors.blue,
                                child: Wrap(
                                  spacing:
                                      8.0, // Horizontal spacing between items
                                  runSpacing:
                                      8.0, // Vertical spacing between rows
                                  children: List.generate(
                                    images!.length,
                                    (index) {
                                      return Container(
                                        // color: Colors.green,
                                        width: 85,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                const SizedBox(
                                                  width: 60,
                                                ),
                                                GestureDetector(
                                                  onTap: () {
                                                    setState(() {
                                                      images?.removeAt(index);
                                                    });
                                                  },
                                                  child: const Icon(
                                                    Icons.close,
                                                    color: Colors.grey,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // color:Colors.blue,
                                                  child: Image.file(
                                                    images![index],
                                                    height: 80,
                                                    width: 80,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : const Center(
                          child: Text("No images selected."),
                        ),

                  imageUrls!.isNotEmpty
                      ? Row(
                          children: [
                            Expanded(
                              child: Container(
                                child: Wrap(
                                  spacing:
                                      8.0, // Horizontal spacing between items
                                  runSpacing:
                                      8.0, // Vertical spacing between rows
                                  children: List.generate(
                                    imageUrls!.length,
                                    (index) {
                                      return Container(
                                        width: 85,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                const SizedBox(width: 60),
                                                GestureDetector(
                                                  onTap: () {
                                                    setState(() {
                                                      imageUrls.removeAt(index);
                                                    });
                                                  },
                                                  child: const Icon(
                                                    Icons.close,
                                                    color: Colors.grey,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  child: Image.network(
                                                    "$image_url${imageUrls[index]}",
                                                    height: 80,
                                                    width: 80,
                                                    fit: BoxFit.cover,
                                                    errorBuilder: (context,
                                                        error, stackTrace) {
                                                      return const Icon(Icons
                                                          .error); // Placeholder for errors
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : const Center(child: Text("No images selected.")),
                  const SizedBox(height: 8.0),

                  Row(
                    children: [
                      const SizedBox(
                        width: 0,
                      ),
                      GestureDetector(
                        onTap: () async {
                          onSave();
                        },
                        child: Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(
                            Radius.circular(5),
                          ),
                          child: Container(
                            height: 30,
                            width: 80,
                            decoration: BoxDecoration(
                              color: blueColor,
                              borderRadius: const BorderRadius.all(
                                Radius.circular(5),
                              ),
                            ),
                            child: const Center(
                                child: Text(
                              "Save",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            )),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(
                            Radius.circular(5),
                          ),
                          child: Container(
                            height: 30,
                            width: 80,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(
                                Radius.circular(5),
                              ),
                            ),
                            child: Center(
                                child: Text(
                              "Cancel",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: blueColor),
                            )),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  if (isError)
                    const Text(
                      "Please fill in all fields correctly.",
                      style: TextStyle(color: Colors.redAccent),
                    ),
                ],
              ),
              // Column(
              //   mainAxisSize: MainAxisSize.min,
              //   children: [
              //     if (isMultiunit) ...[
              //       TextField(
              //         controller: unitController,
              //         decoration: const InputDecoration(
              //           labelText: "Unit Number",
              //         ),
              //       ),
              //     ],
              //     if (propertyType == 'Residential') ...[
              //       TextField(
              //         controller: sqftController,
              //         decoration: const InputDecoration(
              //           labelText: "Square Feet",
              //         ),
              //       ),
              //       TextField(
              //         controller: addressController,
              //         decoration: const InputDecoration(
              //           labelText: "Address",
              //         ),
              //       ),
              //       TextField(
              //         controller: rentAmountController,
              //         decoration: const InputDecoration(
              //           labelText: "Rent Amount",
              //         ),
              //       ),
              //     ],
              //     if (propertyType == 'Commercial') ...[
              //       TextField(
              //         controller: officeSpaceController,
              //         decoration: const InputDecoration(
              //           labelText: "Office Space",
              //         ),
              //       ),
              //       TextField(
              //         controller: sqftController,
              //         decoration: const InputDecoration(
              //           labelText: "Square Feet",
              //         ),
              //       ),
              //       TextField(
              //         controller: addressController,
              //         decoration: const InputDecoration(
              //           labelText: "Address",
              //         ),
              //       ),
              //     ],
              //     const SizedBox(height: 8),
              //     GestureDetector(
              //       onTap: () {
              //         onImageAdd?.call();
              //         setState(() {});
              //       },
              //       child: const Text(
              //         "+ Add Image",
              //         style: TextStyle(color: Colors.green),
              //       ),
              //     ),
              //     const SizedBox(height: 8),
              //     images != null && images.isNotEmpty
              //         ? Wrap(
              //       spacing: 8.0,
              //       runSpacing: 8.0,
              //       children: List.generate(images.length, (index) {
              //         return Stack(
              //           clipBehavior: Clip.none,
              //           children: [
              //             Image.file(
              //               images[index],
              //               height: 80,
              //               width: 80,
              //               fit: BoxFit.cover,
              //             ),
              //             Positioned(
              //               right: -10,
              //               top: -10,
              //               child: GestureDetector(
              //                 onTap: () => onImageRemove?.call(index),
              //                 child: const Icon(
              //                   Icons.close,
              //                   color: Colors.red,
              //                 ),
              //               ),
              //             ),
              //           ],
              //         );
              //       }),
              //     )
              //         : const Text("No images selected."),
              //     const SizedBox(height: 8),
              //     Row(
              //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //       children: [
              //         GestureDetector(
              //           onTap: () {
              //             Navigator.pop(context);
              //           },
              //           child: Container(
              //             padding: const EdgeInsets.symmetric(
              //                 horizontal: 16, vertical: 8),
              //             decoration: BoxDecoration(
              //               color: Colors.grey[200],
              //               borderRadius: BorderRadius.circular(5),
              //             ),
              //             child: const Text("Cancel"),
              //           ),
              //         ),
              //         GestureDetector(
              //           onTap: () {
              //             onSave();
              //           },
              //           child: Container(
              //             padding: const EdgeInsets.symmetric(
              //                 horizontal: 16, vertical: 8),
              //             decoration: BoxDecoration(
              //               color: Colors.blue,
              //               borderRadius: BorderRadius.circular(5),
              //             ),
              //             child: const Text(
              //               "Save",
              //               style: TextStyle(color: Colors.white),
              //             ),
              //           ),
              //         ),
              //       ],
              //     ),
              //   ],
              // ),
            );
          },
        ),
      );
    },
  );
}

class CustomTextFormField extends StatefulWidget {
  final String labelText;
  final String hintText;
  final TextInputType keyboardType;
  final TextEditingController controller;
  final bool obscureText;
  final Widget? suffixIcon;

  const CustomTextFormField({
    super.key,
    required this.labelText,
    required this.hintText,
    required this.keyboardType,
    required this.controller,
    this.obscureText = false,
    this.suffixIcon,
  });

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  final FocusNode _focusNode = FocusNode();
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      setState(() {
        _isFocused = _focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: _isFocused
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ]
              : [],
          border: Border.all(
            color: Colors.grey.shade300,
            width: 1.2,
          ),
        ),
        child: TextFormField(
          focusNode: _focusNode,
          controller: widget.controller,
          keyboardType: widget.keyboardType,
          obscureText: widget.obscureText,
          style: const TextStyle(fontSize: 16),
          decoration: InputDecoration(
            // labelText: widget.labelText,
            hintText: widget.hintText,
            suffixIcon: widget.suffixIcon,
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      ),
    );
  }
}
