import 'dart:convert';

import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:three_zero_two_property/Model/applicant_summery_model.dart';
import 'package:three_zero_two_property/repository/applicant_summery_repo.dart';

import '../../../../constant/constant.dart';

class ApprovedContent extends StatefulWidget {
  final String applicantId;
  applicant_summery_details applicantDetail;

  ApprovedContent({required this.applicantId, required this.applicantDetail});

  @override
  State<ApprovedContent> createState() => _ApprovedContentState();
}

class _ApprovedContentState extends State<ApprovedContent> {
  ApplicantSummeryRepository applicantSummeryRepository =
      ApplicantSummeryRepository();
  ApproveRejectApplicantDetail? applicantDetail;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchApplicantDetails();
  }

  Future<void> fetchApplicantDetails() async {
    try {
      ApproveRejectApplicantDetail detail = await applicantSummeryRepository
          .fetchApprovedDetail(widget.applicantId);
      setState(() {
        applicantDetail = detail;
        isLoading = false;
      });
    } catch (error) {
      setState(() {
        isLoading = false;
      });
      print('Failed to load applicant details: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return
      isLoading
          ? Padding(
            padding: const EdgeInsets.only(top: 200),
            child: Center(
                child: SpinKitSpinningLines(
                color: blueColor,
                size: 40.0,
              )),
          )
          : applicantDetail != null
              ? LayoutBuilder(builder: (context, contraints) {
                  if (contraints.maxWidth > 600) {
                    return
                      Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 205,
                        width: MediaQuery.of(context).size.width * .4,
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                            color:blueColor,
                          ),
                        ),
                        child: Column(
                          children: [
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                const SizedBox(width: 15),
                                Container(
                                  height: 40,
                                  width: 40,
                                  decoration: BoxDecoration(
                                    color:blueColor,
                                    border: Border.all(
                                        color:  blueColor


),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: const Center(
                                    child: FaIcon(
                                      FontAwesomeIcons.user,
                                      size: 16,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const SizedBox(width: 2),
                                        Text(
                                          '${widget.applicantDetail.applicantFirstName ?? 'N/A'} ${widget.applicantDetail.applicantLastName ?? 'N/A'}',
                                          style:  TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color:
                                                blueColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                  ],
                                ),
                                const Spacer(),
                                const SizedBox(width: 15),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                const SizedBox(width: 75),
                                 FaIcon(
                                  FontAwesomeIcons.phone,
                                  size: 25,
                                  color: blueColor,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '${widget.applicantDetail.applicantPhoneNumber ?? 'N/A'}',
                                  style:  TextStyle(
                                    fontSize: 18,
                                    color: blueColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            Row(
                              children: [
                                const SizedBox(width: 75),
                                 FaIcon(
                                  FontAwesomeIcons.home,
                                  size: 25,
                                  color: blueColor,
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  '${widget.applicantDetail.leaseData!.rentalAdress ?? 'N/A'}',
                                  style:  TextStyle(
                                    fontSize: 18,
                                    color: blueColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            const Row(
                              children: [
                                SizedBox(width: 75),
                                Text(
                                  'Approved',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Color.fromRGBO(38, 194, 44, 1),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                  return
                    Padding(
                    padding: const EdgeInsets.all(15.0),
                    child:
                    Material(
                      elevation: 2,
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                       // height: 165,
                       //  width: MediaQuery.of(context).size.width * .9,
                       //  margin: const EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color:blueColor,
                          ),
                        ),
                        child:
                        Column(
                          children: [
                            const SizedBox(height: 15),
                            Row(
                              children: [
                                const SizedBox(width: 20),
                                Container(
                                  height: 35,
                                  width: 35,
                                  decoration: BoxDecoration(
                                    color:blueColor,
                                    border: Border.all(
                                        color:
                                           blueColor),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Center(
                                    child: FaIcon(
                                      FontAwesomeIcons.user,
                                      size: 17,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // const SizedBox(height: 10),
                                    Row(
                                      children: [
                                        const SizedBox(width: 2),
                                        Text(
                                          '${widget.applicantDetail.applicantFirstName ?? 'N/A'} ${widget.applicantDetail.applicantLastName ?? 'N/A'}',
                                          style:  TextStyle(
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold,
                                            color: blueColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                  ],
                                ),
                                const Spacer(),
                                const SizedBox(width: 15),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                const SizedBox(width: 80),
                                 FaIcon(
                                  FontAwesomeIcons.phone,
                                  size: 17,
                                  color: blueColor,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  '${widget.applicantDetail.applicantPhoneNumber ?? 'N/A'}',
                                  style:  TextStyle(
                                    fontSize: 15,
                                    color: blueColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                const SizedBox(width: 80),
                                 FaIcon(
                                  FontAwesomeIcons.home,
                                  size: 17,
                                  color: blueColor,
                                ),
                                const SizedBox(width: 8),
                                SizedBox(
                                  width:
                                  MediaQuery.of(context).size.width > 500 ? 200 : 200,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 1),
                                    child: Text(
                                      '${widget.applicantDetail.leaseData!.rentalAdress ?? 'N/A'}',
                                      textAlign: TextAlign.justify,
                                      maxLines: 7, // Set maximum number of lines
                                      overflow: TextOverflow
                                          .ellipsis, // Handle overflow with ellipsis
                                      style: TextStyle(
                                        fontSize: MediaQuery.of(context).size.width < 500
                                            ? 13
                                            : 18,
                                        color: blueColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                // Text(
                                //   '${widget.applicantDetail.leaseData!.rentalAdress ?? 'N/A'}',
                                //   style:  TextStyle(
                                //     fontSize: 15,
                                //     color: blueColor,
                                //     fontWeight: FontWeight.w500,
                                //   ),
                                // ),
                              ],
                            ),
                            const SizedBox(height: 15),
                            const Row(
                              children: [
                                SizedBox(width: 80),
                                Text(
                                  'Approved',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(38, 194, 44, 1),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  );
                })
              : Padding(
                padding: const EdgeInsets.only(top: 200),
                child: const Center(child: Text('No details found')),
              );

  }
}
