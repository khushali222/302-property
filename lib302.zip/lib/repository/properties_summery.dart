import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:three_zero_two_property/model/properties.dart';
import 'package:three_zero_two_property/model/properties_summery.dart';

import '../Model/Properties_revenue_model.dart';
import '../Model/properties_Lease_model.dart';
import '../constant/constant.dart';
import '../model/properties_workorders.dart';
import '../model/unitsummery_propeties.dart';
import '../screens/Leasing/RentalRoll/addcard/CardModel.dart';

// class Properies_summery_Repo{
//
//   Future<List<RentalSummary>> fetchPropertiessummery(String id) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     //String? id = prefs.getString("rentalid");
//     print(id);
//
//    // final response = await http.get(Uri.parse('${Api_url}/api/rentals/rental_summary/$id'));
//     final response = await http.get(Uri.parse('${Api_url}/api/api/tenant/rental_tenant/$id'));
//     print(response.body);
//     if (response.statusCode == 200) {
//       List jsonResponse = json.decode(response.body)['data'];
//       print(jsonResponse.first["lease_tenant_data"]);
//       return jsonResponse.map((data) => RentalSummary.fromJson(data)).toList();
//     }
//     return [];
//   }
//
//
//
//
// }
class Properies_summery_Repo {
  Future<List<TenantData>> fetchPropertiessummery(String rentalId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //String? id = prefs.getString("rentalid");
    String? id = prefs.getString('adminId');
    String? token = prefs.getString('token');
    print(id);
    final response = await http.get(
      Uri.parse('${Api_url}/api/tenant/rental_tenant/$rentalId'),
      headers: {
        "authorization": "CRM $token",
        "id": "CRM $id",
      },
    );
    print(" get summery details ${response.body}");
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body)['data'];
      return jsonResponse.map((data) => TenantData.fromJson(data)).toList();
    } else {
      print('Failed to fetch property type: ${response.body}');
      return [];
      //throw Exception('Failed to load data');
    }
  }

  Future<Map<String, dynamic>> addUnit({
    String? adminId,
    String? unitId,
    String? rentalunit,
    String? rentalId,
    String? rentalunitadress,
    String? rentalsqft,
    String? rentalbath,
    String? rentalbed,
    List<String?>? rentalImages,
  }) async {
    final Map<String, dynamic> data = {
      'admin_id': adminId,
      'unit_id': unitId,
      'rental_unit': rentalunit,
      'rental_id': rentalId,
      'rental_unit_adress': rentalunitadress,
      'rental_sqft': rentalsqft,
      'rental_bath': rentalbath,
      'rental_bed': rentalbed,
      'rental_images': rentalImages
    };
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    final http.Response response = await http.post(
      Uri.parse('${Api_url}/api/unit/unit'),
      headers: <String, String>{
        "authorization": "CRM $token",
        "id": "CRM $id",
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    print('reesponce ${response.body}');
    var responseData = json.decode(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: responseData["message"]);
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(msg: responseData["message"]);
      throw Exception('Failed to add unit');
    }
  }

  Future<List<unit_properties>> fetchunit(String rentalId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //String? id = prefs.getString("rentalid");
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    print(id);
    print("obj");
    final response = await http.get(
      Uri.parse('${Api_url}/api/unit/rental_unit/$rentalId'),
      headers: {
        "authorization": "CRM $token",
        "id": "CRM $id",
      },
    );
    // print(jsonEncode('data'));
    print('unit responce ${response.body}');
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body)['data'];
      return jsonResponse
          .map((data) => unit_properties.fromJson(data))
          .toList();
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<Map<String, dynamic>> addappliances({
    String? adminId,
    String? unitId,
    String? appliancename,
    String? appliancedescription,
    String? installeddate,
    String? type,
    String? brand,
    String? model,
    String? serialNumber,
    String? warrantyExpiry,
    String? lastMaintenanceDate,
    String? maintenanceNotes,
    String? status,
    String? categoryId,
    List<dynamic>? filters,
    String? appliance_image, // Add this parameter
  }) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');

    // Convert filters to JSON string
    String filtersJson = json.encode(filters ?? []);
    print('Filters as JSON string: $filtersJson');

    // Create FormData
    var formData = {
      'admin_id': adminId,
      'unit_id': unitId,
      'appliance_name': appliancename,
      'appliance_description': appliancedescription,
      'installed_date': installeddate,
      'type': type,
      'brand': brand,
      'model': model,
      'serial_number': serialNumber,
      'warranty_expiry': warrantyExpiry,
      'last_maintenance_date': lastMaintenanceDate,
      'maintenance_notes': maintenanceNotes,
      'status': status,
      'category_id': categoryId,
      'filters': filtersJson,
      'appliance_id': "",
      'appliance_image': appliance_image, // Add this field
    };

    print('Sending form data: ${json.encode(formData)}');

    final http.Response response = await http.post(
      Uri.parse('${Api_url}/api/appliance/appliance'),
      headers: <String, String>{
        "authorization": "CRM $token",
        'Content-Type':
            'application/x-www-form-urlencoded', // Changed content type
        "id": "CRM $id",
      },
      body: formData, // Send as form data
    );

    print("Add appliances response: ${response.body}");
    var responseData = json.decode(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: "add appliances successfully");
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(msg: "Failed to add appliances");
      throw Exception('Failed to add appliances');
    }
  }

  Future<Map<String, dynamic>> Editappliances({
    String? adminId,
    String? unitId,
    String? applianceid,
    String? appliancename,
    String? appliancedescription,
    String? installeddate,
    String? type,
    String? brand,
    String? model,
    String? serialNumber,
    String? warrantyExpiry,
    String? lastMaintenanceDate,
    String? maintenanceNotes,
    String? status,
    String? categoryId,
    List<dynamic>? filters,
    String? appliance_image, // Add this parameter
  }) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');

    // Convert filters to JSON string
    String filtersJson = json.encode(filters ?? []);
    print('Filters as JSON string edit : $filtersJson');

    // Create form data
    var formData = {
      'admin_id': adminId,
      'unit_id': unitId,
      'appliance_id': applianceid,
      'appliance_name': appliancename,
      'appliance_description': appliancedescription,
      'installed_date': installeddate,
      'type': type,
      'brand': brand,
      'model': model,
      'serial_number': serialNumber,
      'warranty_expiry': warrantyExpiry,
      'last_maintenance_date': lastMaintenanceDate,
      'maintenance_notes': maintenanceNotes,
      'status': status,
      'category_id': categoryId,
      'filters': filtersJson,
      'appliance_image': appliance_image, // Add this field
    };

    print('Sending form data for edit: ${json.encode(formData)}');

    final http.Response response = await http.put(
      Uri.parse('${Api_url}/api/appliance/appliance/$applianceid'),
      headers: <String, String>{
        "authorization": "CRM $token",
        'Content-Type':
            'application/x-www-form-urlencoded', // Changed content type
        "id": "CRM $id",
      },
      body: formData, // Send as form data
    );

    print('Edit appliance response: ${response.body}');

    var responseData = json.decode(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: "Appliance updated successfully");
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(
          msg: responseData["message"] ?? "Failed to update appliance");
      throw Exception('Failed to update appliance');
    }
  }

  Future<Map<String, dynamic>> Editunit({
    String? adminId,
    String? id,
    String? unitId,
    String? rentalunit,
    String? rentalId,
    String? rentalunitadress,
    String? rentalsqft,
    String? rentalbath,
    String? rentalbed,
    List<String?>? rentalImages,
  }) async {
    final Map<String, dynamic> data = {
      'admin_id': adminId,
      'unit_id': unitId,
      'rental_unit': rentalunit,
      'rental_id': rentalId,
      'rental_images': rentalImages,
      'rental_unit_adress': rentalunitadress,
      'rental_sqft': rentalsqft,
      'rental_bath': rentalbath,
      'rental_bed': rentalbed,
      'rental_images': rentalImages
    };

    // print('$apiUrl/$id');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    final http.Response response = await http.put(
      Uri.parse('${Api_url}/api/unit/unit/$unitId'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        "authorization": "CRM $token",
        "id": "CRM $id",
      },
      body: jsonEncode(data),
    );
    print(jsonEncode(data));
    print(unitId);

    var responseData = json.decode(response.body);
    print(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: responseData["message"]);
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(msg: responseData["message"]);
      throw Exception('Failed to add property type');
    }
  }

  Future<Map<String, dynamic>> Deleteapplences(
      {required String? appliance_id}) async {
    // print('$apiUrl/$id');
    print('hello 123 ${appliance_id}');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    final http.Response response = await http.delete(
      Uri.parse('${Api_url}/api/appliance/appliance/$appliance_id'),
      headers: <String, String>{
        "authorization": "CRM $token",
        "id": "CRM $id",
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );
    var responseData = json.decode(response.body);
    print(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: responseData["message"]);
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(msg: responseData["message"]);
      throw Exception('Failed to delete applences');
    }
  }

  Future<Map<String, dynamic>> Deleteunit({required String? unitId}) async {
    // print('$apiUrl/$id');

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    final http.Response response = await http.delete(
      Uri.parse('${Api_url}/api/unit/unit/$unitId'),
      headers: <String, String>{
        "authorization": "CRM $token",
        "id": "CRM $id",
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );
    var responseData = json.decode(response.body);
    print(response.body);
    if (responseData["statusCode"] == 200) {
      Fluttertoast.showToast(msg: responseData["message"]);
      return json.decode(response.body);
    } else {
      Fluttertoast.showToast(msg: responseData["message"]);
      throw Exception('Failed to add property type');
    }
  }

  // Future<Rentals> fetchrentalDetails(String rentalId) async {
  //
  //   final response = await http.get(Uri.parse('${Api_url}/api/rentals/rental_summary/$rentalId'));
  //
  //   print(response.body);
  //   print(rentalId);
  //   print('${Api_url}/api/rentals/rental_summary/$rentalId');
  //
  //   if (response.statusCode == 200) {
  //     final jsonResponse = json.decode(response.body);
  //     if (jsonResponse['data'] is List) {
  //       return Rentals.fromJson(jsonResponse['data'][0]);
  //     } else {
  //       return Rentals.fromJson(jsonResponse['data']);
  //     }
  //   } else {
  //     throw Exception('Failed to load rental');
  //   }
  // }

  Future<Rentals> fetchrentalDetails(String rentalId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');

    final response = await http.get(
        Uri.parse('${Api_url}/api/rentals/rental_summary/$rentalId'),
        headers: {
          "authorization": "CRM $token",
          "id": "CRM $id",
          "Content-Type": "application/json"
        });

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['data'] is List) {
        return Rentals.fromJson(jsonResponse['data'][0]);
      } else {
        return Rentals.fromJson(jsonResponse['data']);
      }
    } else {
      print('Failed to load rental details: ${response.body}');
      throw Exception('Failed to load rental details');
    }
  }

  Future<List<Properties_lease_model>> fetchrLeaseDetails(String unitId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //String? id = prefs.getString("rentalid");
    String? id = prefs.getString('adminId');
    String? token = prefs.getString('token');
    print(id);
    final response = await http.get(
      Uri.parse('${Api_url}/api/leases/leases/$id/$unitId'),
      headers: {
        "authorization": "CRM $token",
        "id": "CRM $id",
      },
    );
    print(" get summery lease details ${response.body}");
    print(
        "lease  api for calling ${'${Api_url}/api/leases/leases/$id/$unitId'}");
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body)['data'];
      return jsonResponse
          .map((data) => Properties_lease_model.fromJson(data))
          .toList();
    } else {
      print('Failed to fetch lease table properties: ${response.body}');
      return [];
      //throw Exception('Failed to load data');
    }
  }

  Future<List<Properties_Revenu_model>> fetchrRevenueDetails(
      String unitId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    //String? id = prefs.getString("rentalid");
    String? id = prefs.getString('adminId');
    String? token = prefs.getString('token');
    print(id);
    final response = await http.get(
      Uri.parse('${Api_url}/api/leases/revenue/$id/$unitId'),
      headers: {
        "authorization": "CRM $token",
        "id": "CRM $id",
      },
    );
    print(" get properties revenue details ${response.body}");
    print(
        "properties revenue api for calling ${'${Api_url}/api/leases/revenue/$id/$unitId'}");
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body)['data'];
      return jsonResponse
          .map((data) => Properties_Revenu_model.fromJson(data))
          .toList();
    } else {
      print('Failed to fetch lease revenue table properties: ${response.body}');
      return [];
      //throw Exception('Failed to load data');
    }
  }

  Future<List<propertiesworkData>> fetchWorkOrders(String rentalId) async {
    // Retrieve admin ID and token from SharedPreferences
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString("adminId");
    String? token = prefs.getString('token');

    // Define the URL and headers for the request
    final response = await http.get(
      Uri.parse('$Api_url/api/work-order/rental_workorder/$rentalId'),
      headers: {
        'authorization': 'CRM $token',
        'id': 'CRM $id',
      },
    );
    // Check the response status
    print(response.body);
    print(rentalId);
    if (response.statusCode == 200) {
      // Parse the JSON response
      List jsonResponse = json.decode(response.body)['data'];
      // Map the JSON data to List<Data> and return
      return jsonResponse
          .map((data) => propertiesworkData.fromJson(data))
          .toList();
    } else {
      // Throw an exception if the request failed
      throw Exception('No work order found');
    }
  }

  Future<void> addrecurringtenant(Map<String, dynamic> data) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    String? id = prefs.getString('adminId');
    final http.Response response =
        await http.post(Uri.parse('${Api_url}/api/recurring-cards/add-cards'),
            headers: <String, String>{
              "authorization": "CRM $token",
              "id": "CRM $id",
              'Content-Type': 'application/json; charset=UTF-8',
            },
            body: jsonEncode(data));
    var responseData = json.decode(response.body);
    print(response.body);
  }
}

class tenant_cards {
  List<BillingData> cardDetails = [];
  int? customervaultid;
  Future<List<BillingData>> fetchcreditcard(String tenantId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString("adminId");
    String? token = prefs.getString('token');

    final response = await http.get(
      Uri.parse('$Api_url/api/creditcard/getCreditCards/$tenantId'),
      headers: {"id": "CRM $id", "authorization": "CRM $token"},
    );
    log("${response.body} || response boy");
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      customervaultid = jsonResponse['customer_vault_id'];
      List<dynamic> cardDetailsList = jsonResponse['card_detail'];

      // Debug print to check the response structure
      print('JSON Response: $jsonResponse');

      for (var cardDetail in cardDetailsList) {
        // Debug print to check each card detail
        print('Card Detail: $cardDetail');

        //  BillingData billingData = BillingData.fromJson(cardDetail);
        // print('Parsed Billing ID: ${billingData.billingId}');

        // Assuming this is part of the logic to print billing_id
        print('Billing ID: ${cardDetail['billing_id']}');
      }

      CustomerData? customerData = await postBillingCustomerVault(
          customervaultid.toString(), cardDetailsList);

      if (customerData != null) {
        return customerData.billing;
      }
      return [];
    } else if (response.statusCode == 404) {
      print('customer_vault_id not found');
      return [];
      // throw Exception('Failed to load credit card data');
    } else {
      return [];
      throw Exception('Failed to load credit card data');
    }
  }

  Future<CustomerData?> postBillingCustomerVault(
      String customerVaultId, List<dynamic> cardDetailsList) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? adminId = prefs.getString("adminId");
    String? token = prefs.getString('token');

    Map<String, String> requestBody = {
      "customer_vault_id": customerVaultId,
      "admin_id": adminId.toString(),
    };

    final response = await http.post(
      Uri.parse('$Api_url/api/nmipayment/get-billing-customer-vault'),
      headers: {
        'Content-Type': 'application/json',
        "id": "CRM $adminId",
        "authorization": "CRM $token",
      },
      body: json.encode(requestBody),
    );
    print(response.body);
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      var customerJson = jsonResponse['data']['customer'];
      CustomerData customerData = CustomerData.fromJson(customerJson);

      customerData.billing.forEach((billing) {
        print('CC Bin: ${billing.ccBin}');
      });

      // List<String> binResults = await performBinChecks(customerData);
      //
      // for (int i = 0; i < customerData.billing.length; i++) {
      //   customerData.billing[i].binResult = binResults[i];
      // }
      //
      // print('Number of BIN check results: ${binResults.length}');
      // binResults.forEach((result) {
      //   print('BIN Check Result: $result');
      // });
      for (int i = 0; i < customerData.billing.length; i++) {
        customerData.billing[i].binResult = cardDetailsList[i]["card_type"];
      }

      return customerData;
    } else {
      print('Failed to post data: ${response.statusCode}');
      return null;
    }
  }

  Future<List<String>> performBinChecks(CustomerData customerData) async {
    List<String> binResults = [];
    for (BillingData billing in customerData.billing) {
      String binResult = await binCheck(billing.ccBin ?? '');
      binResults.add(binResult);
    }
    return binResults;
  }

  Future<String> binCheck(String ccBin) async {
    final String apiUrl = 'https://bin-ip-checker.p.rapidapi.com/?bin=$ccBin';

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'X-RapidAPI-Key': '1bd772d3c3msh11c1022dee1c2aep1557bajsn0ac41ea04ef7',
        'X-RapidAPI-Host': 'bin-ip-checker.p.rapidapi.com',
      },
    );

    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      print('BIN check successful: ${jsonResponse['BIN']['type']}');
      return jsonResponse['BIN']['type'];
    } else {
      print('Failed to check BIN: ${response.statusCode}');
      return '';
    }
  }

  Future<Map<String, bool>> fetchCardAcceptance(
      String tenantId, String leaseId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? adminId = prefs.getString("adminId");
    String? token = prefs.getString('token');

    final response = await http.get(
      Uri.parse('$Api_url/api/tenant/payment_settings/$tenantId/$leaseId'),
      headers: {
        'Content-Type': 'application/json',
        "id": "CRM $adminId",
        "authorization": "CRM $token",
      },
    );
    print(response.body);
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return {
        'creditCardAccepted':
            responseData['data']['creditCardAccepted'] ?? false,
        'debitCardAccepted': responseData['data']['debitCardAccepted'] ?? false,
      };
    } else {
      throw Exception('Failed to load card acceptance');
    }
  }

// Function to filter cards based on the acceptance flags
  List<BillingData> filterCards(
      List<BillingData> cards, Map<String, bool> cardAcceptanceResponse) {
    bool creditAccepted = cardAcceptanceResponse['creditCardAccepted'] ?? false;
    bool debitAccepted = cardAcceptanceResponse['debitCardAccepted'] ?? false;

    return cards.where((card) {
      if (card.binResult == "CREDIT" && creditAccepted) {
        return true;
      }
      if (card.binResult == "DEBIT" && debitAccepted) {
        return true;
      }
      return false;
    }).toList();
  }

  Future<Map<String, dynamic>> disableCard(String rentalId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? adminId = prefs.getString("adminId");
    String? token = prefs.getString('token');

    final response = await http.put(
      Uri.parse('$Api_url/api/recurring-cards/disable-cards/$rentalId'),
      headers: {
        'Content-Type': 'application/json',
        "id": "CRM $adminId",
        "authorization": "CRM $token",
      },
    );
    print(response.body);
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return responseData;
    } else {
      throw Exception('Failed to load card acceptance');
    }
  }
}

class DropdownProvider with ChangeNotifier {
  List<String> _tenantCard = [];

  List<String> get tenantCard => _tenantCard;

  void updateTenantCard(int index, String value) {
    _tenantCard[index] = value;
    notifyListeners();
  }

  void initializeTenantCard(List<List<BillingData>> billingDataList) {
    print(billingDataList.length);

    _tenantCard = List<String>.generate(billingDataList.length,
        (index) => billingDataList[index].first.ccNumber!);
    // notifyListeners();
  }
}
