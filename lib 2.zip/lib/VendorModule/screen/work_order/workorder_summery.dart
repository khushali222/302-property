import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:three_zero_two_property/Model/tenants.dart';

// import 'package:three_zero_two_property/TenantsModule/widgets/drawer_tiles.dart';

import 'package:three_zero_two_property/constant/constant.dart';
import 'package:three_zero_two_property/repository/lease.dart';

import 'package:three_zero_two_property/screens/Leasing/RentalRoll/newModel.dart';
// import 'package:three_zero_two_property/repository/properties_summery.dart';
import '../../../provider/dateProvider.dart';
import '../../../widgets/VideoPlayerWidget.dart';
import '../../../widgets/titleBar.dart';
import '../../model/vendor_permission_model.dart';
import '../../repository/vendor_permission.dart';
import '../../widgets/appbar.dart';
import '../../widgets/drawer_tiles.dart';
import '../../repository/workorder.dart';
import '../../model/workorder_summery_model.dart';
import 'Edit_workorders.dart';

class Workorder_summery extends StatefulWidget {
  String? workorder_id;
  Workorder_summery({super.key, this.workorder_id});

  @override
  State<Workorder_summery> createState() => _Workorder_summeryState();
}

class _Workorder_summeryState extends State<Workorder_summery>
    with SingleTickerProviderStateMixin {
  List<String> applicantCheckedChecklist = [
    "CreditCheck",
    "EmploymentVerification",
    "ApplicationFee",
    "IncomeVerification",
    "LandlordVerification"
  ];

  List<String> applicantChecklist = [];
  final Map<String, String> displayNames = {
    "CreditCheck": "Credit and background check",
    "EmploymentVerification": "Employment verification",
    "ApplicationFee": "Application fee collected",
    "IncomeVerification": "Income verification",
    "LandlordVerification": "Landlord verification",
  };

  bool addcheckbox = false;
  TextEditingController startdateController = TextEditingController();
  TextEditingController enddateController = TextEditingController();
  TextEditingController checkvalue = TextEditingController();
  List formDataRecurringList = [];
  late Future<WorkOrderData_summery> futureworkorderSummary;
  String? _selectedValue;
  TabController? _tabController;
  List<String> items = ["Approved", "Rejected"];

  ConnectivityResult? _connectivityResult;

  @override
  void initState() {
    print(widget.workorder_id);
    // TODO: implement initState
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      setState(() {
        print(result);
        _connectivityResult = result;
      });
    });
    checkInternet();
    futureworkorderSummary =
        WorkOrderRepository.getworkorderSummary(widget.workorder_id!);

    _tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  void checkInternet() async {
    var connectiondata;
    connectiondata = await Connectivity().checkConnectivity();
    setState(() {
      _connectivityResult = connectiondata;
    });
    await Provider.of<VendorPermission>(context, listen: false)
        .fetchPermissions();
  }

  GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();
  int visibleCount = 5;
  @override
  Widget build(BuildContext context) {
    //   Provider.of<NotificationProvider>(context, listen: false).fetchNotificationsStaff(context);
    final permissionProvider = Provider.of<VendorPermission>(context);
    UserPermissions? permissions = permissionProvider.permissions;

    return Scaffold(
      // appBar: widget302.,
      key: key,
      appBar: widget_302.App_Bar(
        context: context,
        onDrawerIconPressed: () {
          key.currentState!.openDrawer();
        },
      ),
      backgroundColor: Colors.white,
      /* drawer: Drawer(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 40),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Image.asset("assets/images/logo.png"),
              ),
              const SizedBox(height: 40),
              buildListTile(
                  context,
                  SvgPicture.asset(
                    "assets/images/tenants/dashboard.svg",
                    fit: BoxFit.cover,
                    height: 20,
                    width: 20,
                  ),
                  "Dashboard",
                  false),
              buildListTile(
                  context,
                  SvgPicture.asset(
                    "assets/images/tenants/Admin.svg",
                    fit: BoxFit.cover,
                    height: 20,
                    width: 20,
                  ),
                  "Profile",
                  false),
              */ /*  buildListTile(
                  context,
                  SvgPicture.asset(
                    "assets/images/tenants/Property.svg",
                    fit: BoxFit.cover,
                    height: 20,
                    width: 20,
                  ),
                  "Properties",
                  false),
              buildListTile(
                  context,
                  SvgPicture.asset(
                    "assets/images/tenants/Financial.svg",
                    fit: BoxFit.cover,
                    height: 20,
                    width: 20,
                  ),
                  "Financial",
                  false),*/ /*
              buildListTile(
                  context,
                  SvgPicture.asset(
                    "assets/images/tenants/Work Light.svg",
                    fit: BoxFit.cover,
                    height: 20,
                    width: 20,
                  ),
                  "Work Order",
                  true),
              */ /* buildDropdownListTile(
                  context,
                  const FaIcon(
                    FontAwesomeIcons.key,
                    size: 20,
                    color: Colors.black,
                  ),
                  "Rental",
                  ["Properties", "RentalOwner", "Tenants"]),
              buildDropdownListTile(
                  context,
                  const FaIcon(
                    FontAwesomeIcons.thumbsUp,
                    size: 20,
                    color: Colors.black,
                  ),
                  "Leasing",
                  ["Rent Roll", "Applicants"]),
              buildDropdownListTile(
                  context,
                  Image.asset("assets/icons/maintence.png",
                      height: 20, width: 20),
                  "Maintenance",
                  ["Vendor", "Work Order"]),*/ /*
            ],
          ),
        ),
      ),*/
      body: _connectivityResult != ConnectivityResult.none
          ? Column(
              children: [
                SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    Spacer(),
                    /*  GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Material(
                  elevation: 3,
                  borderRadius: const BorderRadius.all(
                    Radius.circular(5),
                  ),
                  child: Container(
                    height: 40,
                    width: 80,
                    decoration: const BoxDecoration(
                      color: blueColor,
                      borderRadius: BorderRadius.all(
                        Radius.circular(5),
                      ),
                    ),
                    child: const Center(
                        child: Text(
                      "Back",
                      style: TextStyle(
                          fontWeight: FontWeight.w500, color: Colors.white),
                    )),
                  ),
                ),
              ),*/
                    const SizedBox(
                      width: 20,
                    ),
                    if (permissions!.workorderEdit)
                      GestureDetector(
                        onTap: () async {
                          var getback = await Navigator.of(context)
                              .push(MaterialPageRoute(
                                  builder: (context) => Edit_Workorder(
                                        workorderId: widget.workorder_id!,
                                      )));
                          if (getback == true) {
                            setState(() {
                              futureworkorderSummary =
                                  WorkOrderRepository.getworkorderSummary(
                                      widget.workorder_id!);
                            });
                          }
                        },
                        child: Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(
                            Radius.circular(5),
                          ),
                          child: Container(
                            height: 40,
                            width: 100,
                            decoration: BoxDecoration(
                              color: blueColor,
                              borderRadius: BorderRadius.all(
                                Radius.circular(5),
                              ),
                            ),
                            child: const Center(
                                child: Text(
                              "Edit Details",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            )),
                          ),
                        ),
                      ),
                    const SizedBox(
                      width: 20,
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                titleBar(
                  width: MediaQuery.of(context).size.width * .91,
                  title: 'Work Order Details',
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: FutureBuilder<WorkOrderData_summery>(
                        future: futureworkorderSummary,
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Center(
                              child: SpinKitFadingCircle(
                                color: Colors.black,
                                size: 55.0,
                              ),
                            );
                          } else if (snapshot.hasError) {
                            return Center(
                                child: Text('Error: ${snapshot.error}'));
                          } else if (!snapshot.hasData ||
                              snapshot.data == null) {
                            return Center(child: Text('No data found.'));
                          } else {
                            // _selectedValue = snapshot.data!.applicantStatus!.last!.status;
                            return Column(
                              children: <Widget>[
                                const SizedBox(
                                  height: 10,
                                ),
                                Container(
                                  margin: const EdgeInsets.symmetric(horizontal: 5),
                                  height: 50,
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: TabBar(
                                    controller: _tabController,
                                    labelPadding: const EdgeInsets.symmetric(horizontal: 0),
                                    indicator: BoxDecoration(
                                      color: blueColor,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    labelColor: Colors.white,
                                    unselectedLabelColor: blueColor,
                                    indicatorSize: TabBarIndicatorSize.tab,
                                    tabs: const [
                                      Tab(text: 'Summary'),
                                      Tab(text: 'Task'),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 0),
                                Expanded(
                                  child: TabBarView(
                                    controller: _tabController,
                                    children: [
                                      Summery_page(snapshot.data!),
                                      Task(snapshot.data!),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          }
                        }),
                  ),
                ),
              ],
            )
          : SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Lottie.asset(
                    'assets/no_internet.json',
                    width: 200,
                    height: 200,
                    fit: BoxFit.fill,
                  ),
                  Text(
                    'No Internet',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Check your internet connection',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
    );
  }

  List<String> titles = [' Account', 'Qty', '  Price', 'Amount'];
  Map<int, TableColumnWidth> columnWidth = {
    0: FlexColumnWidth(3.3),
    1: FlexColumnWidth(1),
    2: FlexColumnWidth(1.9),
    3: FlexColumnWidth(1.81),
  };
  // int getTotalPrice() {
  //   //return products.fold(0, (sum, item) => sum + item.totalAmount);
  //   return 0;
  // }
  double getTotalPrice(List<PartsandchargeData>? partsList) {
    if (partsList == null || partsList.isEmpty) return 0.0;

    return partsList.fold(
        0.0,
        (sum, item) =>
            sum + ((item.partsQuantity ?? 0) * (item.partsPrice ?? 0)));
  }

  Summery_page(WorkOrderData_summery summery) {
    double grandTotal = 0;
    // applicantChecklist = List<String>.from(summery.applicantCheckedChecklist!);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 600) {
        return SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width * .48,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        border: Border.all(color: blueColor),
                        // color: Colors.blue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  color: blueColor,
                                  border: Border.all(color: blueColor),
                                  // color: Colors.blue,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Icon(
                                  Icons.menu,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                    '${summery.workSubject}',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor),
                                  )),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                      child: Text(
                                    '${summery.propertyData?.rentaladress}',
                                    style: TextStyle(color: blueColor),
                                  )),
                                ],
                              )
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                    'Description',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor),
                                  )),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                      width: 150,
                                      child: Text(
                                        '${summery.workPerformed}',
                                        style: TextStyle(color: blueColor),
                                      )),
                                ],
                              ),
                              Spacer(),
                              Container(
                                height: 70,
                                width: MediaQuery.of(context).size.width * .2,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Status",
                                      style: TextStyle(
                                        color: blueColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text('${summery.status}',
                                        style: TextStyle(
                                            color: blueColor,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                    'Permission to enter',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor),
                                  )),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                      child: Text(
                                    '${summery.entryAllowed! ? "Yes" : "No"}',
                                    style: TextStyle(color: blueColor),
                                  )),
                                ],
                              ),
                              Spacer(),
                              Container(
                                height: 70,
                                width: MediaQuery.of(context).size.width * .2,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Due Date",
                                      style: TextStyle(
                                        color: blueColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text(
                                        '${summery.workorderUpdates!.last.date!.isEmpty == true ? "N/A" : summery.workorderUpdates?.last.date?.toString()}',
                                        style: TextStyle(
                                            color: blueColor,
                                            fontWeight: FontWeight.bold)),
                                    SizedBox(
                                      height: 10,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                    'Vendors Notes',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: blueColor),
                                  )),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                      child: Text(
                                    '${summery.vendorNotes}',
                                    style: TextStyle(color: blueColor),
                                  )),
                                ],
                              ),
                              Spacer(),
                              Container(
                                height: 70,
                                width: MediaQuery.of(context).size.width * .2,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Assignees",
                                      style: TextStyle(
                                        color: blueColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    summery.staffData != null
                                        ? Text(
                                            '${summery.staffData?.firstname}',
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold))
                                        : Text('N/A',
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold)),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * .45,
                      child: Column(
                        children: [
                          if (summery.tenantData != null)
                            SizedBox(
                              height: 220,
                              child: Material(
                                elevation: 7,
                                borderOnForeground: true,
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  height: 220,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Column(
                                    children: [
                                      Expanded(
                                        flex: 2, // 40%
                                        child: Container(
                                          decoration: BoxDecoration(
                                            // color: Colors.blue,
                                            borderRadius: BorderRadius.vertical(
                                              top: Radius.circular(10),
                                            ),
                                            /*   boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.5),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 3), // changes position of shadow
                                ),
                              ],*/
                                          ),
                                          child: Material(
                                            elevation: 4,
                                            color: Colors.white,
                                            borderRadius: BorderRadius.vertical(
                                              top: Radius.circular(10),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Contacts',
                                                style: TextStyle(
                                                    color: blueColor,
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 7, // 60%
                                        child: Column(
                                          children: [
                                            Container(
                                                decoration: BoxDecoration(
                                                  //  color: Colors.green,
                                                  borderRadius:
                                                      BorderRadius.vertical(
                                                    bottom: Radius.circular(10),
                                                  ),
                                                ),
                                                child: ListTile(
                                                  title: Text(
                                                    "Vendor",
                                                    style: TextStyle(
                                                        color: blueColor,
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                  subtitle: summery
                                                              .vendorData !=
                                                          null
                                                      ? Text(
                                                          summery.vendorData!
                                                                  .companyName ??
                                                              "N/A",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        )
                                                      : Text(
                                                          "N/A",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        ),
                                                  leading: Container(
                                                    padding:
                                                        EdgeInsets.only(top: 3),
                                                    child: Icon(
                                                      Icons.person,
                                                      size: 30,
                                                    ),
                                                  ),
                                                )),
                                            Divider(
                                              thickness: 3,
                                            ),
                                            Container(
                                                decoration: BoxDecoration(
                                                  //  color: Colors.green,
                                                  borderRadius:
                                                      BorderRadius.vertical(
                                                    bottom: Radius.circular(10),
                                                  ),
                                                ),
                                                child: ListTile(
                                                  title: Text(
                                                    "Tenant",
                                                    style: TextStyle(
                                                        color: blueColor,
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                  subtitle: summery
                                                              .tenantData !=
                                                          null
                                                      ? Text(
                                                          "${summery.tenantData!.firstname ?? "N/A"} ${summery.tenantData!.lastname ?? "N/A"}",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        )
                                                      : Text(
                                                          "N/A",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        ),
                                                  leading: Container(
                                                    padding:
                                                        EdgeInsets.only(top: 3),
                                                    child: Icon(
                                                      Icons.person,
                                                      size: 30,
                                                    ),
                                                  ),
                                                )),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          if (summery.tenantData == null)
                            SizedBox(
                              height: 100,
                              child: Material(
                                elevation: 7,
                                borderOnForeground: true,
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  height: 100,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Column(
                                    children: [
                                      Expanded(
                                        flex: 3, // 40%
                                        child: Container(
                                          decoration: BoxDecoration(
                                            // color: Colors.blue,
                                            borderRadius: BorderRadius.vertical(
                                              top: Radius.circular(10),
                                            ),
                                            /*   boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.5),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 3), // changes position of shadow
                                ),
                              ],*/
                                          ),
                                          child: Material(
                                            elevation: 4,
                                            color: Colors.white,
                                            borderRadius: BorderRadius.vertical(
                                              top: Radius.circular(10),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Contacts',
                                                style: TextStyle(
                                                    color: blueColor,
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 7, // 60%
                                        child: Container(
                                            decoration: BoxDecoration(
                                              //  color: Colors.green,
                                              borderRadius:
                                                  BorderRadius.vertical(
                                                bottom: Radius.circular(10),
                                              ),
                                            ),
                                            child: ListTile(
                                              title: Text(
                                                "Vendor",
                                                style: TextStyle(
                                                    color: blueColor,
                                                    fontWeight:
                                                        FontWeight.w500),
                                              ),
                                              subtitle:
                                                  summery.vendorData != null
                                                      ? Text(
                                                          summery.vendorData!
                                                                  .companyName ??
                                                              "N/A",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        )
                                                      : Text(
                                                          "N/A",
                                                          style: TextStyle(
                                                              color: blueColor),
                                                        ),
                                              leading: Container(
                                                padding:
                                                    EdgeInsets.only(top: 3),
                                                child: Icon(
                                                  Icons.person,
                                                  size: 30,
                                                ),
                                              ),
                                            )),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          SizedBox(
                            height: 10,
                          ),
                          Material(
                            elevation: 7,
                            borderOnForeground: true,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.vertical(
                                        top: Radius.circular(10),
                                      ),
                                    ),
                                    child: Material(
                                      elevation: 4,
                                      color: Colors.white,
                                      borderRadius: BorderRadius.vertical(
                                        top: Radius.circular(10),
                                      ),
                                      child: Center(
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            'Property',
                                            style: TextStyle(
                                              color: blueColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      if (summery.propertyData!.rental_image !=
                                          null)
                                        Column(
                                          children: [
                                            SizedBox(
                                              height: 10,
                                            ),
                                            CachedNetworkImage(
                                              imageUrl:
                                                  "$image_url${summery.propertyData!.rental_image}",
                                              placeholder: (context, url) => Text(
                                                  "${summery.propertyData!.rental_image}"),
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Icon(Icons.error),
                                              /*  imageBuilder: (context, imageProvider) => Container(
                                      width: 40.0,
                                      height: 40.0,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                          image: imageProvider,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),*/
                                            ),
                                          ],
                                        ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        "${summery.propertyData!.rentaladress} (${summery.unitData!.unitName})",
                                        textAlign: TextAlign.center,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                              "${summery.propertyData!.rental_city}, "),
                                          Text(
                                              "${summery.propertyData!.rental_state}, "),
                                          Text(
                                              "${summery.propertyData!.rental_country}, "),
                                          Text(
                                              "${summery.propertyData!.rental_postcode} "),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                    ],
                                  )
                                  /*  ListTile(
                            title: Text(
                              "Vendor",
                              style: TextStyle(
                                color: blueColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            subtitle: Text(
                              "Vendor Company Name",
                              style: TextStyle(color: blueColor),
                            ),
                            leading: Container(
                              padding: EdgeInsets.only(top: 3),
                              child: Icon(
                                Icons.person,
                                size: 30,
                              ),
                            )

                          ),*/
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 30,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                if (summery.partsandchargeData!.length > 0)
                  IntrinsicHeight(
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: blueColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      // padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Parts and Labor',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                                fontSize: 16),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          /*Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Column(
                                      children: summery.partsandchargeData!.map((part) {
                                        int partTotal =
                                        (part.partsPrice! * part.partsQuantity!);
                                        print(partTotal);
                                        grandTotal += partTotal;
                                        print(grandTotal);
                                        return PartWidget(part: part, total: 0.0);
                                      }).toList(),
                                    ),
                                    */ /*  Column(
                                  children: summery.partsandchargeData!.map((part) {
                                    int partTotal = (part.partsPrice! * part.partsQuantity!);
                                    print(partTotal);
                                    grandTotal += partTotal;
                                    print(grandTotal);
                                    return PartWidget(part: part, total:0.0);
                                  }).toList(),
                                ),*/ /*
                                    // Divider(color: Colors.grey),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Total',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16),
                                        ),
                                        Text(
                                          '\$${grandTotal.toStringAsFixed(2)}',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            color: Colors.black87,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),*/
                          Table(
                            border: TableBorder.all(width: 1),
                            columnWidths: const {
                              0: FlexColumnWidth(1),
                              1: FlexColumnWidth(2),
                              2: FlexColumnWidth(2),
                              3: FlexColumnWidth(2),
                              4: FlexColumnWidth(2),
                            },
                            children: [
                              TableRow(children: [
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('QTY',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('Account',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('Description',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('Price',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('Amount',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ),
                              ]),
                              ...summery.partsandchargeData!
                                  .asMap()
                                  .entries
                                  .map((entry) {
                                int index = entry.key;
                                PartsandchargeData row = entry.value;
                                grandTotal +=
                                    (row.partsQuantity! * row.partsPrice!);
                                return TableRow(children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text("${row.partsQuantity}"),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text("${row.account}"),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text("${row.description}"),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text("\$${row.partsPrice}"),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                        "\$${(row.partsPrice! * row.partsQuantity!)}"),
                                  ),
                                ]);
                              }).toList(),
                              TableRow(children: [
                                const Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('Total',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text('',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text("\$${grandTotal.toString()}",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                ),

                                /* Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                                '\$${totalAmount.toStringAsFixed(2)}'),
                          ),*/
                              ]),
                              /*TableRow(children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: 34,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(width: 1),
                                  borderRadius:
                                  BorderRadius.circular(10.0)),
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(
                                            10.0)),
                                    elevation: 0,
                                    backgroundColor: Colors.white),
                                onPressed: addRow,
                                child: const Text(
                                  'Add Row',
                                  style: TextStyle(
                                    color:
                                    blueColor,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox.shrink(),
                          const SizedBox.shrink(),
                        ]),*/
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: blueColor),
                      // color: Colors.blue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 10,
                            ),
                            Text("Updates",
                                style: TextStyle(
                                    color: blueColor,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                            SizedBox(
                              width: 20,
                            ),
                            InkWell(
                              onTap: () {
                                showUpdateDialog(context);
                              },
                              child: Material(
                                elevation: 4,
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                                child: Container(
                                  height: 40,
                                  width: 70,
                                  child: Center(child: Text("Update")),
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: summery.workorderUpdates!.map((entry) {
                            final update = entry;
                            return Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    '${update.statusUpdatedBy ?? ""} updated this work order (${update.date ?? "N/A"})',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  Divider(color: Colors.black),
                                  Text('Work Order Is Updated'),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    )),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        );
      } else {
        return SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(color: blueColor),
                    // color: Colors.blue,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                              color: blueColor,
                              border: Border.all(color: blueColor),
                              // color: Colors.blue,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.menu,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(
                            width: 20,
                          ),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: MediaQuery.of(context).size.width > 500
                                      ? 200
                                      : 180,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 1),
                                    child: Text(
                                      '${summery.workSubject}',
                                      maxLines:
                                          5, // Set maximum number of lines
                                      overflow: TextOverflow
                                          .ellipsis, // Handle overflow with ellipsis
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 13
                                              : 18,
                                          color: blueColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                                // Container(
                                //     child: Text(
                                //       '${summery.workSubject}',
                                //       maxLines: 5,
                                //       textAlign: TextAlign.justify,
                                //       style: TextStyle(
                                //           fontWeight: FontWeight.bold, color: blueColor),
                                //     )),
                                SizedBox(
                                  height: 10,
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width > 500
                                      ? 200
                                      : 180,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 1),
                                    child: Text(
                                      '${summery.propertyData?.rentaladress}',
                                      maxLines:
                                          5, // Set maximum number of lines
                                      overflow: TextOverflow
                                          .ellipsis, // Handle overflow with ellipsis
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                      .size
                                                      .width <
                                                  500
                                              ? 13
                                              : 18,
                                          color: blueColor,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                ),
                                // Container(
                                //     child: Text(
                                //       maxLines: 4,
                                //       '${summery.propertyData?.rentaladress}',
                                //       style: TextStyle(color: blueColor),
                                //     )),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  child: Text(
                                'Description',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: blueColor),
                              )),
                              SizedBox(
                                height: 8,
                              ),
                              Container(
                                  width: 150,
                                  child: Text(
                                    '${summery.workPerformed!.isNotEmpty ? summery.workPerformed : "N/A"}',
                                    style: TextStyle(color: blueColor),
                                  )),
                            ],
                          ),
                          Spacer(),
                          Container(
                            height: 70,
                            width: MediaQuery.of(context).size.width * .3,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey),
                            ),
                            child: Column(
                              // crossAxisAlignment: CrossAxisAlignment.center,
                              // mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Status",
                                  style: TextStyle(
                                    color: blueColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                Text('${summery.status}',
                                    style: TextStyle(
                                        color: blueColor,
                                        fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  child: Text(
                                'Permission to enter',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: blueColor),
                              )),
                              SizedBox(
                                height: 8,
                              ),
                              Container(
                                  child: Text(
                                '${summery.entryAllowed! ? "Yes" : "No"}',
                                style: TextStyle(color: blueColor),
                              )),
                            ],
                          ),
                          Spacer(),
                          Container(
                            height: 70,
                            width: MediaQuery.of(context).size.width * .3,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey),
                            ),
                            child: Column(
                              // crossAxisAlignment: CrossAxisAlignment.center,
                              // mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Due Date",
                                  style: TextStyle(
                                    color: blueColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                Text(
                                    '${summery.workorderUpdates!.last.date!.isEmpty == true ? "N/A" : summery.workorderUpdates?.last.date?.toString()}',
                                    style: TextStyle(
                                        color: blueColor,
                                        fontWeight: FontWeight.bold)),
                                SizedBox(
                                  height: 10,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  child: Text(
                                'Vendors Notes',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: blueColor),
                              )),
                              SizedBox(
                                height: 8,
                              ),
                              Container(
                                  child: Text(
                                '${summery.vendorNotes!.isNotEmpty ? summery.vendorNotes : "N/A"}',
                                style: TextStyle(color: blueColor),
                              )),
                            ],
                          ),
                          Spacer(),
                          Container(
                            //height: 70,
                            width: MediaQuery.of(context).size.width * .3,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey),
                            ),
                            child: Column(
                              // crossAxisAlignment: CrossAxisAlignment.center,
                              // mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Assignees",
                                  style: TextStyle(
                                    color: blueColor,
                                  ),
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                summery.staffData != null
                                    ? Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Text(
                                                '${summery.staffData?.firstname}',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: blueColor,
                                                    fontWeight:
                                                        FontWeight.bold)),
                                          ),
                                        ],
                                      )
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text('N/A',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: blueColor,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                SizedBox(
                                  height: 5,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                if (summery.partsandchargeData!.length > 0)
                  IntrinsicHeight(
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: blueColor),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      // padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Parts and Labor',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: blueColor,
                                fontSize: 16),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          CustomTableView(
                            titles: titles,
                            data: [],
                            isHeader: true,
                            columnWidths: columnWidth,
                            description: "",
                            showDescription: false,
                          ),

                          Column(
                            children: summery.partsandchargeData!
                                .map((item) => Container(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomTableView(
                                            titles: [],
                                            data: [
                                              [
                                                item.account!,
                                                item.partsQuantity.toString(),
                                                "\$${item.partsPrice!.toStringAsFixed(2)}",
                                                "\$${item.amount!.toStringAsFixed(2)}",
                                              ]
                                            ],
                                            isHeader: false,
                                            columnWidths: columnWidth,
                                            description: item.description!,
                                            showDescription: true,
                                          ),
                                        ],
                                      ),
                                    ))
                                .toList(),
                          ),
                          CustomTableView(
                            titles: [],
                            data: [
                              [
                                "Total",
                                "",
                                "",
                                "\$${getTotalPrice(summery.partsandchargeData).toStringAsFixed(2)}"
                              ]
                            ],
                            isHeader: false,
                            columnWidths: columnWidth,
                            description: "",
                            showDescription: false,
                          ),
                          // SizedBox(
                          //   height: 10,
                          // ),
                          // Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: Column(
                          //     children: [
                          //       Column(
                          //         children: summery.partsandchargeData!.map((part) {
                          //           int partTotal =
                          //           (part.partsPrice! * part.partsQuantity!);
                          //           print(partTotal);
                          //           grandTotal += partTotal;
                          //           print(grandTotal);
                          //           return PartWidget(part: part, total: 0.0);
                          //         }).toList(),
                          //       ),
                          //       /*  Column(
                          //     children: summery.partsandchargeData!.map((part) {
                          //       int partTotal = (part.partsPrice! * part.partsQuantity!);
                          //       print(partTotal);
                          //       grandTotal += partTotal;
                          //       print(grandTotal);
                          //       return PartWidget(part: part, total:0.0);
                          //     }).toList(),
                          //   ),*/
                          //       // Divider(color: Colors.grey),
                          //       Row(
                          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          //         children: [
                          //           Text(
                          //             'Total',
                          //             style: TextStyle(
                          //                 fontWeight: FontWeight.bold,
                          //                 fontSize: 16),
                          //           ),
                          //           Text(
                          //             '\$${grandTotal.toStringAsFixed(2)}',
                          //             style: TextStyle(
                          //               fontWeight: FontWeight.bold,
                          //               fontSize: 16,
                          //               color: Colors.black87,
                          //             ),
                          //           ),
                          //         ],
                          //       ),
                          //     ],
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: blueColor),
                      // color: Colors.blue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 2,
                            ),
                            Text("Updates",
                                style: TextStyle(
                                    color: blueColor,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Display the updates
                            ...summery.workorderUpdates!
                                .take(visibleCount)
                                .map((entry) {
                                  final update = entry;
                                  return Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${update.statusUpdatedBy ?? ""} updated this work order (${update.updatedAt != null ? update.updatedAt : update.createdAt ?? "N/A"})',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Divider(color: Colors.black),
                                        // Text('Work Order Is Updated'),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            if (update.status != "")
                                              Text(
                                                'Status : ${update.status != "" ? update.status : update.status ?? "N/A"}',
                                                style: TextStyle(
                                                    color: greyColor,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            if (update.date != "")
                                              Text(
                                                'Due Date : ${update.date != "" ? update.date : update.date ?? "N/A"}',
                                                style: TextStyle(
                                                    color: greyColor,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                          ],
                                        ),
                                        if (update.staffmemberName != "")
                                          SizedBox(
                                            height: 5,
                                          ),
                                        if (update.staffmemberName != "")
                                          Row(
                                            children: [
                                              Text(
                                                'Assigned To : ${update.staffmemberName != null ? update.staffmemberName : update.staffmemberName ?? "N/A"}',
                                                style: TextStyle(
                                                    color: greyColor,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ],
                                          ),
                                      ],
                                    ),
                                  );
                                })
                                .toList()
                                .reversed
                                .toList(),

                            // "View More" or "View Less" button
                            if (summery.workorderUpdates!.length > 5)
                              TextButton(
                                onPressed: () {
                                  setState(() {
                                    // Toggle between showing all or limited items
                                    if (visibleCount == 5) {
                                      visibleCount =
                                          summery.workorderUpdates!.length;
                                    } else {
                                      visibleCount = 5;
                                    }
                                  });
                                },
                                child: Text(
                                  visibleCount == 5 ? 'View More' : 'View Less',
                                  style: TextStyle(color: blueColor),
                                ),
                              ),
                          ],
                        ),
                        // Column(
                        //   mainAxisAlignment: MainAxisAlignment.start,
                        //   crossAxisAlignment: CrossAxisAlignment.start,
                        //   children: summery.workorderUpdates!.map((entry) {
                        //     final update = entry;
                        //     return
                        //       Padding(
                        //       padding: const EdgeInsets.all(5.0),
                        //       child: Column(
                        //         crossAxisAlignment: CrossAxisAlignment.start,
                        //         mainAxisAlignment: MainAxisAlignment.start,
                        //         children: [
                        //           Text(
                        //             '${update.statusUpdatedBy ?? ""} updated this work order (${update.date ?? "N/A"})',
                        //             style: TextStyle(fontWeight: FontWeight.bold),
                        //           ),
                        //           Divider(color: Colors.black),
                        //           Text('Work Order Is Updated'),
                        //         ],
                        //       ),
                        //     );
                        //   }).toList(),
                        // ),
                      ],
                    )),
                SizedBox(
                  height: 10,
                ),
                if (summery.tenantData != null)
                  SizedBox(
                    height: 220,
                    child: Material(
                      elevation: 7,
                      borderOnForeground: true,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        height: 220,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: [
                            Expanded(
                              flex: 2, // 40%
                              child: Container(
                                decoration: BoxDecoration(
                                  // color: Colors.blue,
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                  /*   boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                spreadRadius: 1,
                                blurRadius: 5,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],*/
                                ),
                                child: Material(
                                  elevation: 4,
                                  color: Colors.white,
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Contacts',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 7, // 60%
                              child: Column(
                                children: [
                                  Container(
                                      decoration: BoxDecoration(
                                        //  color: Colors.green,
                                        borderRadius: BorderRadius.vertical(
                                          bottom: Radius.circular(10),
                                        ),
                                      ),
                                      child: ListTile(
                                        title: Text(
                                          "Vendor",
                                          style: TextStyle(
                                              color: blueColor,
                                              fontWeight: FontWeight.w500),
                                        ),
                                        subtitle: summery.vendorData != null
                                            ? Text(
                                                summery.vendorData!
                                                        .companyName ??
                                                    "N/A",
                                                style:
                                                    TextStyle(color: blueColor),
                                              )
                                            : Text(
                                                "N/A",
                                                style:
                                                    TextStyle(color: blueColor),
                                              ),
                                        leading: Container(
                                          padding: EdgeInsets.only(top: 3),
                                          child: Icon(
                                            Icons.person,
                                            size: 30,
                                          ),
                                        ),
                                      )),
                                  Divider(
                                    thickness: 3,
                                  ),
                                  Container(
                                      decoration: BoxDecoration(
                                        //  color: Colors.green,
                                        borderRadius: BorderRadius.vertical(
                                          bottom: Radius.circular(10),
                                        ),
                                      ),
                                      child: ListTile(
                                        title: Text(
                                          "Tenant",
                                          style: TextStyle(
                                              color: blueColor,
                                              fontWeight: FontWeight.w500),
                                        ),
                                        subtitle: summery.tenantData != null
                                            ? Text(
                                                "${summery.tenantData!.firstname ?? "N/A"} ${summery.tenantData!.lastname ?? "N/A"}",
                                                style:
                                                    TextStyle(color: blueColor),
                                              )
                                            : Text(
                                                "N/A",
                                                style:
                                                    TextStyle(color: blueColor),
                                              ),
                                        leading: Container(
                                          padding: EdgeInsets.only(top: 3),
                                          child: Icon(
                                            Icons.person,
                                            size: 30,
                                          ),
                                        ),
                                      )),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                if (summery.tenantData == null)
                  SizedBox(
                    height: 100,
                    child: Material(
                      elevation: 7,
                      borderOnForeground: true,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        height: 100,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: [
                            Expanded(
                              flex: 3, // 40%
                              child: Container(
                                decoration: BoxDecoration(
                                  // color: Colors.blue,
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                  /*   boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                spreadRadius: 1,
                                blurRadius: 5,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],*/
                                ),
                                child: Material(
                                  elevation: 4,
                                  color: Colors.white,
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Contacts',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 7, // 60%
                              child: Container(
                                  decoration: BoxDecoration(
                                    //  color: Colors.green,
                                    borderRadius: BorderRadius.vertical(
                                      bottom: Radius.circular(10),
                                    ),
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      "Vendor",
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    subtitle: summery.vendorData != null
                                        ? Text(
                                            summery.vendorData!.companyName ??
                                                "N/A",
                                            style: TextStyle(color: blueColor),
                                          )
                                        : Text(
                                            "N/A",
                                            style: TextStyle(color: blueColor),
                                          ),
                                    leading: Container(
                                      padding: EdgeInsets.only(top: 3),
                                      child: Icon(
                                        Icons.person,
                                        size: 30,
                                      ),
                                    ),
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                SizedBox(
                  height: 10,
                ),
                Material(
                  elevation: 7,
                  borderOnForeground: true,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(10),
                            ),
                          ),
                          child: Material(
                            elevation: 4,
                            color: Colors.white,
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(10),
                            ),
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Property',
                                  style: TextStyle(
                                    color: blueColor,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            if (summery.propertyData!.rental_image != null &&
                                summery.propertyData!.rental_image!.isNotEmpty)
                              Column(
                                children: [
                                  SizedBox(
                                    height: 10,
                                  ),
                                  CachedNetworkImage(
                                    imageUrl:
                                        "$image_url${summery.propertyData!.rental_image}",
                                    placeholder: (context, url) => Text(
                                        "${summery.propertyData!.rental_image}"),
                                    errorWidget: (context, url, error) =>
                                        Icon(Icons.error),
                                    /*  imageBuilder: (context, imageProvider) => Container(
                                    width: 40.0,
                                    height: 40.0,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        image: imageProvider,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),*/
                                  ),
                                ],
                              ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "${summery.propertyData!.rentaladress} ${summery.unitData?.rental_unit != null ? '(${summery.unitData?.rental_unit})' : ''}",
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              width: 300,
                              child: Wrap(
                                alignment: WrapAlignment.center,
                                spacing:
                                    4.0, // Space between texts horizontally
                                runSpacing:
                                    4.0, // Space between lines when wrapping
                                children: [
                                  Text(
                                      "${summery.propertyData!.rental_city}, "),
                                  Text(
                                      "${summery.propertyData!.rental_state}, "),
                                  Text(
                                      "${summery.propertyData!.rental_country}, "),
                                  Text(
                                      "${summery.propertyData!.rental_postcode}"),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        )
                        /*  ListTile(
                          title: Text(
                            "Vendor",
                            style: TextStyle(
                              color: blueColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          subtitle: Text(
                            "Vendor Company Name",
                            style: TextStyle(color: blueColor),
                          ),
                          leading: Container(
                            padding: EdgeInsets.only(top: 3),
                            child: Icon(
                              Icons.person,
                              size: 30,
                            ),
                          )

                        ),*/
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        );
      }
    });
  }

  Task(WorkOrderData_summery summery) {
    print(summery.workOrderImages);
    final dateProvider = Provider.of<DateProvider>(context,listen: false);

    double grandTotal = 0;
    // applicantChecklist = List<String>.from(summery.applicantCheckedChecklist!);
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: LayoutBuilder(
          builder: (context, constraints) {
            if(constraints.maxWidth > 500){
              return SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * .5,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            border: Border.all(color:blueColor),
                            // color: Colors.blue,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Container(
                                    height: 40,
                                    width: 40,
                                    decoration: BoxDecoration(
                                      color: blueColor,
                                      border: Border.all(
                                          color:blueColor),
                                      // color: Colors.blue,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Icon(
                                      Icons.menu,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          width:150,

                                          child: Text(
                                            '${summery.workSubject}',

                                            style: TextStyle(
                                                fontWeight: FontWeight.bold, color: blueColor),
                                          )),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Container(
                                          child: Text(
                                            '${summery.propertyData?.rentaladress}',
                                            style: TextStyle(color: blueColor),
                                          )),
                                    ],
                                  ),
                                  Spacer(),
                                  if (summery.priority == "High")
                                    Container(
                                      height: 35,
                                      width: 70,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: Colors.red, width: 3),
                                      ),
                                      child: Center(
                                          child: Text("High",
                                              style: TextStyle(
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.w400))),
                                    ),
                                  if (summery.priority == "Medium")
                                    Container(
                                      height: 35,
                                      width: 70,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: blueColor, width: 3),
                                      ),
                                      child: Center(
                                          child: Text("Medium",
                                              style: TextStyle(
                                                  color: blueColor,
                                                  fontWeight: FontWeight.w400))),
                                    ),
                                  if (summery.priority == "Normal")
                                    Container(
                                      height: 35,
                                      width: 70,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: Colors.grey, width: 3),
                                      ),
                                      child: Center(
                                          child: Text("Normal",
                                              style: TextStyle(
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w400))),
                                    )
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                children: [
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          child: Text(
                                            'Description',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold, color: blueColor),
                                          )),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Container(
                                          child: Text(
                                            '${summery.workPerformed!.isNotEmpty ? summery.workPerformed : "N/A"}',
                                            style: TextStyle(color: blueColor),
                                          )),
                                    ],
                                  ),
                                  Spacer(),
                                  Container(
                                    height: 70,
                                    width: MediaQuery.of(context).size.width * .2,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.grey),
                                    ),
                                    child: Column(
                                      // crossAxisAlignment: CrossAxisAlignment.center,
                                      // mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          "Status",
                                          style: TextStyle(
                                            color: blueColor,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text('${summery.status}',
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          child: Text(
                                            'Permission to enter',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold, color: blueColor),
                                          )),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Container(
                                          child: Text(
                                            '${summery.entryAllowed}',
                                            style: TextStyle(color: blueColor),
                                          )),
                                    ],
                                  ),
                                  Spacer(),
                                  Container(
                                    height: 70,
                                    width: MediaQuery.of(context).size.width * .2,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.grey),
                                    ),
                                    child: Column(
                                      // crossAxisAlignment: CrossAxisAlignment.center,
                                      // mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          "Due Date",
                                          style: TextStyle(
                                            color: blueColor,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text( summery.workorderUpdates!.last.date!.isEmpty == true ?
                                        "N/A" : dateProvider.formatCurrentDate(summery.workorderUpdates!.last.date!.toString()),
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold)),
                                        SizedBox(
                                          height: 10,
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          child: Text(
                                            'Vendors Notes',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold, color: blueColor),
                                          )),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Container(
                                          width: 150,
                                          child: Text(
                                            '${summery.vendorNotes!.isNotEmpty ? summery.vendorNotes : "N/A"}',
                                            style: TextStyle(color: blueColor),
                                          )),
                                    ],
                                  ),
                                  Spacer(),
                                  Container(
                                    height: 70,
                                    width: MediaQuery.of(context).size.width * .2,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.grey),
                                    ),
                                    child: Column(
                                      // crossAxisAlignment: CrossAxisAlignment.center,
                                      // mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          "Assignees",
                                          style: TextStyle(
                                            color: blueColor,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        summery.staffData != null
                                            ? Text('${summery.staffData?.firstname}',
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold))
                                            : Text('N/A',
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Material(
                          elevation: 7,
                          borderOnForeground: true,
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.43,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(10),
                                    ),
                                  ),
                                  child: Material(
                                    elevation: 4,
                                    color: Colors.white,
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(10),
                                    ),
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          'Images',
                                          style: TextStyle(
                                            color: blueColor,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    if (summery.workorderUpdates != null)
                                      Column(
                                        children: [
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Wrap(
                                            spacing: 10,
                                            runSpacing: 10,
                                            children:
                                            summery.workOrderImages!.map((imageUrl) {
                                              return Container(
                                                width:
                                                summery.workOrderImages!.length == 1
                                                    ? MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                    3
                                                    : (MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                    3) -
                                                    10,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(10),
                                                ),
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(10),
                                                  child: CachedNetworkImage(
                                                    imageUrl: "$image_url$imageUrl",
                                                    placeholder: (context, url) => Center(
                                                        child:
                                                        CircularProgressIndicator()),
                                                    errorWidget: (context, url, error) {
                                                      print(error);
                                                      return Container();
                                                    },
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ],
                                      ),
                                    if (summery.workOrderImages!.length == 0)
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text("No Images Provided"),
                                          // Text("(${summery.unitData!.unitName})"),
                                        ],
                                      ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text("${summery.propertyData!.rentaladress} (${summery.unitData!.unitName})",textAlign: TextAlign.center,),

                                    SizedBox(
                                      height: 10,
                                    ),
                                    SizedBox(
                                      width: 300,
                                      child: Wrap(
                                        alignment: WrapAlignment.center,
                                        spacing: 4.0, // Space between texts horizontally
                                        runSpacing: 4.0, // Space between lines when wrapping
                                        children: [
                                          Text("${summery.propertyData!.rental_city}, "),
                                          Text("${summery.propertyData!.rental_state}, "),
                                          Text("${summery.propertyData!.rental_country}, "),
                                          Text("${summery.propertyData!.rental_postcode}"),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                  ],
                                )
                                /*  ListTile(
                              title: Text(
                                "Vendor",
                                style: TextStyle(
                                  color: blueColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              subtitle: Text(
                                "Vendor Company Name",
                                style: TextStyle(color: blueColor),
                              ),
                              leading: Container(
                                padding: EdgeInsets.only(top: 3),
                                child: Icon(
                                  Icons.person,
                                  size: 30,
                                ),
                              )

                            ),*/
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }
            else{
              return SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        border: Border.all(color:blueColor),
                        // color: Colors.blue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  color: blueColor,
                                  border: Border.all(
                                      color:blueColor),
                                  // color: Colors.blue,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Icon(
                                  Icons.menu,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(
                                width: 20,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width > 500
                                        ? 200
                                        : 180,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 1),
                                      child: Text(
                                        '${summery.workSubject}',
                                        maxLines: 5, // Set maximum number of lines
                                        overflow: TextOverflow
                                            .ellipsis, // Handle overflow with ellipsis
                                        style: TextStyle(
                                            fontSize:
                                            MediaQuery.of(context).size.width <
                                                500
                                                ? 13
                                                : 18,
                                            color: blueColor,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),

                                  SizedBox(
                                    height: 10,
                                  ),
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width > 500
                                        ? 200
                                        : 188,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 0),
                                      child: Text(
                                        '${summery.propertyData!.rentaladress} ${summery.unitData?.rental_unit != null ? '(${summery.unitData?.rental_unit})' :''}',
                                        maxLines: 5, // Set maximum number of lines
                                        overflow: TextOverflow
                                            .ellipsis, // Handle overflow with ellipsis
                                        style: TextStyle(
                                            fontSize:
                                            MediaQuery.of(context).size.width <
                                                500
                                                ? 13
                                                : 18,
                                            color: blueColor,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Spacer(),
                              if (summery.priority == "High")
                                Container(
                                  height: 35,
                                  width: 70,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.red, width: 3),
                                  ),
                                  child: Center(
                                      child: Text("High",
                                          style: TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.w400))),
                                ),
                              if (summery.priority == "Medium")
                                Container(
                                  height: 35,
                                  width: 70,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: blueColor, width: 3),
                                  ),
                                  child: Center(
                                      child: Text("Medium",
                                          style: TextStyle(
                                              color: blueColor,
                                              fontWeight: FontWeight.w400))),
                                ),
                              if (summery.priority == "Normal")
                                Container(
                                  height: 35,
                                  width: 70,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: Colors.grey, width: 3),
                                  ),
                                  child: Center(
                                      child: Text("Normal",
                                          style: TextStyle(
                                              color: Colors.grey,
                                              fontWeight: FontWeight.w400))),
                                )
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                        'Description',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold, color: blueColor),
                                      )),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                      width: 250,
                                      child: Text(
                                        '${summery.workPerformed!.isNotEmpty ? summery.workPerformed : "N/A"}',
                                        style: TextStyle(color: blueColor),
                                      )),
                                ],
                              ),
                              Spacer(),

                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Status",
                                    style: TextStyle(
                                      color: blueColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 4,
                                  ),
                                  Text('${summery.status}',
                                      style: TextStyle(
                                          color: blueColor,
                                          fontWeight: FontWeight.bold)),
                                ],
                              ),
                              Spacer(),
                              Container(
                                height: 70,
                                width: MediaQuery.of(context).size.width * .3,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Due Date",
                                      style: TextStyle(
                                        color: blueColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text( '${summery.workorderUpdates!.last.date!.isEmpty == true ?
                                    "N/A" : dateProvider.formatCurrentDate(summery.workorderUpdates!.last.date!.toString())
                                    }',
                                        style: TextStyle(
                                            color: blueColor,
                                            fontWeight: FontWeight.bold)),
                                    SizedBox(
                                      height: 10,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      child: Text(
                                        'Permission to enter',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold, color: blueColor),
                                      )),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                      child: Text(
                                        '${summery.entryAllowed! ? "Yes": "No" }',
                                        style: TextStyle(color: blueColor),
                                      )),
                                ],
                              ),
                              Spacer(),
                              Container(
                                // height: 70,
                                width: MediaQuery.of(context).size.width * .3,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.center,
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Assignees",
                                      style: TextStyle(
                                        color: blueColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    summery.staffData != null
                                        ? Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Expanded(
                                          child: Text('${summery.staffData?.firstname}',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: blueColor,
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ],
                                    )
                                        : Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text('N/A',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: blueColor,
                                                fontWeight: FontWeight.bold)),
                                      ],
                                    ),

                                    SizedBox(
                                      height: 10,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    IntrinsicHeight(
                      child: Material(
                        elevation: 7,
                        borderOnForeground: true,
                        borderRadius: BorderRadius.circular(10),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                ),
                                child: Material(
                                  elevation: 4,
                                  color: Colors.white,
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                  child: Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Images',
                                        style: TextStyle(
                                          color: blueColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  if (summery.workorderUpdates != null)
                                    Column(
                                      children: [
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Wrap(
                                          spacing: 10,
                                          runSpacing: 10,
                                          children:
                                          summery.workOrderImages!.map((imageUrl) {
                                            bool isMp4 = isVideo(imageUrl);
                                            return Container(
                                              width: summery.workOrderImages!.length == 1
                                                  ? MediaQuery.of(context).size.width / 3
                                                  : (MediaQuery.of(context).size.width / 3) - 10,
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              child: ClipRRect(
                                                borderRadius: BorderRadius.circular(10),
                                                child: isMp4
                                                    ?
                                                Container(
                                                  height: 80,
                                                  width: 80,
                                                  child: GestureDetector(
                                                    onTap: (){
                                                      _showVideoDialog('$image_url${imageUrl}');
                                                    },
                                                    child: Stack(
                                                      alignment: Alignment.center,
                                                      children: [
                                                        // Image.file(
                                                        //   File(snapshot.data!),
                                                        //   height:80,
                                                        //   width: 80,
                                                        //   fit: BoxFit.cover,
                                                        // ),
                                                        VideoItem(url: '$image_url${imageUrl}'),
                                                        Icon(Icons.play_circle_fill, color: Colors.white, size: 40),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                                    : CachedNetworkImage(
                                                  imageUrl: "$image_url$imageUrl",
                                                  placeholder: (context, url) => Center(
                                                      child: SpinKitFadingCircle(
                                                        color: Colors.black,
                                                        size: 40.0,
                                                      )),
                                                  errorWidget: (context, url, error) => Icon(Icons.error),
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ],
                                    ),
                                  if (summery.workOrderImages!.length == 0)
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("No Images Provided"),
                                        // Text("(${summery.unitData!.unitName})"),
                                      ],
                                    ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text("${summery.propertyData!.rentaladress} ${summery.unitData?.rental_unit != null ? '(${summery.unitData?.rental_unit})' :''}",textAlign: TextAlign.center,),

                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("${summery.propertyData!.rental_city}, "),
                                      Text("${summery.propertyData!.rental_state}, "),
                                      Text("${summery.propertyData!.rental_country}, "),
                                      Text("${summery.propertyData!.rental_postcode} "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                ],
                              )
                              /*  ListTile(
                            title: Text(
                              "Vendor",
                              style: TextStyle(
                                color: blueColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            subtitle: Text(
                              "Vendor Company Name",
                              style: TextStyle(color: blueColor),
                            ),
                            leading: Container(
                              padding: EdgeInsets.only(top: 3),
                              child: Icon(
                                Icons.person,
                                size: 30,
                              ),
                            )

                          ),*/
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              );
            }

          }
      ),
    );
  }

  bool isVideo(String url) {
    return url.toLowerCase().endsWith(".mp4");
  }

  void _showVideoDialog(String videoFile, {bool isImage = false}) {
    showDialog(
      context: context,
      builder: (context) {
        return isImage
            ? Dialog(
                backgroundColor: Colors.black,
                child: IntrinsicWidth(
                  child: IntrinsicHeight(
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        CachedNetworkImage(
                          imageUrl: "$image_url$videoFile",
                          placeholder: (context, url) => Center(
                              child: SpinKitFadingCircle(
                            color: Colors.black,
                            size: 40.0,
                          )),
                          errorWidget: (context, url, error) =>
                              Icon(Icons.error),
                          fit: BoxFit.cover,
                        ),
                        Positioned(
                          top:
                              -50, // Moves the close button above the container
                          right: 0,
                          child: IconButton(
                            icon: Icon(Icons.close,
                                color: Colors.white, size: 30),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : Container(
                child: VideoPlayerDialog(
                  videoUrl: videoFile,
                ),
              );
      },
    );
  }

  //
  // updatecheckBox() async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  //   String? id = prefs.getString("adminId");
  //   String? token = prefs.getString('token');
  //   var checkvalue = {"applicant_checkedChecklist": applicantChecklist};
  //   final response = await http.put(
  //     Uri.parse('$Api_url/api/applicant/applicant/${widget.applicant_id}'),
  //     headers: <String, String>{
  //       "id": "CRM $id",
  //       "authorization": "CRM $token",
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(checkvalue),
  //   );
  //   if (response.statusCode == 200) {
  //     // Fluttertoast.showToast(msg: 'Applicant Updated Successfully');
  //
  //     setState(() {});
  //   } else {
  //     // Log the response body for debugging
  //     print('Failed to update data: ${response.body}');
  //     throw Exception('Failed to update applicant data');
  //   }
  // }
  //
  // updatecheckBoxnew(List applicant) async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  //   String? id = prefs.getString("adminId");
  //   String? token = prefs.getString('token');
  //   var checkvalue = {"applicant_checklist": applicant};
  //   final response = await http.put(
  //     Uri.parse(
  //         '$Api_url/api/applicant/applicant/${widget.applicant_id}/checklist'),
  //     headers: <String, String>{
  //       "id": "CRM $id",
  //       "authorization": "CRM $token",
  //       'Content-Type': 'application/json; charset=UTF-8',
  //     },
  //     body: jsonEncode(checkvalue),
  //   );
  //   if (response.statusCode == 200) {
  //     // Fluttertoast.showToast(msg: 'Applicant Updated Successfully');
  //
  //     setState(() {});
  //   } else {
  //     // Log the response body for debugging
  //     print('Failed to update data: ${response.body}');
  //     throw Exception('Failed to update applicant data');
  //   }
  // }
  void showUpdateDialog(BuildContext context) {
    // Initialize variables to store user input
    String? selectedStatus;
    //  DateTime? selectedDate;
    //String? message;
    TextEditingController message = TextEditingController();
    TextEditingController selectedDate = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Update Work Order',
            style: TextStyle(color: blueColor),
          ),
          content: Container(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Status', style: TextStyle(color: blueColor)),
                DropdownButtonHideUnderline(
                  child: DropdownButtonFormField2<String>(
                    decoration: InputDecoration(border: InputBorder.none),
                    isExpanded: true,
                    hint: const Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Select Status',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              color: Color(0xFFb0b6c3),
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    items: ['New', 'In Progress', 'On Hold', 'Completed']
                        .map((status) {
                      return DropdownMenuItem<String>(
                        value: status,
                        child: Text(
                          status,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Colors.black87,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    value: selectedStatus,
                    onChanged: (value) {
                      selectedStatus = value;
                    },
                    buttonStyleData: ButtonStyleData(
                      height: 45,
                      width: double.infinity,
                      padding: const EdgeInsets.only(left: 14, right: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: Colors.white,
                      ),
                      elevation: 2,
                    ),
                    iconStyleData: const IconStyleData(
                      icon: Icon(Icons.arrow_drop_down),
                      iconSize: 24,
                      iconEnabledColor: Color(0xFFb0b6c3),
                      iconDisabledColor: Colors.grey,
                    ),
                    dropdownStyleData: DropdownStyleData(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: Colors.white,
                      ),
                      scrollbarTheme: ScrollbarThemeData(
                        radius: const Radius.circular(6),
                        thickness: MaterialStateProperty.all(6),
                        thumbVisibility: MaterialStateProperty.all(true),
                      ),
                    ),
                    menuItemStyleData: const MenuItemStyleData(
                      height: 40,
                      padding: EdgeInsets.only(left: 14, right: 14),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select an option';
                      }
                      return null;
                    },
                  ),
                ),
                Text('Due Date', style: TextStyle(color: blueColor)),
                SizedBox(height: 8.0),
                Material(
                  elevation: 3,
                  borderRadius: BorderRadius.circular(8.0),
                  child: Container(
                    height: 45,
                    padding:
                        EdgeInsets.symmetric(horizontal: 16.0, vertical: 0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: TextFormField(
                      onTap: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2101),
                          helpText: "Due Date",
                          locale: const Locale('en', 'US'),
                          builder: (BuildContext context, Widget? child) {
                            return Theme(
                              data: ThemeData.light().copyWith(
                                colorScheme: const ColorScheme.light(
                                  primary: Color.fromRGBO(
                                      21, 43, 83, 1), // header background color
                                  onPrimary: Colors.white, // header text color
                                  onSurface: Color.fromRGBO(
                                      21, 43, 83, 1), // body text color
                                ),
                                textButtonTheme: TextButtonThemeData(
                                  style: TextButton.styleFrom(
                                    foregroundColor: Colors.white,
                                    backgroundColor: const Color.fromRGBO(
                                        21, 43, 83, 1), // button text color
                                  ),
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );

                        if (pickedDate != null) {
                          String formattedDate =
                              "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
                          setState(() {
                            selectedDate.text = formattedDate;
                          });
                        }
                      },
                      //  obscureText: widget.obscureText,
                      readOnly: true,
                      controller: selectedDate,
                      decoration: InputDecoration(
                        suffixIcon:
                            Icon(Icons.calendar_today, color: blueColor),
                        // hintStyle:
                        // TextStyle(fontSize: 13, color: blueColor),
                        border: InputBorder.none,
                        hintText: "dd-mm-yyyy",
                      ),
                    ),
                  ),
                ),
                /* ElevatedButton(
                  onPressed: () async {
                    final DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (pickedDate != null) {
                      selectedDate = pickedDate;
                    }
                  },
                  child: Text(selectedDate == null
                      ? 'Select Date'
                      : '${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}'),
                ),*/
                SizedBox(height: 16.0),
                Text('Message', style: TextStyle(color: blueColor)),
                Material(
                  elevation: 3,
                  borderRadius: BorderRadius.circular(8.0),
                  child: Container(
                    height: 50,
                    padding:
                        EdgeInsets.symmetric(horizontal: 16.0, vertical: 0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.0),
                      //border: Border.all(color: blueColor),
                      // boxShadow: [
                      //   BoxShadow(
                      //     color: Colors.black.withOpacity(0.2),
                      //     offset: Offset(4, 4),
                      //     blurRadius: 3,
                      //   ),
                      // ],
                    ),
                    child: TextFormField(
                      /*    onTap: ()async{
                        final DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (pickedDate != null) {
                          selectedDate = pickedDate;
                        }
                      },*/
                      //  obscureText: widget.obscureText,
                      // readOnly: true,
                      //keyboardType: widget.keyboardType,
                      /* validator: (value) {
                        if (value == null || value.isEmpty) {
                          state.validate();
                        }
                        return null;
                      },*/
                      controller: message,

                      decoration: InputDecoration(
                        //  suffixIcon: widget.suffixIcon,
                        hintStyle: TextStyle(fontSize: 13, color: blueColor),
                        border: InputBorder.none,
                        //   hintText: widget.hintText,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text(
                'Cancel',
                style: TextStyle(color: blueColor),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: blueColor),
              onPressed: () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                String? firstName = prefs.getString("first_name");
                String? lastName = prefs.getString("last_name");
                Map<String, dynamic> values = {
                  "date": selectedDate.text,
                  "message": message.text,
                  "status": selectedStatus,
                  "statusUpdatedBy": "$firstName $lastName(Tenant)"
                };
                await WorkOrderRepository.updateworkorderSummary(
                        values, widget.workorder_id!)
                    .then((value) {
                  setState(() {
                    futureworkorderSummary =
                        WorkOrderRepository.getworkorderSummary(
                            widget.workorder_id!);
                  });
                });

                // Save the data and close the dialog
                /*  WorkorderUpdates update = WorkorderUpdates(
                  status: selectedStatus,
                  date: selectedDate,
                  message: message,
                );*/
                // Here you can handle saving the update data
                // print('Status: ${update.status}');
                // print('Date: ${update.date}');
                // print('Message: ${update.message}');
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }
}

class PartWidget extends StatelessWidget {
  final PartsandchargeData part;
  final double total;

  PartWidget({required this.part, required this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            part.account!,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '\$${part.partsPrice} x ${part.partsQuantity}',
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              Text(
                '\$${(part.partsPrice! * part.partsQuantity!).toStringAsFixed(2)}',
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
            ],
          ),
          SizedBox(height: 5),
          Text(
            "${part.description}",
            style: TextStyle(fontSize: 14, color: Colors.black54),
          ),
          Divider(color: Colors.grey),
          /* Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Text(
                '\$${(part.partsPrice! * part.partsQuantity!).toStringAsFixed(2)}',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
            ],
          ),*/
        ],
      ),
    );
  }
}
